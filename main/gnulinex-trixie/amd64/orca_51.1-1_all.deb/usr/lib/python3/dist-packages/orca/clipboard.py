# Utilities related to the clipboard
#
# Copyright 2024-2025 Igalia, S.L.
# Copyright 2024 GNOME Foundation Inc.
# Author: Joanmarie Diggs <jdiggs@igalia.com>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., Franklin Street, Fifth Floor,
# Boston MA  02110-1301 USA.

"""Utilities related to the clipboard."""

from __future__ import annotations

import re
import time
from typing import TYPE_CHECKING, Any

import gi
from dasbus.connection import SessionMessageBus
from dasbus.error import DBusError

gi.require_version("Atspi", "2.0")
gi.require_version("Gdk", "3.0")
gi.require_version("Gtk", "3.0")
from gi.repository import Atspi, Gdk, Gtk

from . import (
    clipboard_command_definitions,
    dbus_service,
    debug,
    guilabels,
    input_event,
    input_event_manager,
    messages,
    presentation_manager,
    script_manager,
)
from .ax_utilities import AXUtilities
from .extension import Extension

if TYPE_CHECKING:
    from collections.abc import Callable

    from dasbus.client.proxy import InterfaceProxy

    from .command import Command
    from .scripts import default


class _ClipboardManager:
    """Base class for interacting with clipboard managers."""

    def __init__(self, name: str, change_callback: Callable[[str], None]) -> None:
        self._name: str = name
        self._change_callback: Callable[[str], None] = change_callback
        self._contents: str = ""
        self._is_active: bool = False

    def is_active(self) -> bool:
        """Returns True if this manager is active."""

        return self._is_active

    def connect(self) -> None:
        """Connects to the clipboard manager."""

    def disconnect(self) -> None:
        """Disconnects from the clipboard manager."""

    def set_contents(self, text: str) -> None:
        """Sets the contents of the clipboard to text."""

    def get_contents(self) -> str:
        """Returns the pre-stored contents of the clipboard."""

        if not self._contents:
            self._contents = self._get_contents()
        return self._contents

    def _get_contents(self) -> str:
        """Obtains and returns the contents of the clipboard."""

        return ""

    def _on_contents_changed(self, *args: tuple[Any, ...], **kwargs: dict[str, Any]) -> None:
        """Notifies the registered callback that the contents changed."""

        tokens = [self._name, ": Contents changed.", args, kwargs]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        self._contents = self._get_contents()
        self._change_callback(self._contents)


class _ClipboardManagerFallback(_ClipboardManager):
    """Class for interacting with the clipboard via Gtk.Clipboard."""

    def __init__(self, change_callback: Callable[[str], None]) -> None:
        super().__init__("FALLBACK", change_callback)
        self._handler_id: int | None = None

    def connect(self) -> None:
        """Connects to the clipboard manager."""

        if self._handler_id is not None:
            return

        clipboard = Gtk.Clipboard.get(Gdk.Atom.intern("CLIPBOARD", False))
        self._handler_id = clipboard.connect("owner-change", self._on_contents_changed)
        self._is_active = True

    def disconnect(self) -> None:
        """Disconnects from the clipboard manager."""

        self._is_active = False
        if self._handler_id is None:
            return

        clipboard = Gtk.Clipboard.get(Gdk.Atom.intern("CLIPBOARD", False))
        clipboard.disconnect(self._handler_id)
        self._handler_id = None

    def _get_contents(self) -> str:
        """Obtains and returns the contents of the clipboard."""

        if self._handler_id is None:
            return ""

        clipboard = Gtk.Clipboard.get(Gdk.Atom.intern("CLIPBOARD", False))
        result = clipboard.wait_for_text()
        if result is None:
            msg = "FALLBACK: Have handler, but text is None"
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return ""

        debug_string = result.replace("\n", "\\n")
        tokens = ["FALLBACK: Clipboard contents:", debug_string]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        return result

    def set_contents(self, text: str) -> None:
        """Sets the contents of the clipboard to text."""

        tokens = ["FALLBACK: Setting clipboard contents to:", text]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        clipboard = Gtk.Clipboard.get(Gdk.Atom.intern("CLIPBOARD", False))
        clipboard.set_text(text, -1)


class _ClipboardManagerGPaste(_ClipboardManager):
    """Class for interacting with the clipboard via GPaste."""

    _DBUS_TIMEOUT_MS = 1000
    _DBUS_INTERFACE = ""

    def __init__(self, change_callback: Callable[[str], None]) -> None:
        super().__init__("GPASTE", change_callback)
        self._bus: SessionMessageBus | None = None
        self._gpaste_proxy: InterfaceProxy | None = None
        self._props_proxy: InterfaceProxy | None = None
        self._signal_subscription: Any | None = None
        self._original_active_state: bool | None = None

    def _set_active(self, active: bool) -> None:
        """Enables or disables clipboard tracking."""

        raise NotImplementedError

    def connect(self) -> None:
        """Connects to the clipboard manager."""

        try:
            self._bus = SessionMessageBus()
            self._gpaste_proxy = self._bus.get_proxy("org.gnome.GPaste", "/org/gnome/GPaste")

            # Test if the service is actually available by checking properties
            self._props_proxy = self._bus.get_proxy(
                "org.gnome.GPaste",
                "/org/gnome/GPaste",
                "org.freedesktop.DBus.Properties",
            )
            self._original_active_state = self._props_proxy.Get(
                self._DBUS_INTERFACE,
                "Active",
                timeout=self._DBUS_TIMEOUT_MS,
            )
        except (DBusError, TimeoutError) as error:
            tokens = ["CLIPBOARD PRESENTER: Could not access GPaste interface:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            self._gpaste_proxy = None
            self._props_proxy = None
            self._bus = None
            return

        try:
            if not self._original_active_state:
                msg = "CLIPBOARD PRESENTER: GPaste is not active. Enabling Tracking."
                debug.print_message(debug.LEVEL_INFO, msg, True)
                self._set_active(True)
                new_state = self._props_proxy.Get(
                    self._DBUS_INTERFACE,
                    "Active",
                    timeout=self._DBUS_TIMEOUT_MS,
                )
                tokens = ["CLIPBOARD PRESENTER: Is active now:", bool(new_state)]
                debug.print_tokens(debug.LEVEL_INFO, tokens, True)

            self._signal_subscription = self._gpaste_proxy.Update.connect(self._on_contents_changed)
            self._is_active = True
        except (DBusError, TimeoutError) as error:
            tokens = ["CLIPBOARD PRESENTER: Could not connect to GPaste signals:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            self._gpaste_proxy = None
            self._props_proxy = None
            self._bus = None

    def disconnect(self) -> None:
        """Disconnects from the clipboard manager."""

        if self._gpaste_proxy is None or self._props_proxy is None:
            msg = "CLIPBOARD PRESENTER: Cannot disconnect due to missing interface(s)."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        if self._signal_subscription is not None:
            self._signal_subscription.disconnect()
            self._signal_subscription = None

        if not self._original_active_state:
            msg = "CLIPBOARD PRESENTER: Restoring inactive state by disabling tracking."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            try:
                self._set_active(False)
                new_state = self._props_proxy.Get(
                    self._DBUS_INTERFACE,
                    "Active",
                    timeout=self._DBUS_TIMEOUT_MS,
                )
                tokens = ["CLIPBOARD PRESENTER: Is active now:", bool(new_state)]
                debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            except (DBusError, TimeoutError) as error:
                tokens = ["CLIPBOARD PRESENTER: Could not restore GPaste state:", error]
                debug.print_tokens(debug.LEVEL_INFO, tokens, True)

        self._gpaste_proxy = None
        self._props_proxy = None
        self._bus = None
        self._is_active = False


class _ClipboardManagerGPaste2(_ClipboardManagerGPaste):
    """Class for interacting with the clipboard via GPaste2."""

    _DBUS_INTERFACE = "org.gnome.GPaste2"

    def _set_active(self, active: bool) -> None:
        assert self._gpaste_proxy is not None
        self._gpaste_proxy.Track(active, timeout=self._DBUS_TIMEOUT_MS)

    def _get_contents(self) -> str:
        """Obtains and returns the contents of the clipboard."""

        if self._gpaste_proxy is None:
            return ""

        try:
            result = self._gpaste_proxy.GetElementAtIndex(0, timeout=self._DBUS_TIMEOUT_MS)[1]
        except (DBusError, TimeoutError) as error:
            tokens = ["GPASTE2: Could not get clipboard contents:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            return ""

        debug_string = result.replace("\n", "\\n")
        tokens = ["GPASTE2: Clipboard contents:", debug_string]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        return result

    def set_contents(self, text: str) -> None:
        """Sets the contents of the clipboard to text."""

        if self._gpaste_proxy is None:
            return

        try:
            self._gpaste_proxy.Add(text, timeout=self._DBUS_TIMEOUT_MS)
        except (DBusError, TimeoutError) as error:
            tokens = ["GPASTE2: Could not set clipboard contents:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)


class _ClipboardManagerGPaste3(_ClipboardManagerGPaste):
    """Class for interacting with the clipboard via GPaste3."""

    _DBUS_INTERFACE = "org.gnome.GPaste3"

    def _set_active(self, active: bool) -> None:
        assert self._gpaste_proxy is not None
        self._gpaste_proxy.SetActive(active, timeout=self._DBUS_TIMEOUT_MS)

    def _get_contents(self) -> str:
        """Obtains and returns the contents of the clipboard."""

        if self._gpaste_proxy is None:
            return ""

        try:
            result = self._gpaste_proxy.GetItemAtIndex(0, timeout=self._DBUS_TIMEOUT_MS)[1]
        except (DBusError, TimeoutError) as error:
            tokens = ["GPASTE3: Could not get clipboard contents:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            return ""

        debug_string = result.replace("\n", "\\n")
        tokens = ["GPASTE3: Clipboard contents:", debug_string]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        return result

    def set_contents(self, text: str) -> None:
        """Sets the contents of the clipboard to text."""

        if self._gpaste_proxy is None:
            return

        try:
            self._gpaste_proxy.AddText(text, timeout=self._DBUS_TIMEOUT_MS)
        except (DBusError, TimeoutError) as error:
            tokens = ["GPASTE3: Could not set clipboard contents:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)


class _ClipboardManagerKlipper(_ClipboardManager):
    """Class for interacting with the clipboard via Klipper ."""

    def __init__(self, change_callback: Callable[[str], None]) -> None:
        super().__init__("KLIPPER", change_callback)
        self._bus: SessionMessageBus | None = None
        self._klipper_proxy: InterfaceProxy | None = None
        self._signal_subscription: Any | None = None

    def connect(self) -> None:
        """Connects to the clipboard manager."""

        try:
            self._bus = SessionMessageBus()
            self._klipper_proxy = self._bus.get_proxy("org.kde.klipper", "/klipper")

            # Test if the service is actually available by calling a simple method
            self._klipper_proxy.getClipboardContents()
        except DBusError as error:
            tokens = ["CLIPBOARD PRESENTER: Could not access klipper interface:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            return

        try:
            self._signal_subscription = self._klipper_proxy.clipboardHistoryUpdated.connect(
                self._on_contents_changed,
            )
            self._is_active = True
        except DBusError as error:
            tokens = ["CLIPBOARD PRESENTER: Could not connect to klipper signal:", error]
            debug.print_tokens(debug.LEVEL_INFO, tokens, True)
            self._klipper_proxy = None
            self._bus = None

    def disconnect(self) -> None:
        """Disconnects from the clipboard manager."""

        if self._signal_subscription is not None:
            self._signal_subscription.disconnect()
        self._signal_subscription = None
        self._klipper_proxy = None
        self._bus = None
        self._is_active = False

    def _get_contents(self) -> str:
        """Obtains and returns the contents of the clipboard."""

        if self._klipper_proxy is None:
            return ""

        result = self._klipper_proxy.getClipboardContents()
        debug_string = result.replace("\n", "\\n")
        tokens = ["KLIPPER: Clipboard contents:", debug_string]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        return result

    def set_contents(self, text: str) -> None:
        """Sets the contents of the clipboard to text."""

        if self._klipper_proxy is None:
            return

        tokens = ["KLIPPER: Setting clipboard contents to:", text]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        self._klipper_proxy.setClipboardContents(text)


class ClipboardPresenter(Extension):
    """Manages clipboard-related functionality."""

    GROUP_LABEL = guilabels.KB_GROUP_CLIPBOARD

    def __init__(self) -> None:
        self._event_listener: Atspi.EventListener = Atspi.EventListener.new(self._listener)
        self._last_clipboard_update_text: str = ""
        self._last_clipboard_update_time: float = time.time()
        self._manager: _ClipboardManager | None = None
        super().__init__()

    def _get_commands(self) -> list[Command]:
        return clipboard_command_definitions.get_commands(self)

    @dbus_service.command
    def present_clipboard_contents(
        self,
        script: default.Script,
        event: input_event.InputEvent | None = None,
        notify_user: bool = True,
    ) -> bool:
        """Presents the clipboard contents."""

        tokens = [
            "CLIPBOARD PRESENTER: present_clipboard_contents. Script:",
            script,
            "Event:",
            event,
            "notify_user:",
            notify_user,
        ]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)

        if self._manager is None:
            msg = "CLIPBOARD PRESENTER: Cannot present contents, no active manager."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return False

        contents = self._manager.get_contents()
        if not contents or len(contents) > 5000:
            contents = messages.character_count(len(contents))
        presentation_manager.get_manager().present_message(
            messages.CLIPBOARD_CONTAINS % contents,
            contents,
        )
        return True

    def _connect(self) -> None:
        """Connects to the clipboard manager."""

        if self._manager is not None:
            return

        manager: _ClipboardManager | None = None

        # If you try to connect to Klipper from a GNOME session, it will fail with a DBus
        # exception. However, if you try to connect to GPaste from a KDE session, it will
        # succeed -- or at least not throw an exception. Therefore, check for Klipper first.
        manager = _ClipboardManagerKlipper(self._present_clipboard_contents_change)
        manager.connect()
        if manager.is_active():
            self._manager = manager
            msg = "CLIPBOARD PRESENTER: Using Klipper."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        # See comment above. Check for GPaste last.
        manager = _ClipboardManagerGPaste3(self._present_clipboard_contents_change)
        manager.connect()
        if manager.is_active():
            self._manager = manager
            msg = "CLIPBOARD PRESENTER: Using GPaste3."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        manager = _ClipboardManagerGPaste2(self._present_clipboard_contents_change)
        manager.connect()
        if manager.is_active():
            self._manager = manager
            msg = "CLIPBOARD PRESENTER: Using GPaste2."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        self._manager = _ClipboardManagerFallback(self._present_clipboard_contents_change)
        self._manager.connect()
        msg = "CLIPBOARD PRESENTER: Using Gtk.Clipboard as fallback."
        debug.print_message(debug.LEVEL_INFO, msg, True)

    def _disconnect(self) -> None:
        """Disconnects from the clipboard manager."""

        if self._manager is None:
            return
        self._manager.disconnect()

    def _get_contents(self) -> str:
        """Returns the clipboard contents."""

        if self._manager is None:
            msg = "CLIPBOARD PRESENTER: Cannot get contents, no active manager"
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return ""

        result = self._manager.get_contents()
        debug_string = result.replace("\n", "\\n")
        tokens = ["CLIPBOARD PRESENTER: Current contents:", debug_string]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        return result

    def activate(self) -> None:
        """Activates the presenter."""

        debug.print_message(debug.LEVEL_INFO, "CLIPBOARD PRESENTER: Activating", True)
        self._event_listener.register("object:text-changed")
        self._connect()
        debug.print_message(debug.LEVEL_INFO, "CLIPBOARD PRESENTER: Activated", True)

    def deactivate(self) -> None:
        """Deactivates the presenter."""

        debug.print_message(debug.LEVEL_INFO, "CLIPBOARD PRESENTER: Deactivating", True)
        self._event_listener.deregister("object:text-changed")
        self._disconnect()
        debug.print_message(debug.LEVEL_INFO, "CLIPBOARD PRESENTER: Deactivated", True)

    def append_text(self, text: str, separator: str = "\n") -> None:
        """Appends text to the clipboard contents."""

        if self._manager is None:
            msg = "CLIPBOARD PRESENTER: Cannot append text, no active manager."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        old_text = self._manager.get_contents()
        new_text = f"{old_text}{separator}{text}"
        tokens = ["CLIPBOARD PRESENTER: Appending '", text, "'. New contents: '", new_text, "'."]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        self._manager.set_contents(new_text)

    def set_text(self, text: str) -> None:
        """Sets the clipboard contents to text."""

        if self._manager is None:
            msg = "CLIPBOARD PRESENTER: Cannot set text, no active manager."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        tokens = ["CLIPBOARD PRESENTER: Setting text to '", text, "'."]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        self._manager.set_contents(text)

    def is_clipboard_text_changed_event(self, event: Atspi.Event) -> bool:
        """Returns True if event is a text changed event associated with the clipboard."""

        if not event.type.startswith("object:text-changed"):
            return False

        if not (AXUtilities.is_editable(event.source) or AXUtilities.is_terminal(event.source)):
            return False

        manager = input_event_manager.get_manager()
        if (
            not manager.last_event_was_command()
            or manager.last_event_was_undo()
            or manager.last_event_was_backspace()
        ):
            return False

        if "delete" in event.type and manager.last_event_was_paste():
            return False

        contents = self._get_contents()
        if not contents:
            return False

        # Some applications send multiple text insertion events for part of a given paste.
        words_match = bool(re.search(r"\w", event.any_data)) == bool(re.search(r"\w", contents))
        return words_match and contents.startswith(event.any_data.rstrip())

    def _present_clipboard_contents_change(self, string: str) -> None:
        """Presents the clipboard contents change."""

        tokens = ["CLIPBOARD PRESENTER: Contents changed to: '", string, "'"]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)

        if (
            string == self._last_clipboard_update_text
            and time.time() - self._last_clipboard_update_time < 1
        ):
            msg = "CLIPBOARD PRESENTER: Not presenting change: likely duplicate."
            debug.print_message(debug.LEVEL_INFO, msg, True)
            return

        self._last_clipboard_update_text = string
        self._last_clipboard_update_time = time.time()
        script = script_manager.get_manager().get_active_script()
        if script is None:
            return

        manager = input_event_manager.get_manager()
        if manager.last_event_was_cut():
            presentation_manager.get_manager().present_message(
                messages.CLIPBOARD_CUT_FULL,
                messages.CLIPBOARD_CUT_BRIEF,
            )
            return

        if manager.last_event_was_copy():
            presentation_manager.get_manager().present_message(
                messages.CLIPBOARD_COPIED_FULL,
                messages.CLIPBOARD_COPIED_BRIEF,
            )
            return

        if manager.last_event_was_paste():
            presentation_manager.get_manager().present_command_announcement()
            return

        msg = "CLIPBOARD PRESENTER: Not presenting change: is not cut, copy, or paste"
        debug.print_message(debug.LEVEL_INFO, msg, True)

    def _listener(self, event: Atspi.Event) -> None:
        """Generic listener for events of interest."""

        tokens = ["CLIPBOARD PRESENTER: Possible change event", event]
        debug.print_tokens(debug.LEVEL_INFO, tokens, True)
        if self.is_clipboard_text_changed_event(event):
            self._present_clipboard_contents_change(event.any_data)


_presenter: ClipboardPresenter = ClipboardPresenter()


def get_presenter() -> ClipboardPresenter:
    """Returns the Clipboard Presenter singleton."""

    return _presenter
