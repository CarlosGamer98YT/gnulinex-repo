# This file is part of budgie-desktop
#
# Copyright Budgie Desktop Developers
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# ruff: noqa: BLE001

from __future__ import annotations

import copy
import logging
import os
import shutil
import xml.etree.ElementTree as Et

from .. import paths
from ..config import LabwcConfig, save
from .rewrites import REWRITES

log = logging.getLogger(__name__)

CURRENT_RC_VERSION = 6


class RcXmlMigration:
    """Handles migration of rc.xml to newer versions"""

    def __init__(self, config: LabwcConfig):
        self.config = config

    def get_rc_version(self, et: Et.ElementTree[Et.Element]) -> int:
        """Get the version number from rc.xml root element"""
        root = et.getroot()
        version = root.get("version")
        if version is None:
            return 0  # No version means old/original format
        return int(version)

    def needs_migration(self) -> bool:
        """Check if user's rc.xml needs migration"""
        try:
            user_version = self.get_rc_version(self.config.et)
            return user_version < CURRENT_RC_VERSION
        except ValueError:
            return False

    def backup_user_config(self) -> bool:
        """Create backup of user's current rc.xml"""
        user_path = self.config.path
        backup_path = user_path + ".backup"

        try:
            shutil.copy2(user_path, backup_path)
            log.info(f"Backed up rc.xml to {backup_path}")
            return True
        except Exception as e:
            log.error(f"Failed to backup rc.xml: {e}")
            return False

    def load_template(self) -> Et.ElementTree[Et.Element] | None:
        """Load the new template rc.xml from system data dirs"""
        # A distro's own template shadows ours within the same data dir
        for template_path in paths.shipped("distro-rc.xml", "rc.xml"):
            if not os.path.isfile(template_path):
                continue
            try:
                return Et.parse(template_path)
            except Exception as e:
                log.warning(f"Cannot parse template {template_path}: {e}")

        log.error("Could not find rc.xml template")
        return None

    def replace_keyboard_section(
        self,
        user_et: Et.ElementTree[Et.Element],
        template_et: Et.ElementTree[Et.Element],
    ) -> bool:
        """Merge the template's keyboard section"""
        user_root = user_et.getroot()
        template_root = template_et.getroot()

        # Find keyboard section in template
        template_keyboard = template_root.find("./keyboard")
        if template_keyboard is None:
            log.error("Template has no keyboard section")
            return False

        user_keyboard = user_root.find("./keyboard")

        if user_keyboard is None:
            # Nothing of the user's to preserve - insert the template's
            # keyboard section wholesale.
            new_keyboard = copy.deepcopy(template_keyboard)

            theme_element = user_root.find("./theme")
            if theme_element is not None:
                insert_index = list(user_root).index(theme_element)
                user_root.insert(insert_index, new_keyboard)
            else:
                windowrules_element = user_root.find("./windowRules")
                if windowrules_element is not None:
                    insert_index = list(user_root).index(windowrules_element)
                    user_root.insert(insert_index, new_keyboard)
                else:
                    user_root.append(new_keyboard)

            log.info("Inserted keyboard section from template")
            return True

        # Bring over any non-keybind settings (e.g. <numlock>)
        added_any = False
        for template_child in template_keyboard:
            if template_child.tag == "keybind":
                continue
            if user_keyboard.find(f"./{template_child.tag}") is None:
                user_keyboard.append(copy.deepcopy(template_child))
                added_any = True

        if added_any:
            log.info("Added missing non-keybind keyboard settings from template")
        else:
            log.info(
                "Keyboard section already has all non-keybind settings - nothing to merge"
            )

        return True

    def merge_mouse_section(
        self,
        user_et: Et.ElementTree[Et.Element],
        template_et: Et.ElementTree[Et.Element],
    ) -> None:
        """Add the template's mouse settings and contexts the user's config lacks"""
        template_mouse = template_et.getroot().find("./mouse")
        if template_mouse is None:
            log.info("Template has no mouse section - nothing to merge")
            return

        user_root = user_et.getroot()
        user_mouse = user_root.find("./mouse")

        if user_mouse is None:
            user_root.append(copy.deepcopy(template_mouse))
            log.info("Inserted mouse section from template")
            return

        # labwc keeps the later of two identical mousebinds, so <default /> must precede contexts
        insert_at = 0
        added_any = False
        for template_child in template_mouse:
            existing = self.find_mouse_child(user_mouse, template_child)
            if existing is not None:
                insert_at = list(user_mouse).index(existing) + 1
                continue

            user_mouse.insert(insert_at, copy.deepcopy(template_child))
            insert_at += 1
            added_any = True

        if added_any:
            log.info("Added missing mouse settings from template")
        else:
            log.info("Mouse section already has all template settings - nothing to merge")

    def find_mouse_child(
        self, user_mouse: Et.Element, template_child: Et.Element
    ) -> Et.Element | None:
        """The user's counterpart of a template <mouse> child, a context matched by name"""
        name = template_child.get("name")
        for child in user_mouse:
            if child.tag == template_child.tag and child.get("name") == name:
                return child
        return None

    def apply_rewrites(
        self, user_et: Et.ElementTree[Et.Element], from_version: int
    ) -> bool:
        """Apply the rewrites of every rc.xml version above from_version; True when any did"""
        user_root = user_et.getroot()
        changed = False

        for version in sorted(REWRITES):
            if version <= from_version:
                continue

            log.info(f"Applying rc.xml version {version} rewrites")
            for rewrite in REWRITES[version]:
                changed |= rewrite.apply(user_root)

        return changed

    def migrate(self) -> bool:
        """Merge the template's keyboard and mouse settings, apply the rewrites, and record the version"""
        user_version = self.get_rc_version(self.config.et)
        log.info(f"Starting rc.xml migration from version {user_version}")

        # Step 1: Backup current config
        if not self.backup_user_config():
            log.error("Migration aborted - backup failed")
            return False

        # Step 2: Load template
        template_et = self.load_template()
        if template_et is None:
            log.error("Migration aborted - no template found")
            return False

        # Step 3: Replace keyboard section in user's config
        user_et = self.config.et
        if not self.replace_keyboard_section(user_et, template_et):
            log.error("Migration aborted - failed to replace keyboard section")
            return False

        # Step 4: Add mouse settings and contexts the user's config lacks
        self.merge_mouse_section(user_et, template_et)

        # Step 5: Bring values written by older versions up to date
        self.apply_rewrites(user_et, user_version)

        # Step 6: Set version number on user config
        user_et.getroot().set("version", str(CURRENT_RC_VERSION))

        # Step 7: Write updated config
        save(user_et, self.config.path)

        return True
