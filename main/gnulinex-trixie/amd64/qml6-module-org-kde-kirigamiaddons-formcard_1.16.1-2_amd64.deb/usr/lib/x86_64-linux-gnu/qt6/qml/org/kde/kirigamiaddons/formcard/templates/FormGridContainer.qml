// SPDX-FileCopyrightText: 2022 Devin Lin <devin@kde.org>
// SPDX-FileCopyrightText: 2023 Rishi Kumar <rsi.dev17@gmail.com>
// SPDX-FileCopyrightText: 2023 Carl Schwan <carl@carlschwan.eu>
// SPDX-License-Identifier: LGPL-2.0-or-later

import QtQuick
import QtQuick.Layouts
import QtQuick.Templates as T

import org.kde.kirigami as Kirigami

import org.kde.kirigamiaddons.formcard as FormCard

/*!
   \qmltype FormGridContainer
   \inqmlmodule org.kde.kirigamiaddons.formcard.templates
   \brief This component render a grid of small cards.

   This is used to display multiple information in a FormCard.FormLayout
   without taking too much vertical space.

   Form delegates can also be placed directly inside the container. In this
   mode, delegates are displayed in a two-column grid, each with its own card
   background.

   \qml
   import org.kde.kirigamiaddons.formcard as FormCard

   FormCard.FormGridContainer {
       id: container

       Layout.topMargin: Kirigami.Units.largeSpacing
       Layout.fillWidth: true

       infoCards: [
           FormCard.FormGridContainer.InfoCard {
               title: "42"
               subtitle: i18nc("@info:Number of Posts", "Posts")
           },
           FormCard.FormGridContainer.InfoCard {
               title: "42"
               subtitle: i18nc("@info:Number of followers.", "Followers")
           }
       ]
   }
   \endqml

   \qml
   import org.kde.kirigamiaddons.formcard as FormCard

   FormCard.FormGridContainer {
       FormCard.FormTextDelegate {
           text: "Name"
       }
       FormCard.FormSwitchDelegate {
           text: "Enable notifications"
       }
   }
   \endqml

   \since 0.11.0
 */
Item {
    id: root

    /*!
       The form delegates displayed in the container. When left empty,
       controls added as children are included, even after construction.
     */
    property list<Item> delegates // TODO KF7 make it default

    /*! \internal \brief The component used to draw each card surface. */
    property Component _backgroundDelegate

    /*! \internal \brief The border inset reserved around each delegate. */
    property real _borderWidth: 0

    /*! \internal \brief The corner radius shared by the surfaces and delegate backgrounds. */
    property real _cornerRadius: 0

    /*! \internal \brief The minimum space between the grid and either side of the container. */
    property real _horizontalInset: 0

    property bool _collectChildControls: false

    function _appendChildControls(): void {
        if (!root._collectChildControls) {
            return;
        }

        const newControls = root.children.filter(child => child instanceof T.Control && !root.delegates.includes(child));
        if (newControls.length > 0) {
            root.delegates = [...root.delegates, ...newControls];
        }
    }

    Component.onCompleted: {
        root._collectChildControls = root.delegates.length === 0;
        root._appendChildControls();
    }

    onChildrenChanged: root._appendChildControls()

    readonly property bool hasDelegates: delegates.length > 0

    // Internal: the delegates that currently have `visible` set to `true`, used to
    // lay out the grid and compute column spans while skipping hidden delegates.
    readonly property var _visibleDelegates: root.delegates.filter(delegate => delegate.visible)

    /*!
       This property holds the maximum width of the grid.
       \default Kirigami.Units.gridUnit * 30
     */
    property real maximumWidth: Kirigami.Units.gridUnit * 30

    /*!
       \qmlproperty real padding
       \qmlproperty real verticalPadding
       \qmlproperty real horizontalPadding
       \qmlproperty real topPadding
       \qmlproperty real bottomPadding
       \qmlproperty real leftPadding
       \qmlproperty real rightPadding
       \brief Padding property used around the content edges.
       \default 0
     */
    property real padding: 0
    property real verticalPadding: padding
    property real horizontalPadding: padding
    property real topPadding: verticalPadding
    property real bottomPadding: verticalPadding
    property real leftPadding: horizontalPadding
    property real rightPadding: horizontalPadding

    /*!
       This property holds whether the card's width is being restricted.
     */
    readonly property bool cardWidthRestricted: root.width > root.maximumWidth

    /*!
       This property holds the InfoCards which should be displayed.

       Each InfoCard contains a title and an optional subtitle

       \qml
       import org.kde.kirigamiaddons.formcard as FormCard

       FormCard.FormGridContainer {
           infoCards: [
               FormCard.FormGridContainer.InfoCard {
                   title: "42"
                   subtitle: i18nc("@info:Number of Posts", "Posts")
               },
               FormCard.FormGridContainer.InfoCard {
                   title: "42"
               },
               FormCard.FormGridContainer.InfoCard {
                   title: "Details"
                   action: Kirigami.Action {
                       onClicked: pageStack.push("Details.qml")
                   }
               }
           ]
       }
       \endqml

       \deprecated Use direct form delegates instead.
     */
    property list<QtObject> infoCards

    /*!
       A legacy data object used by the deprecated \c infoCards property.

       \deprecated Use direct form delegates instead.
     */
    component InfoCard: QtObject {
        property bool visible: true
        property string title
        property string subtitle
        property string buttonIcon
        property string tooltipText
        property int subtitleTextFormat: Text.AutoText
        property Kirigami.Action action
    }

    Kirigami.Theme.colorSet: Kirigami.Theme.View
    Kirigami.Theme.inherit: false

    Layout.fillWidth: true

    implicitHeight: topPadding + bottomPadding + (hasDelegates ? delegateGrid.implicitHeight : infoGrid.implicitHeight)

    GridLayout {
        id: delegateGrid

        visible: root.hasDelegates
        anchors {
            fill: parent
            leftMargin: Math.max(root._horizontalInset, root.cardWidthRestricted ? Math.round((root.width - root.maximumWidth) / 2) : 0) + root.leftPadding
            rightMargin: Math.max(root._horizontalInset, root.cardWidthRestricted ? Math.round((root.width - root.maximumWidth) / 2) : 0) + root.rightPadding
            topMargin: root.topPadding
            bottomMargin: root.bottomPadding
        }
        columns: 2
        columnSpacing: Kirigami.Units.smallSpacing
        rowSpacing: Kirigami.Units.smallSpacing

        Repeater {
            model: root.delegates

            Item {
                id: cell

                required property int index
                readonly property Item delegateItem: root.delegates[index]

                visible: delegateItem?.visible ?? true

                implicitWidth: delegateItem?.implicitWidth ?? 0
                implicitHeight: delegateItem?.implicitHeight ?? 0

                Layout.preferredWidth: Kirigami.Units.gridUnit * 10
                Layout.columnSpan: root._visibleDelegates.length % 2 !== 0 && cell.delegateItem === root._visibleDelegates[root._visibleDelegates.length - 1] ? 2 : 1
                Layout.fillWidth: true
                Layout.fillHeight: true

                Loader {
                    anchors.fill: parent
                    anchors.leftMargin: root.cardWidthRestricted ? 0 : -root._borderWidth
                    anchors.rightMargin: root.cardWidthRestricted ? 0 : -root._borderWidth
                    sourceComponent: root._backgroundDelegate
                }

                FormCard.ContentItemLoader {
                    id: delegateLoader

                    readonly property real _cornerRadius: root._cornerRadius
                    readonly property Item _firstVisibleItem: cell.delegateItem
                    readonly property Item _lastVisibleItem: cell.delegateItem

                    // Keep the delegate outside the cell so hiding the cell does not
                    // change the delegate visibility that the cell depends on.
                    parent: root
                    x: delegateGrid.x + cell.x + root._borderWidth
                    y: delegateGrid.y + cell.y + root._borderWidth
                    width: Math.max(0, cell.width - root._borderWidth * 2)
                    height: Math.max(0, cell.height - root._borderWidth * 2)
                    contentItem: cell.delegateItem
                }
            }
        }
    }

    FormCard.FormInfoGrid {
        id: infoGrid

        visible: !root.hasDelegates
        maximumWidth: root.maximumWidth
        leftPadding: root.leftPadding
        rightPadding: root.rightPadding
        topPadding: root.topPadding
        bottomPadding: root.bottomPadding
        cardWidthRestricted: root.cardWidthRestricted
        infoCards: root.infoCards
        backgroundDelegate: root._backgroundDelegate
        borderWidth: root._borderWidth
        cornerRadius: root._cornerRadius

        anchors {
            top: parent.top
            bottom: parent.bottom
            left: parent.left
            right: parent.right

            leftMargin: Math.max(root._horizontalInset, root.cardWidthRestricted ? Math.round((root.width - root.maximumWidth) / 2) : 0)
            rightMargin: Math.max(root._horizontalInset, root.cardWidthRestricted ? Math.round((root.width - root.maximumWidth) / 2) : 0)
        }

    }
}
