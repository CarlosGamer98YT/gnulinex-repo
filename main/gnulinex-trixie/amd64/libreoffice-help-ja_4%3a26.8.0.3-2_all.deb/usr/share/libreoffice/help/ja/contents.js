document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">文書ドキュメント(Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice Writer ヘルプへようこそ</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writerの機能</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice Writer の手引き</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">ウィンドウのドッキングやサイズ変更をする</a></li>\
    <li><a target="_top" href="ja/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writer のショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/words_count.html?DbPAR=WRITER">文字数の計算</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/keyboard.html?DbPAR=WRITER">ショートカットキーの使用法 (LibreOffice Writer アクセシビリティ)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">コマンドとメニューリファレンス</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">メニュー</label><ul>\
    <li><a target="_top" href="ja/text/swriter/main0100.html?DbPAR=WRITER">メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/menu/PickList.html?DbPAR=WRITER">[ファイル]メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/main_edit.html?DbPAR=WRITER">Edit</a></li>\
    <li><a target="_top" href="ja/text/shared/main0103.html?DbPAR=WRITER">表示</a></li>\
    <li><a target="_top" href="ja/text/shared/main0104.html?DbPAR=WRITER">Insert</a></li>\
    <li><a target="_top" href="ja/text/shared/main_format.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="ja/text/shared/menu/style_menu.html?DbPAR=WRITER">スタイル（メニュー）</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0110.html?DbPAR=WRITER">表</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="ja/text/shared/main_tools.html?DbPAR=WRITER">Main Tools Menu</a></li>\
    <li><a target="_top" href="ja/text/shared/main0107.html?DbPAR=WRITER">Window</a></li>\
    <li><a target="_top" href="ja/text/shared/main0108.html?DbPAR=WRITER">ヘルプ</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">ツールバー</label><ul>\
    <li><a target="_top" href="ja/text/swriter/main0200.html?DbPAR=WRITER">ツールバー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0206.html?DbPAR=WRITER">箇条書きと番号付けバー</a></li>\
    <li><a target="_top" href="ja/text/shared/01/classificationbar.html?DbPAR=WRITER">Classification Bar</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0210.html?DbPAR=WRITER">図形描画 バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0205.html?DbPAR=WRITER">図形描画オブジェクトのプロパティバー</a></li>\
    <li><a target="_top" href="ja/text/shared/02/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="ja/text/shared/02/fontwork_toolbar.html?DbPAR=WRITER">Fontwork</a></li>\
    <li><a target="_top" href="ja/text/shared/02/01170000.html?DbPAR=WRITER">フォームコントロール</a></li>\
    <li><a target="_top" href="ja/text/shared/main0226.html?DbPAR=WRITER">フォームデザイン ツールバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0213.html?DbPAR=WRITER">フォームナビゲーションバー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0202.html?DbPAR=WRITER">書式設定バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0214.html?DbPAR=WRITER">数式バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0215.html?DbPAR=WRITER">枠バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0203.html?DbPAR=WRITER">画像バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/02/18010000.html?DbPAR=WRITER">挿入</a></li>\
    <li><a target="_top" href="ja/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo ツールバー</a></li>\
    <li><a target="_top" href="ja/text/swriter/mailmergetoolbar.html?DbPAR=WRITER">差し込み印刷 ツールバー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="ja/text/shared/main0214.html?DbPAR=WRITER">クエリーデザイン バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0213.html?DbPAR=WRITER">ルーラー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0201.html?DbPAR=WRITER">標準バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0204.html?DbPAR=WRITER">表バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0212.html?DbPAR=WRITER">表データ バー</a></li>\
    <li><a target="_top" href="ja/text/swriter/main0220.html?DbPAR=WRITER">テキストオブジェクトバー</a></li>\
    <li><a target="_top" href="ja/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">文書ドキュメントのナビゲート</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">キーボードによる移動および選択操作</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">ドキュメント内でテキストを移動またはコピーする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">ナビゲーターを使用したドキュメントの操作</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">ナビゲーターを用いてハイパーリンクを挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/navigator.html?DbPAR=WRITER">文書ドキュメントのナビゲーター</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">ダイレクトカーソルを使用する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">文書ドキュメントの書式設定</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/pageorientation.html?DbPAR=WRITER">ページの方向を変更する (縦長または横長)</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_capital.html?DbPAR=WRITER">アルファベットを大文字または小文字に変換する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/hidden_text.html?DbPAR=WRITER">テキストを非表示にする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">複数のヘッダーやフッターを使い分ける</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">ヘッダーやフッターに章タイトルや章番号を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">テキスト入力時に書式設定を施す</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/reset_format.html?DbPAR=WRITER">フォントの書式をリセットする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">水やりモードを用いたスタイルの適用</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/wrap.html?DbPAR=WRITER">オブジェクトの周囲で文書を折り返す</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_centervert.html?DbPAR=WRITER">枠を用いてテキストをページ中央に配置する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">テキストを強調表示する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_rotate.html?DbPAR=WRITER">テキストを回転させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/page_break.html?DbPAR=WRITER">改ページ記号の挿入または削除をする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ページスタイルを適用または新規作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/subscript.html?DbPAR=WRITER">テキストの上付きおよび下付き表示</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">テンプレートとスタイル</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/templates_styles.html?DbPAR=WRITER">テンプレートとスタイル</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">奇数ページと偶数ページでページスタイルを使い分ける</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/change_header.html?DbPAR=WRITER">現在のページを基にページスタイルを作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/load_styles.html?DbPAR=WRITER">他のドキュメントやテンプレートからのスタイルの流用</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">選択内容を基に新規スタイルを作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/stylist_update.html?DbPAR=WRITER">選択内容を基に新規スタイルを更新する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/spotlight_styles.html?DbPAR=WRITER">Spotlight Styles</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">文書ドキュメントでの画像の使用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">図を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">他のファイルから画像を挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/gallery_insert.html?DbPAR=WRITER">ギャラリーからオブジェクトを挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">スキャナーで取り込んだ画像を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Calc のグラフを文書ドキュメントに挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">LibreOffice Draw や Impress から図を挿入する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">文書ドキュメントでの表の使用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">表セルの数字の認識機能をオフにする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/tablemode.html?DbPAR=WRITER">キーボード操作で表の行と列を変更する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/table_delete.html?DbPAR=WRITER">表の本体および内容の削除</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/table_insert.html?DbPAR=WRITER">表の挿入</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">新規ページでの表の見出し行の再表示</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/table_sizing.html?DbPAR=WRITER">テキストテーブルの行と列のサイズを変更する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">文書ドキュメントでのオブジェクトの使用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/anchor_object.html?DbPAR=WRITER">オブジェクトの位置決め</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/wrap.html?DbPAR=WRITER">オブジェクトの周囲で文書を折り返す</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">文書ドキュメントでのセクションおよびフレームの使用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/sections.html?DbPAR=WRITER">セクションを使用する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/section_edit.html?DbPAR=WRITER">セクションの編集</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/section_insert.html?DbPAR=WRITER">セクションの挿入</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">目次と索引</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">ユーザー定義の索引</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_toc.html?DbPAR=WRITER">目次を作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_index.html?DbPAR=WRITER">索引を作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">複数ドキュメントを対象にした索引を作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_literature.html?DbPAR=WRITER">参考文献表を作成する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_delete.html?DbPAR=WRITER">目次や索引の項目を編集または削除する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_edit.html?DbPAR=WRITER">目次や索引の更新、編集、削除をする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_enter.html?DbPAR=WRITER">目次や索引の項目を登録する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/indices_form.html?DbPAR=WRITER">目次および索引の表示スタイルを設定する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">文書ドキュメントでのフィールドの使用</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/fields.html?DbPAR=WRITER">フィールドについて</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/fields_date.html?DbPAR=WRITER">日付フィールド (自動更新および固定表示) を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/field_convert.html?DbPAR=WRITER">フィールドをテキストに変換する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/contentcontrols.html?DbPAR=WRITER">Using Content Controls in LibreOffice Writer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">文書ドキュメントでの計算の実行</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">複数の表の間で計算をする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate.html?DbPAR=WRITER">文書ドキュメント上で計算を実行する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">文書ドキュメント上で計算を実行し結果を貼り付ける</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">表セル内の数値を合計する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">文書ドキュメント上で数式を計算させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">表の計算結果を、他のドキュメントで表示させる</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">特殊なテキスト要素</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/captions.html?DbPAR=WRITER">キャプションの使用</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/conditional_text.html?DbPAR=WRITER">条件付きテキスト</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">ページ総数と条件付きテキストを併用した例</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/fields_date.html?DbPAR=WRITER">日付フィールド (自動更新および固定表示) を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/fields_enter.html?DbPAR=WRITER">入力フィールドを挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">次ページのページ番号を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">フッターにページ番号を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/hidden_text.html?DbPAR=WRITER">テキストを非表示にする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">複数のヘッダーやフッターを使い分ける</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">ヘッダーやフッターに章タイトルや章番号を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">ユーザーデータをフィールドなどの条件式で使用する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">脚注と文末脚注の挿入と編集</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">脚注間の間隔</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_footer.html?DbPAR=WRITER">ヘッダーとフッターを使用する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/header_with_line.html?DbPAR=WRITER">ヘッダーおよびフッターの書式設定をする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/text_animation.html?DbPAR=WRITER">テキストアニメーションを使う</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">差し込み印刷を行う</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">自動機能</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">例外をオートコレクトのリストに追加する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/autotext.html?DbPAR=WRITER">入力支援を使用する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">入力中に番号付けや箇条書きリストを自動処理させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/auto_off.html?DbPAR=WRITER">オートコレクトを無効にする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">スペルチェックを自動実行させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">表セルの数字の認識機能をオフにする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Using Hyphenation</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">番号付けと箇条書き</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Adding Heading Numbers to Captions</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">入力中に番号付けや箇条書きリストを自動処理させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">番号付けリストの結合</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">行番号を表示する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/number_sequence.html?DbPAR=WRITER">連番を設定する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">番号付け表示にする</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">箇条書き表示にする</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">スペルチェック、類義語辞典、言語</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">スペルチェックを自動実行させる</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">ユーザー辞書の登録単語を削除する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">類義語辞典</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">スペルと文法をチェックする</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">トラブルシューティングのヒント</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insert Text Before a Table at the Top of Page</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">特定のブックマークに移動する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">読み込み、保存、インポート、エクスポート、墨消し</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/send2html.html?DbPAR=WRITER">文書ドキュメントを HTML 形式で保存する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/markdown.html?DbPAR=WRITER">Markdown</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">文書ドキュメント全体を挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/auto_redact.html?DbPAR=WRITER">自動墨消し</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">マスタードキュメント</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/globaldoc.html?DbPAR=WRITER">マスタードキュメントとサブドキュメント</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">リンクと参照</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/references.html?DbPAR=WRITER">相互参照を挿入する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">ナビゲーターを用いてハイパーリンクを挿入する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">印刷</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/printer_tray.html?DbPAR=WRITER">用紙トレイを指定する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/print_preview.html?DbPAR=WRITER">印刷の実行前にプレビューを確認する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/print_small.html?DbPAR=WRITER">複数のページを 1 枚の用紙に印刷する</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ページスタイルを適用または新規作成する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">検索と置換</label><ul>\
    <li><a target="_top" href="ja/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="ja/text/shared/01/02100001.html?DbPAR=WRITER">正規表現のリスト</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTMLドキュメント(Writer Web)</label><ul>\
    <li><a target="_top" href="ja/text/shared/07/09000000.html?DbPAR=WRITER">Webページ</a></li>\
    <li><a target="_top" href="ja/text/shared/02/01170700.html?DbPAR=WRITER">HTML フィルターおよびフォーム</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/send2html.html?DbPAR=WRITER">文書ドキュメントを HTML 形式で保存する</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">表計算ドキュメント(Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/scalc/main0000.html?DbPAR=CALC">LibreOffice Calc ヘルプへようこそ</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc の機能</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/keyboard.html?DbPAR=CALC">ショートカットキー (LibreOffice Calc アクセシビリティ)</a></li>\
    <li><a target="_top" href="ja/text/scalc/04/01020000.html?DbPAR=CALC">表計算ドキュメントのショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="ja/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calcのエラーコード</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice Calc のプログラミング用アドイン</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice Calc の手引き</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">コマンドとメニューリファレンス</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">メニュー</label><ul>\
    <li><a target="_top" href="ja/text/scalc/main0100.html?DbPAR=CALC">メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/menu/PickList.html?DbPAR=CALC">[ファイル]メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/main_edit.html?DbPAR=CALC">Edit</a></li>\
    <li><a target="_top" href="ja/text/shared/main0103.html?DbPAR=CALC">表示</a></li>\
    <li><a target="_top" href="ja/text/shared/main0104.html?DbPAR=CALC">Insert</a></li>\
    <li><a target="_top" href="ja/text/shared/main_format.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0116.html?DbPAR=CALC">シート</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0112.html?DbPAR=CALC">データ</a></li>\
    <li><a target="_top" href="ja/text/shared/main_tools.html?DbPAR=CALC">Main Tools Menu</a></li>\
    <li><a target="_top" href="ja/text/shared/main0107.html?DbPAR=CALC">Window</a></li>\
    <li><a target="_top" href="ja/text/shared/main0108.html?DbPAR=CALC">ヘルプ</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">ツールバー</label><ul>\
    <li><a target="_top" href="ja/text/scalc/main0200.html?DbPAR=CALC">ツールバー</a></li>\
    <li><a target="_top" href="ja/text/shared/02/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0202.html?DbPAR=CALC">書式設定バー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0203.html?DbPAR=CALC">図形描画オブジェクトのプロパティバー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0205.html?DbPAR=CALC">テキストの書式設定バー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0206.html?DbPAR=CALC">数式バー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0208.html?DbPAR=CALC">ステータスバー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0210.html?DbPAR=CALC">印刷プレビューバー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0214.html?DbPAR=CALC">画像バー</a></li>\
    <li><a target="_top" href="ja/text/scalc/main0218.html?DbPAR=CALC">ツールバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0201.html?DbPAR=CALC">標準バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0212.html?DbPAR=CALC">表データ バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0213.html?DbPAR=CALC">フォームナビゲーションバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0214.html?DbPAR=CALC">クエリーデザイン バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0226.html?DbPAR=CALC">フォームデザイン ツールバー</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">関数の種類と演算子</label><ul>\
    <li><a target="_top" href="ja/text/scalc/01/04060000.html?DbPAR=CALC">関数ウィザード</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060100.html?DbPAR=CALC">カテゴリー別の関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060107.html?DbPAR=CALC">行列関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060120.html?DbPAR=CALC">ビット演算関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060101.html?DbPAR=CALC">データベース関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060102.html?DbPAR=CALC">日付と時刻関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060103.html?DbPAR=CALC">財務関数 1</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060119.html?DbPAR=CALC">財務関数 2</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060118.html?DbPAR=CALC">財務関数 3</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060104.html?DbPAR=CALC">情報関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060105.html?DbPAR=CALC">論理関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060106.html?DbPAR=CALC">数学関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060108.html?DbPAR=CALC">統計関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060181.html?DbPAR=CALC">統計関数 1</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060182.html?DbPAR=CALC">統計関数 2</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060183.html?DbPAR=CALC">統計関数 3</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060184.html?DbPAR=CALC">統計関数 4</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060185.html?DbPAR=CALC">統計関数 5</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060109.html?DbPAR=CALC">表計算ドキュメントの関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060110.html?DbPAR=CALC">テキスト関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060111.html?DbPAR=CALC">アドイン関数</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060115.html?DbPAR=CALC">アドイン関数、分析関数のリスト 1</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060116.html?DbPAR=CALC">アドイン関数、分析関数のリスト 2</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice Calc で使える演算子</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/userdefined_function.html?DbPAR=CALC">関数をユーザーが定義する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">読み込み、保存、インポート、エクスポート、墨消し</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/webquery.html?DbPAR=CALC">外部データを表に挿入する (WebQuery)</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/html_doc.html?DbPAR=CALC">シートを HTML として保存し、開く</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/csv_formula.html?DbPAR=CALC">テキスト形式のデータのインポートとエクスポート</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/auto_redact.html?DbPAR=CALC">自動墨消し</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">書式設定</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/text_rotate.html?DbPAR=CALC">テキストを回転させる</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/text_wrap.html?DbPAR=CALC">テキストを複数行にする</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/text_numbers.html?DbPAR=CALC">数をテキスト書式に設定する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/super_subscript.html?DbPAR=CALC">テキストの上付き、下付き</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/row_height.html?DbPAR=CALC">行の高さと列の幅を変更する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">条件付き書式設定を使う</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">マイナス値を強調表示する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">数式を使って書式を割り当てる</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">ゼロで始まる数を入力する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/format_table.html?DbPAR=CALC">表計算ドキュメント書式設定する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/format_value.html?DbPAR=CALC">小数で表された数値を書式設定する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/value_with_name.html?DbPAR=CALC">セルに名前を付ける</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/table_rotate.html?DbPAR=CALC">表の回転 (入れ替え)</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/rename_table.html?DbPAR=CALC">シートの名前を変更する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/year2000.html?DbPAR=CALC">年数 19xx/20xx</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">四捨五入された数値を使う</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/currency_format.html?DbPAR=CALC">通貨書式のセル</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/autoformat.html?DbPAR=CALC">表のオートフォーマットを使う</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/note_insert.html?DbPAR=CALC">コメントの挿入と編集</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/design.html?DbPAR=CALC">シートのテーマを選択する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/fraction_enter.html?DbPAR=CALC">分数を入力する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">フィルターや並び替え</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/filters.html?DbPAR=CALC">フィルターの適用</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/autofilter.html?DbPAR=CALC">オートフィルターを使う</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/sorted_list.html?DbPAR=CALC">順序リストを使う</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">印刷</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/print_title_row.html?DbPAR=CALC">行または列を全ページに繰り返して印刷する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/print_landscape.html?DbPAR=CALC">シートを横書式で印刷する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/print_details.html?DbPAR=CALC">シートの詳細を印刷する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/print_exact.html?DbPAR=CALC">印刷ページ数を指定する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">データの範囲</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/database_define.html?DbPAR=CALC">データベース範囲を定義する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/database_filter.html?DbPAR=CALC">セル範囲のフィルタリング</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/database_sort.html?DbPAR=CALC">データのソート</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">ピボットテーブル</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot.html?DbPAR=CALC">ピボットテーブル</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">ピボットテーブルを作成する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">ピボットテーブルを削除する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">ピボットテーブルを編集する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">ピボットテーブルをフィルターする</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">ピボットテーブルの出力範囲を選択する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">ピボットテーブルを更新する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">ピボットグラフ</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart.html?DbPAR=CALC">ピボットグラフ</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08095"><label for="08095">Data Analysis</label><ul>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_sampling.html?DbPAR=CALC">Data Sampling in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_descriptive.html?DbPAR=CALC">Descriptive Statistics in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_anova.html?DbPAR=CALC">ANOVA</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_correlation.html?DbPAR=CALC">Data Correlation in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_covariance.html?DbPAR=CALC">Data Covariance in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_exposmooth.html?DbPAR=CALC">Exponential Smoothing in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_movingavg.html?DbPAR=CALC">Moving Average in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_regression.html?DbPAR=CALC">Regression Analysis</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_test_t.html?DbPAR=CALC">Paired t-test in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_test_f.html?DbPAR=CALC">F Test Statistics in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_test_z.html?DbPAR=CALC">Z Test Statistics in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_test_chisqr.html?DbPAR=CALC">Chi Square Statistics in Calc</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/statistics_fourier.html?DbPAR=CALC">Fourier Analysis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">シナリオ</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/scenario.html?DbPAR=CALC">シナリオを使用する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">小計</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">参照</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">セルの絶対参照と相対参照</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/r1c1syntax.html?DbPAR=CALC">R1C1 Syntax</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referencing a Cell in Another Sheet</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referencing URLs in other Sheets</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">ドラッグ＆ドロップによるセルの参照</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/address_auto.html?DbPAR=CALC">名前を参照として使う</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">表示、選択、コピー</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/table_view.html?DbPAR=CALC">表の表示方法の変更</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/formula_value.html?DbPAR=CALC">数式または値を表示する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/line_fix.html?DbPAR=CALC">行または列を見出しとして固定する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/multi_tables.html?DbPAR=CALC">シート見出しによる移動</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/edit_multitables.html?DbPAR=CALC">複数のシートへのコピー</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cellcopy.html?DbPAR=CALC">表示されているセルのみのコピー</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/mark_cells.html?DbPAR=CALC">複数のセルを選択する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/move_dragdrop.html?DbPAR=CALC">ドラッグ＆ドロップによるセルの移動</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">数式と計算</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/formulas.html?DbPAR=CALC">数式を使って計算する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/formula_copy.html?DbPAR=CALC">数式をコピーする</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/formula_enter.html?DbPAR=CALC">数式を入力する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/formula_value.html?DbPAR=CALC">数式または値を表示する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/calculate.html?DbPAR=CALC">表計算ドキュメントで計算する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/calc_date.html?DbPAR=CALC">日付と時刻を計算する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/calc_series.html?DbPAR=CALC">連続データを自動計算する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">時間差を計算する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/matrixformula.html?DbPAR=CALC">行列式を入力する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">保護</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/cell_protect.html?DbPAR=CALC">セルを変更から保護する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">セルの保護を解除する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Calcマクロの作成</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">その他</label><ul>\
    <li><a target="_top" href="ja/text/scalc/guide/auto_off.html?DbPAR=CALC">オートコレクトをオフにする</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/consolidate.html?DbPAR=CALC">データの統合</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/goalseek.html?DbPAR=CALC">ゴールシークを適用する</a></li>\
    <li><a target="_top" href="ja/text/scalc/01/solver.html?DbPAR=CALC">ソルバー</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/multioperation.html?DbPAR=CALC">複数演算を適用する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/multitables.html?DbPAR=CALC">複数のシートに適用する</a></li>\
    <li><a target="_top" href="ja/text/scalc/guide/validity.html?DbPAR=CALC">セルの内容の入力規則</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">プレゼンテーション(Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/simpress/main0000.html?DbPAR=IMPRESS">LibreOffice Impress ヘルプへようこそ</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress の機能</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">LibreOffice Impress のショートカットキーの使用</a></li>\
    <li><a target="_top" href="ja/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impress のショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impress の手引き</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">コマンドとメニューリファレンス</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">メニュー</label><ul>\
    <li><a target="_top" href="ja/text/simpress/main0100.html?DbPAR=IMPRESS">メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/menu/PickList.html?DbPAR=IMPRESS">[ファイル]メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="ja/text/shared/main0103.html?DbPAR=IMPRESS">表示</a></li>\
    <li><a target="_top" href="ja/text/shared/main0104.html?DbPAR=IMPRESS">Insert</a></li>\
    <li><a target="_top" href="ja/text/shared/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="ja/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0114.html?DbPAR=IMPRESS">スライドショー</a></li>\
    <li><a target="_top" href="ja/text/shared/main_tools.html?DbPAR=IMPRESS">Main Tools Menu</a></li>\
    <li><a target="_top" href="ja/text/shared/main0107.html?DbPAR=IMPRESS">Window</a></li>\
    <li><a target="_top" href="ja/text/shared/main0108.html?DbPAR=IMPRESS">ヘルプ</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">ツールバー</label><ul>\
    <li><a target="_top" href="ja/text/simpress/main0200.html?DbPAR=IMPRESS">ツールバー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0210.html?DbPAR=IMPRESS">図形描画 バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0227.html?DbPAR=IMPRESS">制御点の編集 バー</a></li>\
    <li><a target="_top" href="ja/text/shared/02/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="ja/text/shared/main0226.html?DbPAR=IMPRESS">フォームデザイン ツールバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0213.html?DbPAR=IMPRESS">フォームナビゲーションバー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0214.html?DbPAR=IMPRESS">画像バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0202.html?DbPAR=IMPRESS">線と塗りつぶしバー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0213.html?DbPAR=IMPRESS">オプション バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0211.html?DbPAR=IMPRESS">アウトライン バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0209.html?DbPAR=IMPRESS">ルーラー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0212.html?DbPAR=IMPRESS">スライド一覧 バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0204.html?DbPAR=IMPRESS">スライドビュー バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0201.html?DbPAR=IMPRESS">標準バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0206.html?DbPAR=IMPRESS">ステータスバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0204.html?DbPAR=IMPRESS">表バー</a></li>\
    <li><a target="_top" href="ja/text/simpress/main0203.html?DbPAR=IMPRESS">テキストの書式設定 バー</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">読み込み、保存、インポート、エクスポート、墨消し</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML ページをプレゼンテーションにインポート</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">アニメーションのGIF形式でのエクスポート</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">図を挿入する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">自動墨消し</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">書式設定</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">線および矢印のスタイルの読み込み</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">ユーザー定義の色を定義する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">グラデーションを作成する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">色を置換する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">オブジェクトを整列、配置、および分布する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/background.html?DbPAR=IMPRESS">スライド背景の塗りつぶしの変更</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/footer.html?DbPAR=IMPRESS">すべてのスライドにヘッダーやフッターを追加</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/move_object.html?DbPAR=IMPRESS">オブジェクトの移動</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">印刷</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/printing.html?DbPAR=IMPRESS">プレゼンテーションの印刷</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">スライドを用紙サイズに合わせて印刷</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">機能</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">アニメーションのGIF形式でのエクスポート</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">プレゼンテーションスライド内のオブジェクトのアニメーション化</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">画面切り替えのアニメーション化</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">2 つのオブジェクト間でフェードアウトする</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">アニメーション化した GIF 画像の作成</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">オブジェクト、画像、ビットマップ</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">オブジェクトを組み合わせてシェイプを作る</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/groups.html?DbPAR=IMPRESS">オブジェクトのグループ化</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">扇形と切片を描画する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">オブジェクトを複製する</a></li>\
    <li><a target="_top" href="ja/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">オブジェクトを回転する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">立体オブジェクトを組み合わせる</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">線を接続する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">テキスト文字を図形描画オブジェクトに変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">ビットマップイメージをベクタグラフィックスに変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">2D オブジェクトから、曲線、多角形、立体オブジェクトへの変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">線および矢印のスタイルの読み込み</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">曲線を描画する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">曲線の編集</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">図を挿入する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/move_object.html?DbPAR=IMPRESS">オブジェクトの移動</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/select_object.html?DbPAR=IMPRESS">背後のオブジェクトを選択</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">フローチャートの作成</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">プレゼンテーション内のテキスト</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">テキストを追加する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">テキスト文字を図形描画オブジェクトに変換</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">表示</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">スライドの順番の変更</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">キーパッドを使用したズーム操作</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">スライドショー</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/show.html?DbPAR=IMPRESS">スライドショーの表示</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">プレゼンターコンソールの使用</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/individual.html?DbPAR=IMPRESS">目的別スライドショーの作成</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">スライドを切り替えるタイミングのリハーサル</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">図形描画(Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice Draw ヘルプへようこそ</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw の機能</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/keyboard.html?DbPAR=DRAW">図形描画オブジェクト用のショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/sdraw/04/01020000.html?DbPAR=DRAW">図形描画のショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw の使用上の注意点</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">コマンドとメニューリファレンス</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">メニュー</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/main0100.html?DbPAR=DRAW">メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/menu/PickList.html?DbPAR=DRAW">[ファイル]メニュー</a></li>\
    <li><a target="_top" href="ja/text/shared/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="ja/text/shared/main0103.html?DbPAR=DRAW">表示</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="ja/text/shared/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="ja/text/shared/main_tools.html?DbPAR=DRAW">Main Tools Menu</a></li>\
    <li><a target="_top" href="ja/text/shared/main0107.html?DbPAR=DRAW">Window</a></li>\
    <li><a target="_top" href="ja/text/shared/main0108.html?DbPAR=DRAW">ヘルプ</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">ツールバー</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/main0200.html?DbPAR=DRAW">ツールバー</a></li>\
    <li><a target="_top" href="ja/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D設定</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main0210.html?DbPAR=DRAW">図形描画 バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0227.html?DbPAR=DRAW">制御点の編集 バー</a></li>\
    <li><a target="_top" href="ja/text/shared/02/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="ja/text/shared/main0226.html?DbPAR=DRAW">フォームデザイン ツールバー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0213.html?DbPAR=DRAW">フォームナビゲーションバー</a></li>\
    <li><a target="_top" href="ja/text/sdraw/main0213.html?DbPAR=DRAW">オプション バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0201.html?DbPAR=DRAW">標準バー</a></li>\
    <li><a target="_top" href="ja/text/shared/main0204.html?DbPAR=DRAW">表バー</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">読み込み、保存、インポート、エクスポート</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">図を挿入する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">書式設定</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">線および矢印のスタイルの読み込み</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/color_define.html?DbPAR=DRAW">ユーザー定義の色を定義する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/gradient.html?DbPAR=DRAW">グラデーションを作成する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">色を置換する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">オブジェクトを整列、配置、および分布する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/background.html?DbPAR=DRAW">スライド背景の塗りつぶしの変更</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/move_object.html?DbPAR=DRAW">オブジェクトの移動</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">印刷</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/printing.html?DbPAR=DRAW">プレゼンテーションの印刷</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/print_tofit.html?DbPAR=DRAW">スライドを用紙サイズに合わせて印刷</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">効果</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">2 つのオブジェクト間でフェードアウトする</a></li>\
    <li><a target="_top" href="ja/text/shared/01/05350000.html?DbPAR=DRAW">3D効果</a></li>\
    <li><a target="_top" href="ja/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">オブジェクト、画像、ビットマップ</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">オブジェクトを組み合わせてシェイプを作る</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">扇形と切片を描画する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">オブジェクトを複製する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">オブジェクトを回転する</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">立体オブジェクトを組み合わせる</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/join_objects.html?DbPAR=DRAW">線を接続する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/text2curve.html?DbPAR=DRAW">テキスト文字を図形描画オブジェクトに変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/vectorize.html?DbPAR=DRAW">ビットマップイメージをベクタグラフィックスに変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/3d_create.html?DbPAR=DRAW">2D オブジェクトから、曲線、多角形、立体オブジェクトへの変換</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">線および矢印のスタイルの読み込み</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_draw.html?DbPAR=DRAW">曲線を描画する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/line_edit.html?DbPAR=DRAW">曲線の編集</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">図を挿入する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/table_insert.html?DbPAR=DRAW">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/move_object.html?DbPAR=DRAW">オブジェクトの移動</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/select_object.html?DbPAR=DRAW">背後のオブジェクトを選択</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/orgchart.html?DbPAR=DRAW">フローチャートの作成</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">グループとレイヤー</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/groups.html?DbPAR=DRAW">オブジェクトのグループ化</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="ja/text/sdraw/01/insert_layer.html?DbPAR=DRAW">レイヤーの挿入</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="ja/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">図形描画内のテキスト</label><ul>\
    <li><a target="_top" href="ja/text/sdraw/guide/text_enter.html?DbPAR=DRAW">テキストを追加する</a></li>\
    <li><a target="_top" href="ja/text/simpress/guide/text2curve.html?DbPAR=DRAW">テキスト文字を図形描画オブジェクトに変換</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">表示</label><ul>\
    <li><a target="_top" href="ja/text/simpress/guide/change_scale.html?DbPAR=DRAW">キーパッドを使用したズーム操作</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">データベース機能(Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">概要</label><ul>\
    <li><a target="_top" href="ja/text/sdatabase/main.html?DbPAR=BASE">LibreOffice データベース</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/database_main.html?DbPAR=BASE">データベースの概要</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_new.html?DbPAR=BASE">データベースの新規作成</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_tables.html?DbPAR=BASE">テーブルの使い方</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_queries.html?DbPAR=BASE">クエリーの使い方</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_forms.html?DbPAR=BASE">フォームの使い方</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_reports.html?DbPAR=BASE">レポートの作成</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_register.html?DbPAR=BASE">データベースの登録と削除</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_im_export.html?DbPAR=BASE">Base でのデータのインポート/エクスポート</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQLコマンドの実行</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">数式(Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/smath/main0000.html?DbPAR=MATH">LibreOffice Math ヘルプへようこそ</a></li>\
    <li><a target="_top" href="ja/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math の使い方</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOfficeの数式の要素</label><ul>\
    <li><a target="_top" href="ja/text/smath/01/03090100.html?DbPAR=MATH">単項演算子と二項演算子</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090200.html?DbPAR=MATH">比較</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090800.html?DbPAR=MATH">集合演算子</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090400.html?DbPAR=MATH">関数</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090300.html?DbPAR=MATH">演算子</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090600.html?DbPAR=MATH">属性</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090500.html?DbPAR=MATH">かっこ</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03090700.html?DbPAR=MATH">書式</a></li>\
    <li><a target="_top" href="ja/text/smath/01/03091600.html?DbPAR=MATH">その他</a></li>\
      </ul></li>\
    <li><a target="_top" href="ja/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Math の手引き</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/keyboard.html?DbPAR=MATH">ショートカットキー（LibreOffice Math アクセシビリティ）</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">コマンドとメニューリファレンス</label><ul>\
    <li><a target="_top" href="ja/text/smath/main0100.html?DbPAR=MATH">メニュー</a></li>\
    <li><a target="_top" href="ja/text/smath/main0200.html?DbPAR=MATH">ツールバー</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">数式の使い方</label><ul>\
    <li><a target="_top" href="ja/text/smath/guide/align.html?DbPAR=MATH">数式の一部を任意に配置する</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/attributes.html?DbPAR=MATH">標準属性を変更する</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/brackets.html?DbPAR=MATH">数式部分をかっこでまとめる</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/comment.html?DbPAR=MATH">コメントを入力する</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/newline.html?DbPAR=MATH">改行する</a></li>\
    <li><a target="_top" href="ja/text/smath/guide/parentheses.html?DbPAR=MATH">かっこを入力する</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">グラフと図表</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">概要</label><ul>\
    <li><a target="_top" href="ja/text/schart/main0000.html?DbPAR=CHART">LibreOffice のグラフ</a></li>\
    <li><a target="_top" href="ja/text/schart/main0503.html?DbPAR=CHART">LibreOffice グラフの機能</a></li>\
    <li><a target="_top" href="ja/text/schart/04/01020000.html?DbPAR=CHART">グラフのショートカットキー</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">マクロとスクリプト</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basicヘルプ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01000000.html?DbPAR=BASIC">LibreOffice Basicのプログラミング</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic用語集</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01010210.html?DbPAR=BASIC">基本</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020000.html?DbPAR=BASIC">構文</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE の概要</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basicエディター</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01050100.html?DbPAR=BASIC">オブザーバウィンドウ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/main0211.html?DbPAR=BASIC">マクロ ツールバー</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/05060700.html?DbPAR=BASIC">マクロ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">VBAマクロのサポート</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">コマンドリファレンス</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020500.html?DbPAR=BASIC">ライブラリ、モジュール、ダイアログ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">関数、ステートメント、演算子</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100000.html?DbPAR=BASIC">変数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060000.html?DbPAR=BASIC">論理演算子</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120000.html?DbPAR=BASIC">文字列</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030000.html?DbPAR=BASIC">日付および時刻関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070000.html?DbPAR=BASIC">算術演算子</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080000.html?DbPAR=BASIC">数値関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080100.html?DbPAR=BASIC">三角関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010000.html?DbPAR=BASIC">画面入出力関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020000.html?DbPAR=BASIC">ファイル入出力関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090000.html?DbPAR=BASIC">プログラム実行の制御</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050000.html?DbPAR=BASIC">エラーを制御するための関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130000.html?DbPAR=BASIC">その他のコマンド</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080300.html?DbPAR=BASIC">乱数の生成</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/vba_objects.html?DbPAR=BASIC">VBA Supported Objects</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090400.html?DbPAR=BASIC">その他のステートメント</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">関数、ステートメント、演算子のアルファベット順リスト</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/CreateUnoSvcWithArgs.html?DbPAR=BASIC">CreateUnoServiceWithArguments Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/doEvents.html?DbPAR=BASIC">DoEvents Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050000.html?DbPAR=BASIC">エラーを制御するための関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp 関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03170020.html?DbPAR=BASIC">FormatPercent Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080000.html?DbPAR=BASIC">数値関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080400.html?DbPAR=BASIC">平方根の計算</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch関数</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03120300.html?DbPAR=BASIC">文字列の編集</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020100.html?DbPAR=BASIC">変数の使用法</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">高度なBasicライブラリ</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForgeライブラリ</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForgeライブラリ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_toc.html?DbPAR=BASIC">List of all ScriptForge methods and properties</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">ScriptForgeを利用したPythonスクリプトの作成</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><input type="checkbox" id="07010501"><label for="07010501">Example Scripts</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/guide/read_write_values.html?DbPAR=BASIC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/calc_borders.html?DbPAR=BASIC">Formatting Borders in Calc with Macros</a></li>\
            </ul></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_contextmenu.html?DbPAR=BASIC">SFWidgets.ContextMenu service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_dataset.html?DbPAR=BASIC">SFDatabases.Dataset service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_datasheet.html?DbPAR=BASIC">SFDatabases.Datasheet service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_formdocument.html?DbPAR=BASIC">SFDocuments.FormDocument service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_toolbar.html?DbPAR=BASIC">SFWidgets.Toolbar service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_toolbarbutton.html?DbPAR=BASIC">SFWidgets.ToolbarButton service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">ガイド</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/macro_recording.html?DbPAR=BASIC">マクロの記録</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/control_properties.html?DbPAR=BASIC">ダイアログエディターに配置したコントロールのプロパティの変更</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/insert_control.html?DbPAR=BASIC">ダイアログエディターでのコントロールの作成</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/sample_code.html?DbPAR=BASIC">ダイアログエディターでのコントロール制御用プログラミングの例</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Basicダイアログの作成</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01030400.html?DbPAR=BASIC">ライブラリとモジュールを準備しています</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020100.html?DbPAR=BASIC">変数の使用法</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01020200.html?DbPAR=BASIC">オブジェクトの使用法</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01030300.html?DbPAR=BASIC">Basicプログラムのデバッグ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/shared/01040000.html?DbPAR=BASIC">イベント駆動マクロについての文書</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">BasicからPythonの呼び出し</a></li>\
    <li><a target="_top" href="ja/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Pythonスクリプト ヘルプ</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">概要とユーザーインタフェースの利用</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/python/main0000.html?DbPAR=BASIC">Pythonスクリプト</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_ide.html?DbPAR=BASIC">Python向けIDE</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_locations.html?DbPAR=BASIC">Pythonスクリプトの管理</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/running_scripts.html?DbPAR=BASIC">Running Python Scripts</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python対話シェル</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Pythonによるプログラミング</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Pythonによるプログラミング</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_examples.html?DbPAR=BASIC">Pythonサンプル</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">PythonからBasicの呼び出し</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070203"><label for="070203">Pythonモジュール</label><ul>\
    <li><a target="_top" href="ja/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForgeライブラリ</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Pythonによるプログラミング</a></li>\
    <li><a target="_top" href="ja/text/sbasic/python/python_screen.html?DbPAR=BASIC">Python : 画面への入出力</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">スクリプト開発ツール</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOfficeのインストール</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office ドキュメントのファイルの関連付け設定</a></li>\
    <li><a target="_top" href="ja/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Troubleshoot Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">共通のヘルプ項目</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">概要</label><ul>\
    <li><a target="_top" href="ja/text/shared/main0400.html?DbPAR=SHARED">ショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/shared/00/00000005.html?DbPAR=SHARED">一般用語集</a></li>\
    <li><a target="_top" href="ja/text/shared/00/00000002.html?DbPAR=SHARED">インターネット用語集</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOfficeのユーザー補助機能</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/keyboard.html?DbPAR=SHARED">ショートカット (LibreOffice アクセシビリティ)</a></li>\
    <li><a target="_top" href="ja/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice の全般的なショートカットキー</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/version_number.html?DbPAR=SHARED">バージョンとビルド番号</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOfficeとMicrosoft Office</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/ms_user.html?DbPAR=SHARED">Microsoft Office と LibreOffice の併用</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Microsoft Office と LibreOffice での用語の比較</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office ドキュメントの変換について</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office ドキュメントのファイルの関連付け設定</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice オプション</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01000000.html?DbPAR=SHARED">オプション</a></li>\
    <li><input type="checkbox" id="100401"><label for="100401">LibreOffice</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01010100.html?DbPAR=SHARED">ユーザーデータ</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010600.html?DbPAR=SHARED">全般</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010800.html?DbPAR=SHARED">表示</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010900.html?DbPAR=SHARED">印刷オプション</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010300.html?DbPAR=SHARED">パス</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010700.html?DbPAR=SHARED">フォント</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01030300.html?DbPAR=SHARED">セキュリティ</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01013000.html?DbPAR=SHARED">アクセシビリティ</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100402"><label for="100402">読み込みと保存</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01010200.html?DbPAR=SHARED">全般</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA 属性</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01030500.html?DbPAR=SHARED">HTML 互換性</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100403"><label for="100403">言語とロケール</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01150000.html?DbPAR=SHARED">言語設定オプション</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01010400.html?DbPAR=SHARED">文章作成支援</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100404"><label for="100404">LibreOffice Writer</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01040000.html?DbPAR=SHARED">「文書ドキュメント」オプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100405"><label for="100405">LibreOffice Writer/Web</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01050000.html?DbPAR=SHARED">「HTML 形式ドキュメント」オプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100406"><label for="100406">LibreOffice Calc</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01060000.html?DbPAR=SHARED">表計算ドキュメントオプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100407"><label for="100407">LibreOffice Impress</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01070000.html?DbPAR=SHARED">プレゼンテーションのオプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100408"><label for="100408">LibreOffice Draw</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01080000.html?DbPAR=SHARED">図形描画オプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100409"><label for="100409">LibreOffice Math</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01090000.html?DbPAR=SHARED">数式</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100410"><label for="100410">LibreOffice Base</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01160000.html?DbPAR=SHARED">データソースのオプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100412"><label for="100412">グラフ</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01110000.html?DbPAR=SHARED">グラフのオプション</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100413"><label for="100413">インターネット</label><ul>\
    <li><a target="_top" href="ja/text/shared/optionen/01030000.html?DbPAR=SHARED">インターネットのオプション</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">ウィザード</label><ul>\
    <li><a target="_top" href="ja/text/shared/autopi/01000000.html?DbPAR=SHARED">ウィザード</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">レターウィザード</label><ul>\
    <li><a target="_top" href="ja/text/shared/autopi/01010000.html?DbPAR=SHARED">レターウィザード</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">ファックスウィザード</label><ul>\
    <li><a target="_top" href="ja/text/shared/autopi/01020000.html?DbPAR=SHARED">ファックスウィザード</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">アジェンダウィザード</label><ul>\
    <li><a target="_top" href="ja/text/shared/autopi/01040000.html?DbPAR=SHARED">アジェンダウィザード</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">ドキュメント変換ウィザード</label><ul>\
    <li><a target="_top" href="ja/text/shared/autopi/01130000.html?DbPAR=SHARED">ドキュメント変換</a></li>\
      </ul></li>\
    <li><a target="_top" href="ja/text/shared/autopi/01150000.html?DbPAR=SHARED">ユーロ通貨換算 ウィザード</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOfficeの設定</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice のユーザー設定</a></li>\
    <li><a target="_top" href="ja/text/shared/01/packagemanager.html?DbPAR=SHARED">拡張機能マネージャー</a></li>\
    <li><a target="_top" href="ja/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">ツールバーへのボタンの追加</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/workfolder.html?DbPAR=SHARED">作業用ディレクトリの変更</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_addressbook.html?DbPAR=SHARED">アドレス帳を登録する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/formfields.html?DbPAR=SHARED">ボタンを挿入して編集する</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">ユーザーインタフェースの使用法</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">オブジェクトを素早く見つけるナビゲーション</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/navigator.html?DbPAR=SHARED">ドキュメント概要のナビゲーター</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/autohide.html?DbPAR=SHARED">ウィンドウの表示、ドッキング、非表示</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/textmode_change.html?DbPAR=SHARED">挿入モードと上書きモードの切り替え</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">ツールバーの使用</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">デジタル署名</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/digital_signatures.html?DbPAR=SHARED">デジタル署名の使用法</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">デジタル署名の使用法</a></li>\
    <li><a target="_top" href="ja/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="ja/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="ja/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="ja/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="ja/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">印刷、Fax、送信</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/labels_database.html?DbPAR=SHARED">宛名ラベルの印刷</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">白黒で印刷</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/fax.html?DbPAR=SHARED">Fax の送信と LibreOffice の Fax 設定</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">ドラッグ＆ドロップ</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop.html?DbPAR=SHARED">LibreOffice ドキュメント内でのドラッグ＆ドロップ</a></li>\
    <li><a target="_top" href="ja/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">ドキュメント内でテキストを移動またはコピーする</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">表計算ドキュメント内の領域をテキストドキュメントへコピー</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">図をドキュメント間でコピー</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/gallery_insert.html?DbPAR=SHARED">ギャラリーからオブジェクトを挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">データソース表示でのドラッグ＆ドロップ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">コピーとペースト</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">図形描画オブジェクトを別のドキュメントにコピーする</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">図をドキュメント間でコピー</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/gallery_insert.html?DbPAR=SHARED">ギャラリーからオブジェクトを挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">表計算ドキュメント内の領域をテキストドキュメントへコピー</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">グラフと図表</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/chart_insert.html?DbPAR=SHARED">グラフの挿入</a></li>\
    <li><a target="_top" href="ja/text/schart/main0000.html?DbPAR=SHARED">LibreOffice のグラフ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">読み込み、保存、インポート、エクスポート、PDF</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/doc_open.html?DbPAR=SHARED">ドキュメントを開く</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/import_ms.html?DbPAR=SHARED">別の形式で保存されたドキュメントを開く</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/doc_save.html?DbPAR=SHARED">ドキュメントの保存</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/doc_autosave.html?DbPAR=SHARED">ドキュメントを自動的に保存する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/export_ms.html?DbPAR=SHARED">ドキュメントの別形式での保存</a></li>\
    <li><a target="_top" href="ja/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">PDFとしてエクスポートする</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">テキスト形式データをインポート/エクスポート</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">リンクと参照</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">ハイパーリンクを挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">絶対リンクと相対リンク</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">ハイパーリンクの編集</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">ドキュメントのバージョン管理</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">ドキュメントのバージョンの比較</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">各バージョンをマージ</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_enter.html?DbPAR=SHARED">変更記録</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining.html?DbPAR=SHARED">変更を記録して表示する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_accept.html?DbPAR=SHARED">変更の承認または却下</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_versions.html?DbPAR=SHARED">バージョン管理</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">ラベル書きと名刺</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/labels.html?DbPAR=SHARED">ラベル書きと名刺を作成して印刷</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">外部データの挿入</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/copytable2application.html?DbPAR=SHARED">表計算ドキュメントからのデータの挿入</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/copytext2application.html?DbPAR=SHARED">文書ドキュメントからのデータの挿入</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">ビットマップの挿入、編集、保存</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">ギャラリーへの図の追加</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">自動機能</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/autocorr_url.html?DbPAR=SHARED">自動 URL 識別の解除</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">検索と置換</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/data_search2.html?DbPAR=SHARED">フォームフィルターを使って検索</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_search.html?DbPAR=SHARED">表およびフォームドキュメントの検索</a></li>\
    <li><a target="_top" href="ja/text/shared/01/02100001.html?DbPAR=SHARED">正規表現のリスト</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">ガイド</label><ul>\
    <li><a target="_top" href="ja/text/shared/guide/linestyles.html?DbPAR=SHARED">線スタイルの適用</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/text_color.html?DbPAR=SHARED">テキストの色の変更</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/change_title.html?DbPAR=SHARED">ドキュメントのタイトルの変更</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/round_corner.html?DbPAR=SHARED">角を丸くする</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/background.html?DbPAR=SHARED">背景用の色または画像の設定</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/linestyle_define.html?DbPAR=SHARED">線スタイルを定義する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">図オブジェクトの編集</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/line_intext.html?DbPAR=SHARED">テキストに線を挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/aaa_start.html?DbPAR=SHARED">第1ステップ</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/gallery_insert.html?DbPAR=SHARED">ギャラリーからオブジェクトを挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">特殊文字を挿入する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/tabs.html?DbPAR=SHARED">タブストップの挿入と編集</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/protection.html?DbPAR=SHARED">LibreOffice の内容の保護</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/redlining_protect.html?DbPAR=SHARED">記録を保護する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/pageformat_max.html?DbPAR=SHARED">ページの最大印刷可能領域を選択</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/measurement_units.html?DbPAR=SHARED">測定単位の選択</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/language_select.html?DbPAR=SHARED">ドキュメントの言語を選択する</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">テーブルデザイン</a></li>\
    <li><a target="_top" href="ja/text/shared/guide/numbering_stop.html?DbPAR=SHARED">個別段落の箇条書きと番号付けをオフにする</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
