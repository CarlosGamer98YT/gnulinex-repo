# Shared functions for ucf and ucfr

warn () {
    echo "$@" >&2
}

vset() {
    # Value Doc_string
    if [ -z "$1" ]; then
	warn "$progname: Unable to determine $2"
	exit 1
    else
	if [ -n "$VERBOSE" ]; then
	    warn "$progname: $2 is $1"
	fi
	printf '%s' "$1"
    fi
}

withecho () {
	warn "$@"
	"$@"
}

escape_bre () {
    printf '%s' "$1" | sed -e 's#[.[\*^$]#\\&#g'
}
