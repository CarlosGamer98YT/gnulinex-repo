# -*- encoding: utf-8 -*-
# stub: rubygems-update 4.0.20 ruby hide_lib_for_update

Gem::Specification.new do |s|
  s.name = "rubygems-update".freeze
  s.version = "4.0.20".freeze

  s.required_rubygems_version = Gem::Requirement.new(">= 0".freeze) if s.respond_to? :required_rubygems_version=
  s.metadata = { "bug_tracker_uri" => "https://github.com/ruby/rubygems/issues", "changelog_uri" => "https://github.com/ruby/rubygems/blob/master/CHANGELOG.md", "funding_uri" => "https://rubycentral.org/#/portal/signup", "source_code_uri" => "https://github.com/ruby/rubygems" } if s.respond_to? :metadata=
  s.require_paths = ["hide_lib_for_update".freeze]
  s.authors = ["Jim Weirich".freeze, "Chad Fowler".freeze, "Eric Hodel".freeze, "Luis Lavena".freeze, "Aaron Patterson".freeze, "Samuel Giddins".freeze, "Andr\u00E9 Arko".freeze, "Evan Phoenix".freeze, "Hiroshi SHIBATA".freeze]
  s.bindir = "exe".freeze
  s.date = "2026-09-08"
  s.description = "A package (also known as a library) contains a set of functionality\n  that can be invoked by a Ruby program, such as reading and parsing an XML file. We call\n  these packages 'gems' and RubyGems is a tool to install, create, manage and load these\n  packages in your Ruby environment. RubyGems is also a client for RubyGems.org, a public\n  repository of Gems that allows you to publish a Gem that can be shared and used by other\n  developers. See our guide on publishing a Gem at guides.rubygems.org".freeze
  s.email = ["".freeze, "".freeze, "drbrain@segment7.net".freeze, "luislavena@gmail.com".freeze, "aaron@tenderlovemaking.com".freeze, "segiddins@segiddins.me".freeze, "andre@arko.net".freeze, "evan@phx.io".freeze, "hsbt@ruby-lang.org".freeze]
  s.executables = ["update_rubygems".freeze]
  s.files = ["exe/update_rubygems".freeze]
  s.homepage = "https://guides.rubygems.org".freeze
  s.licenses = ["Ruby".freeze, "MIT".freeze]
  s.rdoc_options = ["--main".freeze, "README.md".freeze, "--title=RubyGems Update Documentation".freeze]
  s.required_ruby_version = Gem::Requirement.new(">= 3.2.0".freeze)
  s.rubygems_version = "4.0.18".freeze
  s.summary = "RubyGems is a package management framework for Ruby. This gem is downloaded and installed by `gem update --system`, so that the `gem` CLI can update itself.".freeze

  s.installed_by_version = "4.0.18".freeze
end
