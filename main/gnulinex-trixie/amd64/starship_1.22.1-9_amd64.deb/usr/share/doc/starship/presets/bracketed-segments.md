[Return to Presets](./#bracketed-segments)

# Bracketed Segments Preset

This preset changes the format of all the built-in modules to show their segment
in brackets instead of using the default Starship wording ("via", "on", etc.).

![Screenshot of Bracketed Segments preset](/presets/img/bracketed-segments.png)

### Configuration

```sh
starship preset bracketed-segments -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/bracketed-segments.toml){download}

<<< @/public/presets/toml/bracketed-segments.toml
