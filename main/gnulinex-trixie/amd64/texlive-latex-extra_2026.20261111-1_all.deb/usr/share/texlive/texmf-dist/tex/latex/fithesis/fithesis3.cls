%%
%% This is file `fithesis3.cls',
%% generated with the docstrip utility.
%%
%% The original source files were:
%%
%% fithesis.dtx  (with options: `oldclass3')
%% 
%% Copyright 1998--2025  Daniel Marek (DM), Jan Pavlovič (JP),
%%                       Petr Sojka (PS), Vít Starý Novotný (VN),
%%                       Tereza Vrabcová (TV), Vlastislav Dohnal (VD)
%% http://www.fi.muni.cz/tech/unix/tex/fithesis.xhtml
%% Faculty of Informatics, Masaryk University (Brno, Czech Republic)
%% 
%% This work may be distributed and/or modified under the
%% conditions of the LaTeX Project Public License, either version
%% 1.3 of this license or (at your option) any later version.
%% The latest version of this license is available at
%% 
%%   http://www.latex-project.org/lppl.txt
%% 
%% and version 1.3 or later is part of all distributions of LaTeX
%% version 2005/12/01 or later.
%% 
%% This work has the LPPL maintenance status `maintained'.
%% 
%% The Current Maintainer of this work is Vít Starý Novotný (VN).
%% Send bug reports, requests for additions and questions
%% either to the fithesis discussion forum at
%% 
%%   http://is.muni.cz/auth/df/fithesis-sazba/
%% 
%% or to the e-mail address <witiko@mail.muni.cz>.
%% 
%% 
%% MODIFICATION ADVICE:
%% 
%% If you want to customize this file, it is best to make a copy of
%% the source file(s) from which it was produced.  Use a different
%% name for your copy(ies) and modify the copy(ies); this will ensure
%% that your modifications do not get overwritten when you install a
%% new release of the standard system.  You should also ensure that
%% your modified source file does not generate any modified file with
%% the same name as a standard file.
%% 
%% You will also need to produce your own, suitably named, .ins file to
%% control the generation of files from your source file; this file
%% should contain your own preambles for the files it generates, not
%% those in the standard .ins files.
%% 
%% The names of the source files used are shown above.
%% 

\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{oldfithesis3}[2018/11/17 old fithesis3 will load fithesis4 MU thesis class]

\ClassWarning{oldfithesis3}{%
  You are using the fithesis3 class, which has been deprecated.
  The fithesis4 class will be used instead.
  For more information, see <http://www.fi.muni.cz/tech/unix/tex/fithesis.xhtml>%
}\LoadClass{fithesis4}

\endinput
%%
%% End of file `fithesis3.cls'.
