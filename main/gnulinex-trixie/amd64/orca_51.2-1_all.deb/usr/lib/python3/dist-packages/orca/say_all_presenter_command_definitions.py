# Orca
#
# Copyright 2005-2009 Sun Microsystems Inc.
# Copyright 2011-2026 Igalia, S.L.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., Franklin Street, Fifth Floor,
# Boston MA  02110-1301 USA.

"""Command definitions for Say All."""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import cmdnames, keybindings
from .command import Command, KeyboardCommand
from .help_metadata import (
    CommandDoc,
    CommandGroupDoc,
)

if TYPE_CHECKING:
    from .say_all_presenter import SayAllPresenter


def get_documentation() -> CommandGroupDoc:
    """Returns documentation metadata for Say All commands."""

    return CommandGroupDoc(
        summary="Say All reads from the current location to the end of the document.",
        commands=(
            CommandDoc(
                "sayAllHandler",
                details=(
                    "Starts continuous presentation from the current location. Press a key to "
                    "interrupt it; enabled navigation options can instead move within the content."
                ),
            ),
        ),
    )


def get_commands(owner: SayAllPresenter) -> list[Command]:
    """Returns commands for Say All."""

    kb_unmodified_kp_add = keybindings.KeyBinding(
        "KP_Add",
        keybindings.NO_MODIFIER_MASK,
    )
    kb_orca_semicolon = keybindings.KeyBinding(
        "semicolon",
        keybindings.ORCA_MODIFIER_MASK,
    )

    return [
        KeyboardCommand(
            "sayAllHandler",
            owner.say_all,
            owner.GROUP_LABEL,
            cmdnames.SAY_ALL,
            desktop_keybinding=kb_unmodified_kp_add,
            laptop_keybinding=kb_orca_semicolon,
        ),
    ]
