# Orca
#
# Copyright 2011-2026 Igalia, S.L.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., Franklin Street, Fifth Floor,
# Boston MA  02110-1301 USA.

"""Preferences grid for chat support."""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import guilabels, preferences_grid_base
from .chat_presenter_settings import ChatMessageVerbosity, ChatSettings
from .help_metadata import (
    PreferenceCategoryDoc,
    PreferenceControlDoc,
    PreferencePanelDoc,
    PreferenceValueDoc,
)

if TYPE_CHECKING:
    from .chat_presenter import ChatPresenter


class ChatPreferencesGrid(preferences_grid_base.AutoPreferencesGrid):
    """Preferences grid for Chat settings."""

    _gsettings_schema = "chat"

    @classmethod
    def get_documentation(cls) -> PreferencePanelDoc:
        """Return documentation metadata for chat preferences."""

        return PreferencePanelDoc(
            title=guilabels.KB_GROUP_CHAT,
            panel_id="chat_presenter.chat",
            category=PreferenceCategoryDoc(
                category_id="chat",
                title="Chat",
                description=(
                    "Configure how Orca presents messages and participants in supported chat "
                    "applications."
                ),
                panels=("chat_presenter.chat",),
            ),
            command_groups=("commands.chat",),
            schema="chat",
            controls=(
                PreferenceControlDoc(
                    label=guilabels.CHAT_SPEAK_ROOM_NAME,
                    kind="switch",
                    summary=(
                        "Controls whether Orca includes the conversation name with incoming "
                        "messages, unless the message came from the focused conversation."
                    ),
                    schema="chat",
                    key=ChatSettings.KEY_SPEAK_ROOM_NAME,
                ),
                PreferenceControlDoc(
                    label=guilabels.CHAT_SPEAK_ROOM_NAME_LAST,
                    kind="switch",
                    summary=(
                        "Controls whether the conversation name is spoken after the message "
                        "instead of before it."
                    ),
                    schema="chat",
                    key=ChatSettings.KEY_SPEAK_ROOM_NAME_LAST,
                ),
                PreferenceControlDoc(
                    label=guilabels.CHAT_ANNOUNCE_BUDDY_TYPING,
                    kind="switch",
                    summary=(
                        "Controls whether Orca announces changes in typing status when "
                        "the chat application provides that information."
                    ),
                    schema="chat",
                    key=ChatSettings.KEY_ANNOUNCE_BUDDY_TYPING,
                ),
                PreferenceControlDoc(
                    label=guilabels.CHAT_SEPARATE_MESSAGE_HISTORIES,
                    kind="switch",
                    summary=(
                        "Controls whether Orca keeps separate recent-message histories for "
                        "each conversation."
                    ),
                    schema="chat",
                    key=ChatSettings.KEY_ROOM_HISTORIES,
                ),
                PreferenceControlDoc(
                    label=guilabels.CHAT_SPEAK_MESSAGES_FROM,
                    kind="choice",
                    summary="Controls which incoming chat messages Orca speaks automatically.",
                    schema="chat",
                    key=ChatSettings.KEY_MESSAGE_VERBOSITY,
                    value_docs=(
                        PreferenceValueDoc(
                            label=guilabels.CHAT_SPEAK_MESSAGES_ALL,
                            value="all",
                            summary=(
                                "Speaks messages from all conversations, even when another "
                                "application is active."
                            ),
                        ),
                        PreferenceValueDoc(
                            label=guilabels.CHAT_SPEAK_MESSAGES_ACTIVE_CHANNEL,
                            value="focused-channel",
                            summary=(
                                "Speaks messages from the active conversation, even when another "
                                "application is active."
                            ),
                        ),
                        PreferenceValueDoc(
                            label=guilabels.CHAT_SPEAK_MESSAGES_ALL_IF_FOCUSED,
                            value="all-if-focused",
                            summary=(
                                "Speaks messages from all conversations while the chat application "
                                "is active."
                            ),
                        ),
                        PreferenceValueDoc(
                            label=guilabels.CHAT_SPEAK_MESSAGES_ACTIVE,
                            value="active-channel",
                            summary=(
                                "Speaks messages from the active conversation while the chat "
                                "application is active."
                            ),
                        ),
                    ),
                ),
            ),
        )

    def __init__(self, presenter: ChatPresenter) -> None:
        options = [
            guilabels.CHAT_SPEAK_MESSAGES_ALL,
            guilabels.CHAT_SPEAK_MESSAGES_ACTIVE_CHANNEL,
            guilabels.CHAT_SPEAK_MESSAGES_ALL_IF_FOCUSED,
            guilabels.CHAT_SPEAK_MESSAGES_ACTIVE,
        ]
        values = [
            ChatMessageVerbosity.ALL_ANY_APP.value,
            ChatMessageVerbosity.CURRENT_ANY_APP.value,
            ChatMessageVerbosity.ALL_ACTIVE_APP.value,
            ChatMessageVerbosity.CURRENT_ACTIVE_APP.value,
        ]

        controls: list[
            preferences_grid_base.BooleanPreferenceControl
            | preferences_grid_base.SelectionPreferenceControl
        ] = [
            preferences_grid_base.BooleanPreferenceControl(
                label=guilabels.CHAT_SPEAK_ROOM_NAME,
                getter=presenter.get_speak_room_name,
                setter=presenter.set_speak_room_name,
                prefs_key=ChatSettings.KEY_SPEAK_ROOM_NAME,
            ),
            preferences_grid_base.BooleanPreferenceControl(
                label=guilabels.CHAT_SPEAK_ROOM_NAME_LAST,
                getter=presenter.get_speak_room_name_last,
                setter=presenter.set_speak_room_name_last,
                prefs_key=ChatSettings.KEY_SPEAK_ROOM_NAME_LAST,
                determine_sensitivity=presenter.get_speak_room_name,
            ),
            preferences_grid_base.BooleanPreferenceControl(
                label=guilabels.CHAT_ANNOUNCE_BUDDY_TYPING,
                getter=presenter.get_announce_buddy_typing,
                setter=presenter.set_announce_buddy_typing,
                prefs_key=ChatSettings.KEY_ANNOUNCE_BUDDY_TYPING,
            ),
            preferences_grid_base.BooleanPreferenceControl(
                label=guilabels.CHAT_SEPARATE_MESSAGE_HISTORIES,
                getter=presenter.get_room_histories,
                setter=presenter.set_room_histories,
                prefs_key=ChatSettings.KEY_ROOM_HISTORIES,
            ),
            preferences_grid_base.SelectionPreferenceControl(
                label=guilabels.CHAT_SPEAK_MESSAGES_FROM,
                options=options,
                values=values,
                getter=presenter.get_message_verbosity,
                setter=presenter.set_message_verbosity,
                prefs_key=ChatSettings.KEY_MESSAGE_VERBOSITY,
            ),
        ]

        super().__init__(guilabels.KB_GROUP_CHAT, controls)
