# Orca
#
# Copyright 2005-2008 Sun Microsystems Inc.
# Copyright 2011-2025 Igalia, S.L.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., Franklin Street, Fifth Floor,
# Boston MA  02110-1301 USA.

"""Command definitions for typing echo."""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import cmdnames
from .command import Command, KeyboardCommand
from .help_metadata import CommandDoc, CommandGroupDoc

if TYPE_CHECKING:
    from .typing_echo_presenter import TypingEchoPresenter


def get_documentation() -> CommandGroupDoc:
    """Returns documentation metadata for echo commands."""

    return CommandGroupDoc(
        commands=(
            CommandDoc(
                "cycleKeyEchoHandler",
                details=(
                    "Switches among key echo, word echo, sentence echo, key and word echo, word "
                    "and sentence echo, and off."
                ),
            ),
        ),
        summary="Echo controls what Orca speaks while you type.",
    )


def get_commands(owner: TypingEchoPresenter) -> list[Command]:
    """Returns commands for typing echo."""

    return [
        KeyboardCommand(
            "cycleKeyEchoHandler",
            owner.cycle_key_echo,
            owner.GROUP_LABEL,
            cmdnames.CYCLE_KEY_ECHO,
            desktop_keybinding=None,
            laptop_keybinding=None,
        ),
    ]
