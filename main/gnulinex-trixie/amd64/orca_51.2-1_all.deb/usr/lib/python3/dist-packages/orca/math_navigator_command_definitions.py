# Orca
#
# Copyright 2026 Igalia, S.L.
# Author: Joanmarie Diggs <jdiggs@igalia.com>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., Franklin Street, Fifth Floor,
# Boston MA  02110-1301 USA.

"""Command definitions for math navigation."""

from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING

from . import cmdnames, keybindings
from .command import Command, KeyboardCommand
from .help_metadata import CommandDoc, CommandGroupDoc, CommandSectionDoc

if TYPE_CHECKING:
    from .math_navigator import MathNavigator


def get_documentation() -> CommandGroupDoc:
    """Returns documentation metadata for math navigation commands."""

    return CommandGroupDoc(
        summary="Move through mathematical expressions.",
        commands=(
            *tuple(
                CommandDoc(
                    name=f"math_{prefix.lower()}_{digit}",
                    summary=(
                        f"Sets place marker {digit} at the current part of the expression."
                        if prefix == "SetPlacemarker"
                        else f"Returns to place marker {digit}."
                        if prefix == "MoveTo"
                        else f"Speaks the part of the expression at place marker {digit}."
                        if prefix == "Read"
                        else f"Describes the structure at place marker {digit}."
                    ),
                )
                for prefix in PLACE_MARKER_PREFIXES
                for digit in range(10)
            ),
            CommandDoc(
                "math_enter",
                details=(
                    "Starts math navigation at the current expression. First move to an "
                    "expression, such as an equation, fraction, or formula."
                ),
            ),
            CommandDoc("math_exit", details=("Leaves math navigation.")),
            CommandDoc(
                "math_move_next",
                details="Moves to the next part at the current level of detail.",
            ),
            CommandDoc(
                "math_move_previous",
                details="Moves to the previous part at the current level of detail.",
            ),
            CommandDoc("math_zoom_in", details=("Explores smaller parts of the expression.")),
            CommandDoc(
                "math_zoom_out", details=("Returns to larger structures within the expression.")
            ),
            CommandDoc(
                "math_zoom_in_all",
                details="Moves to the smallest part within the current part of the expression.",
            ),
            CommandDoc(
                "math_zoom_out_all",
                details="Returns to the whole expression.",
            ),
            CommandDoc(
                "math_move_start",
                details="Moves to the first part of the expression.",
            ),
            CommandDoc(
                "math_move_end",
                details="Moves to the last part of the expression.",
            ),
            CommandDoc(
                "math_move_line_start",
                details=(
                    "Moves to the beginning of the current mathematical line, such as a "
                    "fraction's numerator or denominator."
                ),
            ),
            CommandDoc(
                "math_move_line_end",
                details=(
                    "Moves to the end of the current mathematical line, such as a fraction's "
                    "numerator or denominator."
                ),
            ),
            CommandDoc(
                "math_move_column_start",
                details="Moves to the top of the current column in tabular math.",
            ),
            CommandDoc(
                "math_move_column_end",
                details="Moves to the bottom of the current column in tabular math.",
            ),
            CommandDoc(
                "math_move_cell_previous",
                details="Moves left within a matrix or other tabular expression.",
            ),
            CommandDoc(
                "math_move_cell_next",
                details="Moves right within a matrix or other tabular expression.",
            ),
            CommandDoc(
                "math_move_cell_up",
                details="Moves up within a matrix or other tabular expression.",
            ),
            CommandDoc(
                "math_move_cell_down",
                details="Moves down within a matrix or other tabular expression.",
            ),
            CommandDoc(
                "math_move_last_location",
                details=(
                    "Returns to the previous navigation position. Unlike moving left, this can "
                    "return inside a fraction after you have moved out of it."
                ),
            ),
            CommandDoc(
                "math_toggle_zoom_lock_up",
                details=("Cycles through Character, Simple, Enhanced, and back to Character."),
            ),
            CommandDoc(
                "math_toggle_zoom_lock_down",
                details=("Cycles through Enhanced, Simple, Character, and back to Enhanced."),
            ),
            CommandDoc(
                "math_toggle_speech_mode",
                details=(
                    "Chooses whether moving through the expression speaks the selected part or "
                    "describes its structure."
                ),
            ),
            CommandDoc(
                "math_where_am_i",
                details=(
                    "Describes your location within the expression, rather than your location in "
                    "the application."
                ),
            ),
            CommandDoc(
                "math_where_am_i_all",
                details=(
                    "Describes your location within the expression, rather than your location in "
                    "the application."
                ),
            ),
            CommandDoc(
                "math_read_previous",
                details="Moves to the previous part of the expression and speaks it.",
            ),
            CommandDoc(
                "math_read_next",
                details="Moves to the next part of the expression and speaks it.",
            ),
            CommandDoc(
                "math_read_current", details=("Speaks the selected part of the expression.")
            ),
            CommandDoc(
                "math_read_cell_current",
                details=(
                    "Speaks the current cell in a matrix or other tabular expression, rather "
                    "than just the part you are exploring."
                ),
            ),
            CommandDoc(
                "math_describe_previous",
                details="Moves to the previous part and gives an overview of its structure.",
            ),
            CommandDoc(
                "math_describe_next",
                details="Moves to the next part and gives an overview of its structure.",
            ),
            CommandDoc(
                "math_describe_current",
                details=("Gives an outline of the selected part's structure."),
            ),
            CommandDoc(
                "math_copy",
                details=(
                    "Copies math content to the clipboard using the format configured in the "
                    "settings above."
                ),
            ),
        ),
        sections=(
            CommandSectionDoc(
                title="Entering and leaving math navigation",
                command_names=("math_enter", "math_exit"),
            ),
            CommandSectionDoc(
                title="Moving through expressions",
                command_names=tuple(
                    name
                    for name, *_rest in COMMAND_SPECS
                    if name.startswith(("math_move_", "math_zoom_", "math_toggle_zoom_lock_"))
                ),
            ),
            CommandSectionDoc(
                title="Place markers",
                instructions=(
                    "A place marker records a position within a mathematical expression so you "
                    "can return to it later."
                ),
                command_names=tuple(
                    f"math_{prefix.lower()}_{digit}"
                    for prefix in PLACE_MARKER_PREFIXES
                    for digit in range(10)
                ),
            ),
            CommandSectionDoc(
                title="Reading and describing expressions",
                instructions=(
                    "Reading speaks the selected part's mathematical content. Describing gives "
                    "an overview of its structure."
                ),
                command_names=tuple(
                    name
                    for name, *_rest in COMMAND_SPECS
                    if name != "math_exit"
                    and not name.startswith(("math_move_", "math_zoom_", "math_toggle_zoom_lock_"))
                ),
            ),
        ),
    )


PLACE_MARKER_PREFIXES = ("MoveTo", "SetPlacemarker", "Read", "Describe")

COMMAND_SPECS = (
    ("math_move_next", "MoveNext", cmdnames.MATH_NAV_MOVE_NEXT, "Right", "none"),
    ("math_move_previous", "MovePrevious", cmdnames.MATH_NAV_MOVE_PREVIOUS, "Left", "none"),
    ("math_zoom_in", "ZoomIn", cmdnames.MATH_NAV_ZOOM_IN, "Down", "none"),
    ("math_zoom_out", "ZoomOut", cmdnames.MATH_NAV_ZOOM_OUT, "Up", "none"),
    ("math_zoom_in_all", "ZoomInAll", cmdnames.MATH_NAV_ZOOM_IN_ALL, "Down", "ctrl_shift"),
    ("math_zoom_out_all", "ZoomOutAll", cmdnames.MATH_NAV_ZOOM_OUT_ALL, "Up", "ctrl_shift"),
    ("math_move_start", "MoveStart", cmdnames.MATH_NAV_MOVE_START, "Home", "none"),
    ("math_move_end", "MoveEnd", cmdnames.MATH_NAV_MOVE_END, "End", "none"),
    ("math_move_line_start", "MoveLineStart", cmdnames.MATH_NAV_MOVE_LINE_START, "Home", "ctrl"),
    ("math_move_line_end", "MoveLineEnd", cmdnames.MATH_NAV_MOVE_LINE_END, "End", "ctrl"),
    (
        "math_move_column_start",
        "MoveColumnStart",
        cmdnames.MATH_NAV_MOVE_COLUMN_START,
        "Home",
        "shift",
    ),
    (
        "math_move_column_end",
        "MoveColumnEnd",
        cmdnames.MATH_NAV_MOVE_COLUMN_END,
        "End",
        "shift",
    ),
    (
        "math_move_cell_previous",
        "MoveCellPrevious",
        cmdnames.MATH_NAV_MOVE_CELL_PREVIOUS,
        "Left",
        "ctrl",
    ),
    (
        "math_move_cell_next",
        "MoveCellNext",
        cmdnames.MATH_NAV_MOVE_CELL_NEXT,
        "Right",
        "ctrl",
    ),
    ("math_move_cell_up", "MoveCellUp", cmdnames.MATH_NAV_MOVE_CELL_UP, "Up", "ctrl"),
    (
        "math_move_cell_down",
        "MoveCellDown",
        cmdnames.MATH_NAV_MOVE_CELL_DOWN,
        "Down",
        "ctrl",
    ),
    (
        "math_move_last_location",
        "MoveLastLocation",
        cmdnames.MATH_NAV_MOVE_LAST_LOCATION,
        "BackSpace",
        "none",
    ),
    (
        "math_toggle_zoom_lock_up",
        "ToggleZoomLockUp",
        cmdnames.MATH_NAV_TOGGLE_ZOOM_LOCK_UP,
        "Up",
        "shift",
    ),
    (
        "math_toggle_zoom_lock_down",
        "ToggleZoomLockDown",
        cmdnames.MATH_NAV_TOGGLE_ZOOM_LOCK_DOWN,
        "Down",
        "shift",
    ),
    (
        "math_toggle_speech_mode",
        "ToggleSpeakMode",
        cmdnames.MATH_NAV_TOGGLE_SPEECH_MODE,
        "space",
        "shift",
    ),
    ("math_read_previous", "ReadPrevious", cmdnames.MATH_NAV_READ_PREVIOUS, "Left", "shift"),
    ("math_read_next", "ReadNext", cmdnames.MATH_NAV_READ_NEXT, "Right", "shift"),
    ("math_read_current", "ReadCurrent", cmdnames.MATH_NAV_READ_CURRENT, "space", "none"),
    (
        "math_read_cell_current",
        "ReadCellCurrent",
        cmdnames.MATH_NAV_READ_CELL_CURRENT,
        "space",
        "ctrl",
    ),
    (
        "math_describe_previous",
        "DescribePrevious",
        cmdnames.MATH_NAV_DESCRIBE_PREVIOUS,
        "Left",
        "ctrl_shift",
    ),
    (
        "math_describe_next",
        "DescribeNext",
        cmdnames.MATH_NAV_DESCRIBE_NEXT,
        "Right",
        "ctrl_shift",
    ),
    (
        "math_describe_current",
        "DescribeCurrent",
        cmdnames.MATH_NAV_DESCRIBE_CURRENT,
        "space",
        "ctrl_shift",
    ),
    ("math_where_am_i", "WhereAmI", cmdnames.MATH_NAV_WHERE_AM_I, "", "unbound"),
    ("math_where_am_i_all", "WhereAmIAll", cmdnames.MATH_NAV_WHERE_AM_I_ALL, "", "unbound"),
    ("math_exit", "Exit", cmdnames.MATH_NAV_EXIT, "Escape", "none"),
    ("math_copy", "Copy", cmdnames.MATH_NAV_COPY, "", "unbound"),
)

MODIFIER_MASKS = {
    "none": keybindings.NO_MODIFIER_MASK,
    "ctrl": keybindings.CTRL_MODIFIER_MASK,
    "shift": keybindings.SHIFT_MODIFIER_MASK,
    "ctrl_shift": keybindings.CTRL_SHIFT_MODIFIER_MASK,
}


def _keybinding(key: str, modifier_name: str) -> keybindings.KeyBinding | None:
    """Returns the keybinding for key and modifier_name."""

    if modifier_name == "unbound":
        return None
    return keybindings.KeyBinding(key, MODIFIER_MASKS[modifier_name])


def get_supported_commands() -> list[str]:
    """Returns MathCAT navigation commands supported by the math navigator."""

    commands = [mathcat_command for _name, mathcat_command, _desc, _key, _mod in COMMAND_SPECS]
    for digit in range(10):
        commands.extend(f"{prefix}{digit}" for prefix in PLACE_MARKER_PREFIXES)
    return commands


def get_commands(owner: MathNavigator) -> list[Command]:
    """Returns commands for math navigation."""

    enter_binding = keybindings.KeyBinding("m", keybindings.ORCA_ALT_MODIFIER_MASK)
    commands: list[Command] = [
        KeyboardCommand(
            "math_enter",
            owner.enter_math_mode_command,
            owner.GROUP_LABEL,
            cmdnames.MATH_NAV_ENTER,
            desktop_keybinding=enter_binding,
            laptop_keybinding=enter_binding,
            is_group_toggle=True,
        )
    ]
    for name, mathcat_command, description, key, modifier_name in COMMAND_SPECS:
        if mathcat_command == "Exit":
            handler = owner.exit_math_mode
        elif mathcat_command == "Copy":
            handler = owner.copy_to_clipboard
        else:
            handler = partial(owner._execute_command, mathcat_command)  # pylint: disable=protected-access
        binding = _keybinding(key, modifier_name)
        commands.append(
            KeyboardCommand(
                name,
                handler,
                owner.GROUP_LABEL,
                description,
                desktop_keybinding=binding,
                laptop_keybinding=binding,
            )
        )

    marker_types = (
        ("none", PLACE_MARKER_PREFIXES[0], cmdnames.MATH_NAV_GOTO_PLACE_MARKER),
        ("ctrl", PLACE_MARKER_PREFIXES[1], cmdnames.MATH_NAV_SET_PLACE_MARKER),
        ("shift", PLACE_MARKER_PREFIXES[2], cmdnames.MATH_NAV_READ_PLACE_MARKER),
        (
            "ctrl_shift",
            PLACE_MARKER_PREFIXES[3],
            cmdnames.MATH_NAV_DESCRIBE_PLACE_MARKER,
        ),
    )
    for digit in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"):
        for modifier_name, command_prefix, description in marker_types:
            binding = keybindings.KeyBinding(digit, MODIFIER_MASKS[modifier_name])
            commands.append(
                KeyboardCommand(
                    f"math_{command_prefix.lower()}_{digit}",
                    partial(owner._execute_command, f"{command_prefix}{digit}"),  # pylint: disable=protected-access
                    owner.GROUP_LABEL,
                    description,
                    desktop_keybinding=binding,
                    laptop_keybinding=binding,
                )
            )

    return commands
