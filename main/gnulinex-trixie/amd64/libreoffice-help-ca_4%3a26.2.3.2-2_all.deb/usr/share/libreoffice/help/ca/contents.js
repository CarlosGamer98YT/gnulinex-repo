document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Documents de text (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/swriter/main0000.html?DbPAR=WRITER">Us donem la benvinguda a l&#39;ajuda del LibreOffice Writer</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0503.html?DbPAR=WRITER">Funcions del LibreOffice Writer</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/main.html?DbPAR=WRITER">Instruccions per a la utilització del LibreOffice Writer</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Acoblament i redimensionament de finestres</a></li>\
    <li><a target="_top" href="ca/text/swriter/04/01020000.html?DbPAR=WRITER">Tecles de drecera per al LibreOffice Writer</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/words_count.html?DbPAR=WRITER">Recompte de paraules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/keyboard.html?DbPAR=WRITER">Utilització de tecles de drecera (accessibilitat del LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Referència de les ordres i menús</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menús</label><ul>\
    <li><a target="_top" href="ca/text/swriter/main0100.html?DbPAR=WRITER">Menús</a></li>\
    <li><a target="_top" href="ca/text/shared/menu/PickList.html?DbPAR=WRITER">Menú Fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/main_edit.html?DbPAR=WRITER">Edita</a></li>\
    <li><a target="_top" href="ca/text/shared/main0103.html?DbPAR=WRITER">Visualitza</a></li>\
    <li><a target="_top" href="ca/text/shared/main0104.html?DbPAR=WRITER">Insereix</a></li>\
    <li><a target="_top" href="ca/text/shared/main_format.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="ca/text/shared/menu/style_menu.html?DbPAR=WRITER">Estils (menú)</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0110.html?DbPAR=WRITER">Taula</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0120.html?DbPAR=WRITER">Menú Formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/main_tools.html?DbPAR=WRITER">Main Tools Menu</a></li>\
    <li><a target="_top" href="ca/text/shared/main0107.html?DbPAR=WRITER">Finestra</a></li>\
    <li><a target="_top" href="ca/text/shared/main0108.html?DbPAR=WRITER">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barres d&#39;eines</label><ul>\
    <li><a target="_top" href="ca/text/swriter/main0200.html?DbPAR=WRITER">Barres d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0206.html?DbPAR=WRITER">Barra Pics i numeració</a></li>\
    <li><a target="_top" href="ca/text/shared/01/classificationbar.html?DbPAR=WRITER">Barra Classificació</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0210.html?DbPAR=WRITER">Barra Dibuix</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0205.html?DbPAR=WRITER">Barra Propietats de l&#39;objecte de dibuix</a></li>\
    <li><a target="_top" href="ca/text/shared/02/find_toolbar.html?DbPAR=WRITER">Barra Cerca</a></li>\
    <li><a target="_top" href="ca/text/shared/02/fontwork_toolbar.html?DbPAR=WRITER">Fontwork</a></li>\
    <li><a target="_top" href="ca/text/shared/02/01170000.html?DbPAR=WRITER">Controls de formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/main0226.html?DbPAR=WRITER">Barra d&#39;eines Disseny del formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/main0213.html?DbPAR=WRITER">Barra Navegació de formularis</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0202.html?DbPAR=WRITER">Barra de formatació</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0214.html?DbPAR=WRITER">Barra de fórmules</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0215.html?DbPAR=WRITER">Barra Marc</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0203.html?DbPAR=WRITER">Barra d&#39;imatges</a></li>\
    <li><a target="_top" href="ca/text/swriter/02/18010000.html?DbPAR=WRITER">Insereix</a></li>\
    <li><a target="_top" href="ca/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barra d&#39;eines del LibreLogo</a></li>\
    <li><a target="_top" href="ca/text/swriter/mailmergetoolbar.html?DbPAR=WRITER">Barra d&#39;eines Combinació de correu</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0216.html?DbPAR=WRITER">Barra Objecte OLE</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0210.html?DbPAR=WRITER">Barra de previsualització d&#39;impressió (Writer)</a></li>\
    <li><a target="_top" href="ca/text/shared/main0214.html?DbPAR=WRITER">Barra Disseny de la consulta</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0213.html?DbPAR=WRITER">Regles</a></li>\
    <li><a target="_top" href="ca/text/shared/main0201.html?DbPAR=WRITER">Barra Estàndard</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0208.html?DbPAR=WRITER">Barra d&#39;estat (Writer)</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0204.html?DbPAR=WRITER">Barra Taula</a></li>\
    <li><a target="_top" href="ca/text/shared/main0212.html?DbPAR=WRITER">Barra Dades de la taula</a></li>\
    <li><a target="_top" href="ca/text/swriter/main0220.html?DbPAR=WRITER">Barra Objecte de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Barra d&#39;eines Control de canvis</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navegació pels documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navegació i selecció amb el teclat</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Moure i copiar text en documents</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Reorganització d&#39;un document mitjançant el Navegador</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserció d&#39;enllaços amb el Navegador</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/navigator.html?DbPAR=WRITER">Navegador per a documents de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Utilització del cursor directe</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatació de documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Canviar l&#39;orientació de la pàgina (horitzontal o vertical)</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_capital.html?DbPAR=WRITER">Canviar el text a majúscules o minúscules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Amagar text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definició de capçaleres i peus diferents</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserció del nom i del número de capítol en una capçalera o en un peu</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Aplicació de formatació de text en teclejar</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/reset_format.html?DbPAR=WRITER">Reinicialització dels atributs de lletra tipogràfica</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Aplicació d&#39;estils en mode de format d&#39;emplenament</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/wrap.html?DbPAR=WRITER">Ajustament del text al voltant d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Utilització d&#39;un marc per centrar el text en una pàgina</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Emfasització de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Gir del text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserció i supressió de salts de pàgina</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creació i aplicació d&#39;estils de pàgina</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/subscript.html?DbPAR=WRITER">Formatació del text com a superíndex o subíndex</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Plantilles i estils</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Plantilles i estils</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternar estils de pàgina en pàgines senars i parelles</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/change_header.html?DbPAR=WRITER">Creació d&#39;un estil de pàgina basat en la pàgina actual</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/load_styles.html?DbPAR=WRITER">Utilització d&#39;estils des d&#39;un altre fitxer o plantilla</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Creació d&#39;estils nous a partir de seleccions</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Actualització d&#39;estils a partir de seleccions</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/spotlight_styles.html?DbPAR=WRITER">Spotlight Styles</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/template_manager.html?DbPAR=WRITER">Gestor de plantilles</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Gràfics en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserció de gràfics</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserció d&#39;un gràfic des d&#39;un fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/gallery_insert.html?DbPAR=WRITER">Inserció d&#39;objectes des de la Galeria</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserció d&#39;una imatge escanejada</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserció d&#39;un diagrama del Calc en un document de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserció d&#39;imatges des del LibreOffice Draw o el LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Taules en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Activació i desactivació del reconeixement de nombres en taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificació de files i de columnes mitjançant el teclat</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/table_delete.html?DbPAR=WRITER">Supressió de taules o dels continguts d&#39;una taula</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserció de taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Repetir una capçalera de taula en una pàgina nova</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Redimensionament de files i de columnes en una taula de text</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objectes en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Col·locació d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/wrap.html?DbPAR=WRITER">Ajustament del text al voltant d&#39;objectes</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Seccions i marcs en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/sections.html?DbPAR=WRITER">Utilització de seccions</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserció, edició i enllaçament de marcs</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/section_edit.html?DbPAR=WRITER">Edició de seccions</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserció de seccions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Taules de contingut i índexs</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeració per a encapçalaments</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Índexs definits per l&#39;usuari</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Creació d&#39;una taula de continguts</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_index.html?DbPAR=WRITER">Creació d&#39;índexs alfabètics</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Índexs per a diversos documents</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Creació d&#39;una bibliografia</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Edició i supressió d&#39;entrades d&#39;índexs i taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Actualització, edició i supressió d&#39;índexs i taules de continguts</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definició d&#39;entrades en índexs o en taules de continguts</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatació d&#39;un índex o d&#39;una taula de continguts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Camps en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/fields.html?DbPAR=WRITER">Quant als camps</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserció d&#39;un camp de data fixa o variable</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/field_convert.html?DbPAR=WRITER">Convertir un camp en text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/contentcontrols.html?DbPAR=WRITER">Ús de controls de contingut al LibreOffice Writer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Càlculs en documents de text</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Càlculs entre taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate.html?DbPAR=WRITER">Càlculs en documents de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcular una fórmula i enganxar-ne el resultat en un document de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Càlcul de totals de cel·les en taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Càlcul de fórmules complexes en documents de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Mostrar el resultat del càlcul d&#39;una taula en una altra taula</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elements de text especials</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/captions.html?DbPAR=WRITER">Utilització de llegendes</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Text condicional</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Text condicional per al recompte de pàgines</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserció d&#39;un camp de data fixa o variable</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Addició de camps d&#39;entrada</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserció de números de pàgina de pàgines de continuació</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserció de números de pàgina en els peus</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Amagar text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definició de capçaleres i peus diferents</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserció del nom i del número de capítol en una capçalera o en un peu</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Consultar dades de l&#39;usuari en camps o condicions</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserció i edició de notes al peu o de notes finals</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Espaiat entre notes al peu</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_footer.html?DbPAR=WRITER">Quant a les capçaleres i els peus</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatació de capçaleres i peus</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animació de text</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Creació d&#39;una carta model</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funcions automàtiques</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Addició d&#39;excepcions a la llista de correcció automàtica</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/autotext.html?DbPAR=WRITER">Utilització del text automàtic</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creació de llistes numerades o amb pics en teclejar</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/auto_off.html?DbPAR=WRITER">Desactivació de la correcció automàtica</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificació ortogràfica automàtica</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Activació i desactivació del reconeixement de nombres en taules</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Ús de la partició de mots</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeracions i llistes</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Addició de números d&#39;encapçalament a les llegendes</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creació de llistes numerades o amb pics en teclejar</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeració per a encapçalaments</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinació de llistes numerades</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Addició de números de línia</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modificació de la numeració en una llista ordenada</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definició d&#39;intervals numèrics</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Addició de numeració</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Estils de numeració i de paràgraf</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Addició de pics</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Verificació ortogràfica, tesaurus i llengües</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificació ortogràfica automàtica</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Supressió de paraules d&#39;un diccionari definit per l&#39;usuari</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Tesaurus</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Verificació ortogràfica i gramatical</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Consells per a la resolució de problemes</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insert Text Before a Table at the Top of Page</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Anar a una adreça d&#39;interès concreta</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Càrrega, desament, importació, exportació i emmascarament</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/send2html.html?DbPAR=WRITER">Desar documents de text en format HTML</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserció de tot un document de text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redaction.html?DbPAR=WRITER">Veladura</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/auto_redact.html?DbPAR=WRITER">Veladura automàtica</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Documents mestres</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Documents mestres i subdocuments</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Enllaços i referències</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/references.html?DbPAR=WRITER">Inserció de referències creuades</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserció d&#39;enllaços amb el Navegador</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Impressió</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecció d&#39;allò que s&#39;ha d&#39;imprimir</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Selecció de safates de paper de la impressora</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/print_preview.html?DbPAR=WRITER">Previsualització d&#39;una pàgina abans d&#39;imprimir-la</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/print_small.html?DbPAR=WRITER">Impressió de pàgines múltiples en un full</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creació i aplicació d&#39;estils de pàgina</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Cerques i substitucions</label><ul>\
    <li><a target="_top" href="ca/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="ca/text/shared/01/02100001.html?DbPAR=WRITER">Llista d&#39;expressions regulars</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documents HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="ca/text/shared/07/09000000.html?DbPAR=WRITER">Pàgines web</a></li>\
    <li><a target="_top" href="ca/text/shared/02/01170700.html?DbPAR=WRITER">Filtres i formularis HTML</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/send2html.html?DbPAR=WRITER">Desar documents de text en format HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Fulls de càlcul (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/scalc/main0000.html?DbPAR=CALC">Us donem la benvinguda a l&#39;ajuda del LibreOffice Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0503.html?DbPAR=CALC">Funcions del LibreOffice Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/keyboard.html?DbPAR=CALC">Tecles de drecera (accessibilitat al LibreOffice Calc)</a></li>\
    <li><a target="_top" href="ca/text/scalc/04/01020000.html?DbPAR=CALC">Tecles de drecera per als fulls de càlcul</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Precisió del càlcul</a></li>\
    <li><a target="_top" href="ca/text/scalc/05/02140000.html?DbPAR=CALC">Codis d&#39;error del LibreOffice Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060112.html?DbPAR=CALC">Complement de programació del LibreOffice Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/main.html?DbPAR=CALC">Instruccions per a la utilització del LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Referència de les ordres i menús</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menús</label><ul>\
    <li><a target="_top" href="ca/text/scalc/main0100.html?DbPAR=CALC">Menús</a></li>\
    <li><a target="_top" href="ca/text/shared/menu/PickList.html?DbPAR=CALC">Menú Fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/main_edit.html?DbPAR=CALC">Edita</a></li>\
    <li><a target="_top" href="ca/text/shared/main0103.html?DbPAR=CALC">Visualitza</a></li>\
    <li><a target="_top" href="ca/text/shared/main0104.html?DbPAR=CALC">Insereix</a></li>\
    <li><a target="_top" href="ca/text/shared/main_format.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0116.html?DbPAR=CALC">Full</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0112.html?DbPAR=CALC">Dades</a></li>\
    <li><a target="_top" href="ca/text/shared/main_tools.html?DbPAR=CALC">Main Tools Menu</a></li>\
    <li><a target="_top" href="ca/text/shared/main0107.html?DbPAR=CALC">Finestra</a></li>\
    <li><a target="_top" href="ca/text/shared/main0108.html?DbPAR=CALC">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barres d&#39;eines</label><ul>\
    <li><a target="_top" href="ca/text/scalc/main0200.html?DbPAR=CALC">Barres d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/shared/02/find_toolbar.html?DbPAR=CALC">Barra Cerca</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0202.html?DbPAR=CALC">Barra Formatació</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0203.html?DbPAR=CALC">Barra de propietats dels objectes de dibuix</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0205.html?DbPAR=CALC">Barra de formatació del text</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0206.html?DbPAR=CALC">Barra de fórmules</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0208.html?DbPAR=CALC">Barra d&#39;estat</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0210.html?DbPAR=CALC">Barra de previsualització d&#39;impressió</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0214.html?DbPAR=CALC">Barra d&#39;imatges</a></li>\
    <li><a target="_top" href="ca/text/scalc/main0218.html?DbPAR=CALC">Barra d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/shared/main0201.html?DbPAR=CALC">Barra Estàndard</a></li>\
    <li><a target="_top" href="ca/text/shared/main0212.html?DbPAR=CALC">Barra Dades de la taula</a></li>\
    <li><a target="_top" href="ca/text/shared/main0213.html?DbPAR=CALC">Barra Navegació de formularis</a></li>\
    <li><a target="_top" href="ca/text/shared/main0214.html?DbPAR=CALC">Barra Disseny de la consulta</a></li>\
    <li><a target="_top" href="ca/text/shared/main0226.html?DbPAR=CALC">Barra d&#39;eines Disseny del formulari</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Tipus de funcions i operadors</label><ul>\
    <li><a target="_top" href="ca/text/scalc/01/04060000.html?DbPAR=CALC">Auxiliar de funcions</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060100.html?DbPAR=CALC">Funcions per categoria</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060107.html?DbPAR=CALC">Funcions matricials</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060120.html?DbPAR=CALC">Funcions d&#39;operació de bits</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060101.html?DbPAR=CALC">Funcions de base de dades</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060102.html?DbPAR=CALC">Funcions de data i d&#39;hora</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060103.html?DbPAR=CALC">Funcions financeres, primera part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060119.html?DbPAR=CALC">Funcions financeres, segona part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060118.html?DbPAR=CALC">Funcions financeres, tercera part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060104.html?DbPAR=CALC">Funcions d&#39;informació</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060105.html?DbPAR=CALC">Funcions lògiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060106.html?DbPAR=CALC">Funcions matemàtiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060108.html?DbPAR=CALC">Funcions estadístiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060181.html?DbPAR=CALC">Funcions estadístiques, primera part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060182.html?DbPAR=CALC">Funcions estadístiques, segona part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060183.html?DbPAR=CALC">Funcions estadístiques, tercera part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060184.html?DbPAR=CALC">Funcions estadístiques, quarta part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060185.html?DbPAR=CALC">Funcions estadístiques, cinquena part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060109.html?DbPAR=CALC">Funcions del full de càlcul</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060110.html?DbPAR=CALC">Funcions de text</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060111.html?DbPAR=CALC">Funcions de complements</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060115.html?DbPAR=CALC">Funcions de complements, llista de funcions d&#39;anàlisi: primera part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060116.html?DbPAR=CALC">Funcions de complements, llista de funcions d&#39;anàlisi: segona part</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/04060199.html?DbPAR=CALC">Operadors al LibreOffice Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Funcions definides per l&#39;usuari</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Càrrega, desament, importació, exportació i emmascarament</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/webquery.html?DbPAR=CALC">Inserció de dades externes a una taula (consulta de pàgina web)</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/html_doc.html?DbPAR=CALC">Desament i obertura de fulls en HTML</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importació i exportació de fitxers de text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redaction.html?DbPAR=CALC">Veladura</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/auto_redact.html?DbPAR=CALC">Veladura automàtica</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatació</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/text_rotate.html?DbPAR=CALC">Gir del text</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/text_wrap.html?DbPAR=CALC">Escriptura de text en línies múltiples</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatació de nombres com a text</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/super_subscript.html?DbPAR=CALC">Superíndex / subíndex del text</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/row_height.html?DbPAR=CALC">Canvi de l&#39;alçada de la fila o de l&#39;amplada de la columna</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Aplicació de la formatació condicional</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Realçament de nombres negatius</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Assignació de formats per fórmula</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Introducció d&#39;un nombre amb zeros inicials</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/format_table.html?DbPAR=CALC">Formatació de fulls de càlcul</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/format_value.html?DbPAR=CALC">Formatació de nombres amb decimals</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/value_with_name.html?DbPAR=CALC">Denominació de cel·les</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/table_rotate.html?DbPAR=CALC">Gir de taules (transposició)</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/rename_table.html?DbPAR=CALC">Canvi de nom dels fulls</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/year2000.html?DbPAR=CALC">Anys 19xx/20xx</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Utilització de nombres arrodonits</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/currency_format.html?DbPAR=CALC">Cel·les en format de moneda</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/autoformat.html?DbPAR=CALC">Utilització de la formatació automàtica per a taules</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserció i edició de comentaris</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/design.html?DbPAR=CALC">Selecció de temes per als fulls</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Introducció de fraccions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtratge i ordenació</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/filters.html?DbPAR=CALC">Aplicació de filtres</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/specialfilter.html?DbPAR=CALC">Aplicació de filtres avançats</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/autofilter.html?DbPAR=CALC">Aplicació del filtre automàtic</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/sorted_list.html?DbPAR=CALC">Aplicació de les llistes d&#39;ordenació</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Eliminació dels valors duplicats</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Impressió</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/print_title_row.html?DbPAR=CALC">Impressió de files o columnes a totes les pàgines</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/print_landscape.html?DbPAR=CALC">Impressió de fulls en format horitzontal</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/print_details.html?DbPAR=CALC">Impressió dels detalls d&#39;un full</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/print_exact.html?DbPAR=CALC">Definició del nombre de pàgines per a la impressió</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Intervals de dades</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/database_define.html?DbPAR=CALC">Definició d&#39;intervals de bases de dades</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtratge d&#39;intervals de cel·les</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/database_sort.html?DbPAR=CALC">Ordenació de dades</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Taula dinàmica</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot.html?DbPAR=CALC">Taula dinàmica</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Creació de taules dinàmiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Supressió de taules dinàmiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Edició de taules dinàmiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtratge de taules dinàmiques</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selecció d&#39;intervals de sortida de la taula dinàmica</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Actualització de taules dinàmiques</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Diagrama dinàmic</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart.html?DbPAR=CALC">Diagrama dinàmic</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creació de diagrames dinàmics</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Edició de diagrames dinàmics</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtratge de diagrames dinàmics</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Actualització de diagrames dinàmics</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Supressió de diagrames dinàmics</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08095"><label for="08095">Anàlisi de dades</label><ul>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_sampling.html?DbPAR=CALC">Data Sampling in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_descriptive.html?DbPAR=CALC">Estadístiques descriptives al Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_anova.html?DbPAR=CALC">ANOVA</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_correlation.html?DbPAR=CALC">Data Correlation in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_covariance.html?DbPAR=CALC">Covariància de dades al Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_exposmooth.html?DbPAR=CALC">Exponential Smoothing in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_movingavg.html?DbPAR=CALC">Moving Average in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_regression.html?DbPAR=CALC">Anàlisi de regressió</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_test_t.html?DbPAR=CALC">Paired t-test in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_test_f.html?DbPAR=CALC">F Test Statistics in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_test_z.html?DbPAR=CALC">Z Test Statistics in Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_test_chisqr.html?DbPAR=CALC">Estadístiques de khi quadrat al Calc</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/statistics_fourier.html?DbPAR=CALC">Anàlisi de Fourier</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Escenaris</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/scenario.html?DbPAR=CALC">Utilització d&#39;escenaris</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Ús de l&#39;eina de subtotals</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referències</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adreces i referències, absolutes i relatives</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/r1c1syntax.html?DbPAR=CALC">Sintaxi R1C1</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referencing a Cell in Another Sheet</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referencing URLs in other Sheets</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referència de cel·les mitjançant la funció d&#39;arrossegar i deixar anar</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/address_auto.html?DbPAR=CALC">Reconeixement dels noms com a adreçament</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Visualitzacions, seleccions i còpies</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/table_view.html?DbPAR=CALC">Canvi de les visualitzacions de la taula</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/formula_value.html?DbPAR=CALC">Visualització de fórmules o valors</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/line_fix.html?DbPAR=CALC">Congelació de files o columnes com a capçaleres</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navegació per les pestanyes dels fulls</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Còpia a fulls múltiples</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copiar només les cel·les visibles</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selecció de cel·les múltiples</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/move_dragdrop.html?DbPAR=CALC">Moviment de cel·les mitjançant la funció d&#39;arrossegar i deixar anar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Fórmules i càlculs</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/formulas.html?DbPAR=CALC">Càlculs amb fórmules</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/formula_copy.html?DbPAR=CALC">Còpia de fórmules</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/formula_enter.html?DbPAR=CALC">Introducció de fórmules</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/formula_value.html?DbPAR=CALC">Visualització de fórmules o valors</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/calculate.html?DbPAR=CALC">Càlcul en fulls de càlcul</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/calc_date.html?DbPAR=CALC">Càlculs amb dates i hores</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/calc_series.html?DbPAR=CALC">Càlcul automàtic de sèries</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Càlcul de diferències horàries</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/matrixformula.html?DbPAR=CALC">Introducció de fórmules matriu</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Protecció</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/cell_protect.html?DbPAR=CALC">Protecció de les cel·les en cas de canvis</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Desprotecció de cel·les</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Escritura de macros al Calc</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Lectura i escriptura de valors als intervals</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatació de les vores al Calc amb macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Miscel·lània</label><ul>\
    <li><a target="_top" href="ca/text/scalc/guide/auto_off.html?DbPAR=CALC">Desactivació dels canvis automàtics</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidació de dades</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/goalseek.html?DbPAR=CALC">Aplicació de la cerca de l&#39;objectiu</a></li>\
    <li><a target="_top" href="ca/text/scalc/01/solver.html?DbPAR=CALC">Solucionador</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/multioperation.html?DbPAR=CALC">Aplicació d&#39;operacions múltiples</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/multitables.html?DbPAR=CALC">Aplicació de fulls múltiples</a></li>\
    <li><a target="_top" href="ca/text/scalc/guide/validity.html?DbPAR=CALC">Validesa del contingut de les cel·les</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentacions (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/simpress/main0000.html?DbPAR=IMPRESS">Us donem la benvinguda a l&#39;ajuda del LibreOffice Impress</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0503.html?DbPAR=IMPRESS">Funcions del LibreOffice Impress</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Utilització de les tecles de drecera al LibreOffice Impress</a></li>\
    <li><a target="_top" href="ca/text/simpress/04/01020000.html?DbPAR=IMPRESS">Tecles de drecera per al LibreOffice Impress</a></li>\
    <li><a target="_top" href="ca/text/simpress/04/presenter.html?DbPAR=IMPRESS">Tecles de drecera de la Consola del presentador</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruccions per a utilitzar el LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Referència de les ordres i menús</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menús</label><ul>\
    <li><a target="_top" href="ca/text/simpress/main0100.html?DbPAR=IMPRESS">Menús</a></li>\
    <li><a target="_top" href="ca/text/shared/menu/PickList.html?DbPAR=IMPRESS">Menú Fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/main_edit.html?DbPAR=IMPRESS">Edita</a></li>\
    <li><a target="_top" href="ca/text/shared/main0103.html?DbPAR=IMPRESS">Visualitza</a></li>\
    <li><a target="_top" href="ca/text/shared/main0104.html?DbPAR=IMPRESS">Insereix</a></li>\
    <li><a target="_top" href="ca/text/shared/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="ca/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapositiva</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0114.html?DbPAR=IMPRESS">Presentació de diapositives</a></li>\
    <li><a target="_top" href="ca/text/shared/main_tools.html?DbPAR=IMPRESS">Main Tools Menu</a></li>\
    <li><a target="_top" href="ca/text/shared/main0107.html?DbPAR=IMPRESS">Finestra</a></li>\
    <li><a target="_top" href="ca/text/shared/main0108.html?DbPAR=IMPRESS">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barres d&#39;eines</label><ul>\
    <li><a target="_top" href="ca/text/simpress/main0200.html?DbPAR=IMPRESS">Barres d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0210.html?DbPAR=IMPRESS">Barra Dibuix</a></li>\
    <li><a target="_top" href="ca/text/shared/main0227.html?DbPAR=IMPRESS">Barra Edita els punts</a></li>\
    <li><a target="_top" href="ca/text/shared/02/find_toolbar.html?DbPAR=IMPRESS">Barra Cerca</a></li>\
    <li><a target="_top" href="ca/text/shared/main0226.html?DbPAR=IMPRESS">Barra d&#39;eines Disseny del formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/main0213.html?DbPAR=IMPRESS">Barra Navegació de formularis</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0214.html?DbPAR=IMPRESS">Barra d&#39;imatges</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0202.html?DbPAR=IMPRESS">Barra Línia i emplenament</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0213.html?DbPAR=IMPRESS">Barra Opcions</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0211.html?DbPAR=IMPRESS">Barra Esquema</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0209.html?DbPAR=IMPRESS">Regles</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0212.html?DbPAR=IMPRESS">Barra Classificador de diapositives</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0204.html?DbPAR=IMPRESS">Barra Visualització de diapositives</a></li>\
    <li><a target="_top" href="ca/text/shared/main0201.html?DbPAR=IMPRESS">Barra Estàndard</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0206.html?DbPAR=IMPRESS">Barra d&#39;estat</a></li>\
    <li><a target="_top" href="ca/text/shared/main0204.html?DbPAR=IMPRESS">Barra Taula</a></li>\
    <li><a target="_top" href="ca/text/simpress/main0203.html?DbPAR=IMPRESS">Barra Formatació del text</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Càrrega, desament, importació, exportació i emmascarament</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importació de pàgines HTML a presentacions</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportació d&#39;animacions en format GIF</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserció de gràfics</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insereix una diapositiva des d&#39;un fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redaction.html?DbPAR=IMPRESS">Veladura</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Veladura automàtica</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatació</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Càrrega dels estils de línia i de fletxa</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definició de colors personalitzats</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Creació d&#39;emplenaments amb degradats</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Reemplaçament de colors</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Organització, alineació i distribució d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/background.html?DbPAR=IMPRESS">Canvi de l&#39;emplenament de fons de la diapositiva</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/footer.html?DbPAR=IMPRESS">Addició d&#39;una capçalera o d&#39;un peu de pàgina a totes les diapositives</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Moviment d&#39;objectes</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Impressió</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/printing.html?DbPAR=IMPRESS">Impressió de presentacions</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Impressió d&#39;una diapositiva perquè s&#39;ajusti a la mida del paper</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efectes</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportació d&#39;animacions en format GIF</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animació d&#39;objectes en diapositives d&#39;una presentació</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animació de transicions entre diapositives</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Esvaïment encreuat de dos objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Creació d&#39;imatges GIF animades</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objectes, gràfics i mapes de bits</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combinació d&#39;objectes i construcció de formes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Agrupació d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Dibuix de sectors i de segments</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicació d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformacions</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Gir d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Assemblatge d&#39;objectes 3D</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Línies de connexió</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Conversió de caràcters de text en objectes de dibuix</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Conversió d&#39;imatges de mapa de bits en gràfics vectorials</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Conversió d&#39;objectes 2D en corbes, polígons i objectes 3D</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Càrrega dels estils de línia i de fletxa</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Dibuix de corbes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Edició de corbes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserció de gràfics</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Moviment d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Selecció d&#39;objectes subjacents</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Creació d&#39;un diagrama de flux</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text en presentacions</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Addició de text</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Conversió de caràcters de text en objectes de dibuix</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visualització</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Canvi de l&#39;ordre de les diapositives</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Canvi d&#39;escala amb el teclat numèric</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Presentacions de diapositives</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/show.html?DbPAR=IMPRESS">Mostra d&#39;una presentació de diapositives</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Guia de la telecomanda de l&#39;Impress</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/individual.html?DbPAR=IMPRESS">Creació d&#39;una presentació de diapositives personalitzada</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Assaig de cronometratges per als canvis de diapositives</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Dibuixos (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/main0000.html?DbPAR=DRAW">Us donem la benvinguda a l&#39;ajuda del LibreOffice Draw</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main0503.html?DbPAR=DRAW">Funcions del LibreOffice Draw</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Tecles de drecera per a objectes de dibuix</a></li>\
    <li><a target="_top" href="ca/text/sdraw/04/01020000.html?DbPAR=DRAW">Tecles de drecera per a dibuixos</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/main.html?DbPAR=DRAW">Instruccions per a utilitzar el LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Referència de les ordres i menús</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menús</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/main0100.html?DbPAR=DRAW">Menús</a></li>\
    <li><a target="_top" href="ca/text/shared/menu/PickList.html?DbPAR=DRAW">Menú Fitxer</a></li>\
    <li><a target="_top" href="ca/text/shared/main_edit.html?DbPAR=DRAW">Edita</a></li>\
    <li><a target="_top" href="ca/text/shared/main0103.html?DbPAR=DRAW">Visualitza</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main_insert.html?DbPAR=DRAW">Insereix</a></li>\
    <li><a target="_top" href="ca/text/shared/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main_page.html?DbPAR=DRAW">Pàgina</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="ca/text/shared/main_tools.html?DbPAR=DRAW">Main Tools Menu</a></li>\
    <li><a target="_top" href="ca/text/shared/main0107.html?DbPAR=DRAW">Finestra</a></li>\
    <li><a target="_top" href="ca/text/shared/main0108.html?DbPAR=DRAW">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barres d&#39;eines</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/main0200.html?DbPAR=DRAW">Barres d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Paràmetres 3D</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main0210.html?DbPAR=DRAW">Barra de dibuix</a></li>\
    <li><a target="_top" href="ca/text/shared/main0227.html?DbPAR=DRAW">Barra Edita els punts</a></li>\
    <li><a target="_top" href="ca/text/shared/02/find_toolbar.html?DbPAR=DRAW">Barra Cerca</a></li>\
    <li><a target="_top" href="ca/text/shared/main0226.html?DbPAR=DRAW">Barra d&#39;eines Disseny del formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/main0213.html?DbPAR=DRAW">Barra Navegació de formularis</a></li>\
    <li><a target="_top" href="ca/text/sdraw/main0213.html?DbPAR=DRAW">Barra d&#39;opcions</a></li>\
    <li><a target="_top" href="ca/text/shared/main0201.html?DbPAR=DRAW">Barra Estàndard</a></li>\
    <li><a target="_top" href="ca/text/shared/main0204.html?DbPAR=DRAW">Barra Taula</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Càrregues, desaments, importacions i exportacions</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserció de gràfics</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatació</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Càrrega dels estils de línia i de fletxa</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definició de colors personalitzats</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/gradient.html?DbPAR=DRAW">Creació d&#39;emplenaments amb degradats</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Reemplaçament de colors</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Organització, alineació i distribució d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/background.html?DbPAR=DRAW">Canvi de l&#39;emplenament de fons de la diapositiva</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/move_object.html?DbPAR=DRAW">Moviment d&#39;objectes</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Impressió</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/printing.html?DbPAR=DRAW">Impressió de presentacions</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Impressió d&#39;una diapositiva perquè s&#39;ajusti a la mida del paper</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efectes</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Esvaïment encreuat de dos objectes</a></li>\
    <li><a target="_top" href="ca/text/shared/01/05350000.html?DbPAR=DRAW">Efectes 3D</a></li>\
    <li><a target="_top" href="ca/text/simpress/02/10030000.html?DbPAR=DRAW">Transformacions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objectes, imatges i mapes de bits</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combinació d&#39;objectes i construcció de formes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Dibuix de sectors i de segments</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicació d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Gir d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Assemblatge d&#39;objectes 3D</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Línies de connexió</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/text2curve.html?DbPAR=DRAW">Conversió de caràcters de text en objectes de dibuix</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/vectorize.html?DbPAR=DRAW">Conversió d&#39;imatges de mapa de bits en gràfics vectorials</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/3d_create.html?DbPAR=DRAW">Conversió d&#39;objectes 2D en corbes, polígons i objectes 3D</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Càrrega dels estils de línia i de fletxa</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_draw.html?DbPAR=DRAW">Dibuix de corbes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/line_edit.html?DbPAR=DRAW">Edició de corbes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserció de gràfics</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/table_insert.html?DbPAR=DRAW">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/move_object.html?DbPAR=DRAW">Moviment d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/select_object.html?DbPAR=DRAW">Selecció d&#39;objectes subjacents</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/orgchart.html?DbPAR=DRAW">Creació d&#39;un diagrama de flux</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grups i capes</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/groups.html?DbPAR=DRAW">Agrupació d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/layers.html?DbPAR=DRAW">Quant a les capes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/01/insert_layer.html?DbPAR=DRAW">Insereix una capa</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Treball amb capes</a></li>\
    <li><a target="_top" href="ca/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moure objectes a una capa diferent</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text en dibuixos</label><ul>\
    <li><a target="_top" href="ca/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Addició de text</a></li>\
    <li><a target="_top" href="ca/text/simpress/guide/text2curve.html?DbPAR=DRAW">Conversió de caràcters de text en objectes de dibuix</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visualització</label><ul>\
    <li><a target="_top" href="ca/text/simpress/guide/change_scale.html?DbPAR=DRAW">Canvi d&#39;escala amb el teclat numèric</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funcions de les bases de dades (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informació general</label><ul>\
    <li><a target="_top" href="ca/text/sdatabase/main.html?DbPAR=BASE">Base de dades del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/database_main.html?DbPAR=BASE">Visió general de les bases de dades</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_new.html?DbPAR=BASE">Creació d&#39;una base de dades nova</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_tables.html?DbPAR=BASE">Treballar amb taules</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_queries.html?DbPAR=BASE">Treballar amb consultes</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_forms.html?DbPAR=BASE">Treballar amb formularis</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_reports.html?DbPAR=BASE">Creació d&#39;informes</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_register.html?DbPAR=BASE">Registre i supressió d&#39;una base de dades</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_im_export.html?DbPAR=BASE">Importació i exportació de dades amb el Base</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Execució d&#39;ordres SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Fórmules (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/smath/main0000.html?DbPAR=MATH">Us donem la benvinguda a l&#39;Ajuda del LibreOffice Math</a></li>\
    <li><a target="_top" href="ca/text/smath/main0503.html?DbPAR=MATH">Funcions del LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elements de fórmula del LibreOffice</label><ul>\
    <li><a target="_top" href="ca/text/smath/01/03090100.html?DbPAR=MATH">Operadors unaris i binaris</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090200.html?DbPAR=MATH">Relacions</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090800.html?DbPAR=MATH">Operacions amb conjunts</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090400.html?DbPAR=MATH">Funcions</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090300.html?DbPAR=MATH">Operadors</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090600.html?DbPAR=MATH">Atributs</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090500.html?DbPAR=MATH">Claudàtors</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="ca/text/smath/01/03091600.html?DbPAR=MATH">Altres símbols</a></li>\
      </ul></li>\
    <li><a target="_top" href="ca/text/smath/guide/main.html?DbPAR=MATH">Instruccions per a utilitzar el LibreOffice Math</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/keyboard.html?DbPAR=MATH">Dreceres (accessibilitat del LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Referència de les ordres i menús</label><ul>\
    <li><a target="_top" href="ca/text/smath/main0100.html?DbPAR=MATH">Menús</a></li>\
    <li><a target="_top" href="ca/text/smath/main0200.html?DbPAR=MATH">Barres d&#39;eines</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Treball amb fórmules</label><ul>\
    <li><a target="_top" href="ca/text/smath/guide/align.html?DbPAR=MATH">Alineació manual de les parts d&#39;una fórmula</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/color.html?DbPAR=MATH">Aplicació de colors a parts de la fórmula</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/attributes.html?DbPAR=MATH">Canviar els atributs per defecte</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/brackets.html?DbPAR=MATH">Fusió de les parts de la fórmula entre claudàtors</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/comment.html?DbPAR=MATH">Introducció de comentaris</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/newline.html?DbPAR=MATH">Introducció de salts de línia</a></li>\
    <li><a target="_top" href="ca/text/smath/guide/parentheses.html?DbPAR=MATH">Inserció de claudàtors</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Diagrames i gràfics</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informació general</label><ul>\
    <li><a target="_top" href="ca/text/schart/main0000.html?DbPAR=CHART">Diagrames del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/schart/main0503.html?DbPAR=CHART">Funcionalitats de diagrama del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/schart/04/01020000.html?DbPAR=CHART">Dreceres per als diagrames</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros i creació de scripts</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/main0601.html?DbPAR=BASIC">Ajuda del LibreOffice Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programació amb el LibreOffice Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glossari del LibreOffice Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01010210.html?DbPAR=BASIC">Bàsics</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaxi</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01050000.html?DbPAR=BASIC">EID del LibreOffice Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01030100.html?DbPAR=BASIC">Visió general de l&#39;EID</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01030200.html?DbPAR=BASIC">Editor del Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01050100.html?DbPAR=BASIC">Finestra Observador</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barra d&#39;eines de macro</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Implementació de macros VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Referència d&#39;ordres</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Opcions del compilador</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020300.html?DbPAR=BASIC">Ús dels procediments, les funcions i les propietats</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020500.html?DbPAR=BASIC">Biblioteques, mòduls i diàlegs</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagrames sintàctics</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funcions, expressions i operadors</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/03040000.html?DbPAR=BASIC">Constants del Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variables</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operadors lògics</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadors de comparació</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120000.html?DbPAR=BASIC">Cadenes</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funcions Date i Time</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operadors matemàtics</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funcions numèriques</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funcions trigonomètriques</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funcions d&#39;E/S de pantalla</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funcions d&#39;E/S de fitxer</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090000.html?DbPAR=BASIC">Control de l&#39;execució del programa</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funcions de gestió d&#39;errors</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130000.html?DbPAR=BASIC">Altres ordres</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generació de nombres aleatoris</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Objectes de l&#39;UNO</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Ús de les funcions del Calc a les macros</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Funcions exclusives del VBA</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/vba_objects.html?DbPAR=BASIC">Objectes que admet VBA</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090400.html?DbPAR=BASIC">Més expressions</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Llista alfabètica de funcions, d&#39;expressions i d&#39;operadors</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funció Abs</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operador AND</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funció Array</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funció Asc</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funció AscW</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funció Atn</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130100.html?DbPAR=BASIC">Expressió Beep</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funció Blue</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090401.html?DbPAR=BASIC">Expressió Call</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/CallByName.html?DbPAR=BASIC">Funció CallByName</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090102.html?DbPAR=BASIC">Expressió Select… Case</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funció CBool</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funció CByte</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funció CCur</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funció CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funció CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funció CDateFromUnoTime</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funció CDateToUnoTime</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funció CDateFromUnoDate</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funció CDateToUnoDate</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funció CDateFromIso</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funció CDateTolso</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funció CDate</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funció CDbl</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funció CDec</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020401.html?DbPAR=BASIC">Expressió ChDir</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020402.html?DbPAR=BASIC">Expressió ChDrive</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090402.html?DbPAR=BASIC">Funció Choose</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funció Chr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120112.html?DbPAR=BASIC">Funció ChrW [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funció CInt</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funció CLng</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instrucció Close</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/collection.html?DbPAR=BASIC">Objecte Collection</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100700.html?DbPAR=BASIC">Expressió Const</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funció ConvertFromURL</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funció ConvertToURL</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funció Cos</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funció CreateObject</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funció CreateUnoDialog</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funció CreateUnoListener</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funció CreateUnoService</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/CreateUnoSvcWithArgs.html?DbPAR=BASIC">Funció CreateUnoServiceWithArguments</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funció CreateUnoStruct</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funció CreateUnoValue</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funció CSng</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funció CStr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funció CurDir</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funció CVar</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funció CVErr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funció DateAdd</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funció DateDiff</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funció DatePart</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funció DateSerial</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funció DateValue</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funció Day</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140000.html?DbPAR=BASIC">Funció DDB [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090403.html?DbPAR=BASIC">Expressió Declare</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101100.html?DbPAR=BASIC">Expressió DefBool</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101110.html?DbPAR=BASIC">Expressió DefCur</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101300.html?DbPAR=BASIC">Expressió DefDate</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101400.html?DbPAR=BASIC">Expressió DefDbl</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101120.html?DbPAR=BASIC">Expressió DefErr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101500.html?DbPAR=BASIC">Expressió DefInt</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101600.html?DbPAR=BASIC">Expressió DefLng</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101700.html?DbPAR=BASIC">Expressió DefObj</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101130.html?DbPAR=BASIC">Expressió DefSng</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03101140.html?DbPAR=BASIC">Expressió DefStr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102000.html?DbPAR=BASIC">Expressió DefVar</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funció DimArray</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102100.html?DbPAR=BASIC">Expressió Dim</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funció Dir</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090201.html?DbPAR=BASIC">Expressió Do… Loop</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/doEvents.html?DbPAR=BASIC">Funció DoEvents</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090404.html?DbPAR=BASIC">Expressió End</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funció Environ</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funció Eof</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funció EqualUnoObjects</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operador Eqv</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funció Erl</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funció Err</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funció Error</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funcions de gestió d&#39;errors</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090412.html?DbPAR=BASIC">Expressió Exit</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funció Exp</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funció FileAttr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020406.html?DbPAR=BASIC">Expressió FileCopy</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funció FileDateTime</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funció FileExists</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funció FileLen</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funció FindObject</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funció FindPropertyObject</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funció Fix</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090202.html?DbPAR=BASIC">Expressió For… Next</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090202.html?DbPAR=BASIC">Expressió For… Next</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funció Format</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funció FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03170010.html?DbPAR=BASIC">Funció FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03170020.html?DbPAR=BASIC">Funció FormatPercent [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080503.html?DbPAR=BASIC">Funció Frac</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funció FreeFile</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funció FreeLibrary</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090406.html?DbPAR=BASIC">Expressió Function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140001.html?DbPAR=BASIC">Funció FV [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funció GetAttr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funció GetDefaultContext</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funció GetGuiType</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funció GetProcessServiceManager</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funció GetSolarVersion</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funció GetSystemTicks</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020201.html?DbPAR=BASIC">Expressió Get</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103450.html?DbPAR=BASIC">Expressió Global</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090301.html?DbPAR=BASIC">Expressió GoSub… Return</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090302.html?DbPAR=BASIC">Expressió GoTo</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funció Green</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funció HasUnoInterfaces</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funció Hex</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funció Hour</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090101.html?DbPAR=BASIC">Expressió If… Then… Else</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operador Imp</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funció InStr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funció InStrRev [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funció Input [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funció InputBox</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020202.html?DbPAR=BASIC">Expressió Input#</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funció Int</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funció IPmt [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140003.html?DbPAR=BASIC">Funció IRR [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Operador Is</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funció IsArray</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funció IsDate</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funció IsEmpty</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102450.html?DbPAR=BASIC">Funció IsError</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funció IsMissing</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funció IsNull</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funció IsNumeric</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funció IsObject</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funció IsUnoStruct</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funció Join</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020410.html?DbPAR=BASIC">Expressió Kill</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102900.html?DbPAR=BASIC">Funció LBound</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funció LCase</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120304.html?DbPAR=BASIC">Expressió LSet</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funció LTrim</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funció Left</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funció Len</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103100.html?DbPAR=BASIC">Expressió Let</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funció Loc</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funció Lof</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funció Log</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120306.html?DbPAR=BASIC">Funció Mid, Expressió Mid</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funció Minute</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funció MIRR [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020411.html?DbPAR=BASIC">Expressió MkDir</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operador Mod</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funció Month</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funció MonthName [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funció MsgBox</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020412.html?DbPAR=BASIC">Expressió Name</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">Operador New</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operador Not</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funció Now</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funció NPer [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funció NPV [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funcions numèriques</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funció Oct</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03050500.html?DbPAR=BASIC">Expressió On Error GoTo … Resume</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090303.html?DbPAR=BASIC">Expressió On… GoSub; Expressió On… GoTo</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instrucció Open</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103200.html?DbPAR=BASIC">Expressió Option Base</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103300.html?DbPAR=BASIC">Expressió Option Explicit</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103350.html?DbPAR=BASIC">Expressió Option VBASupport</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (a l&#39;expressió Function)</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operador Or</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funció Pmt [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funció PPmt [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103400.html?DbPAR=BASIC">Expressió Public</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funció PV [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funció QBColor</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funció Rate [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080301.html?DbPAR=BASIC">Expressió Randomize</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03102101.html?DbPAR=BASIC">Expressió ReDim</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funció Red</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090407.html?DbPAR=BASIC">Expressió Rem</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/replace.html?DbPAR=BASIC">Funció Replace</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020104.html?DbPAR=BASIC">Expressió Reset</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funció RGB</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03010306.html?DbPAR=BASIC">Funció RGB [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funció Right</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020413.html?DbPAR=BASIC">Expressió RmDir</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funció Rnd</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funció Round [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120308.html?DbPAR=BASIC">Expressió RSet</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funció RTrim</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funció Second</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funció Seek</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090102.html?DbPAR=BASIC">Expressió Select… Case</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020414.html?DbPAR=BASIC">Expressió SetAttr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103700.html?DbPAR=BASIC">Expressió Set</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funció Sgn</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funció Shell</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funció Sin</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140011.html?DbPAR=BASIC">Funció SLN [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funcions Space i Spc</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funcions Space i Spc</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funció Split</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funció Sqr</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080400.html?DbPAR=BASIC">Càlcul de l&#39;arrel quadrada</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Objecte StarDesktop</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103500.html?DbPAR=BASIC">Expressió Static</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090408.html?DbPAR=BASIC">Expressió Stop</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funció StrComp</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funció Str</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funció StrReverse [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funció String</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090409.html?DbPAR=BASIC">Expressió Sub</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funció Switch</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funció SYD [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funció Tan</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objecte ThisComponent</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">Objecte ThisDatabaseDocument</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funció TimeSerial</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funció TimeValue</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funció Timer</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funció Trim</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funció TwipsPerPixelX</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funció TwipsPerPixelY</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090413.html?DbPAR=BASIC">Expressió Type</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funció TypeName; Funció VarType</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funció UBound</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funció UCase</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funció Val</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130600.html?DbPAR=BASIC">Expressió Wait</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03130610.html?DbPAR=BASIC">Expressió WaitUntil</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funció WeekDay</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funció WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090203.html?DbPAR=BASIC">Expressió While… Wend</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03090411.html?DbPAR=BASIC">Expressió With</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03020205.html?DbPAR=BASIC">Expressió Write</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operador XOR</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funció Year</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operador «-»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operador «*»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operador «+»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operador «/»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070700.html?DbPAR=BASIC">Operador «\»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operador «^»</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03120300.html?DbPAR=BASIC">Edició del contingut de les cadenes</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020100.html?DbPAR=BASIC">Ús de variables</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagrames sintàctics</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Biblioteques avançades del Basic</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteca Tools</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteca DEPOT</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteca EURO</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteca FORMWIZARD</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteca GIMMICKS</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Biblioteca ImportWizard</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteca SCHEDULE</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteca SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteca TEMPLATE</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Biblioteca WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Biblioteca ScriptForge</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Biblioteques ScriptForge</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_toc.html?DbPAR=BASIC">Llista de tots els mètodes i propietats de l&#39;ScriptForge</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">Servei SFDocuments.Base</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">Servei ScriptForge.Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">Servei SFDocuments.Calc</a></li>\
    <li><input type="checkbox" id="07010501"><label for="07010501">Example Scripts</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/guide/read_write_values.html?DbPAR=BASIC">Lectura i escriptura de valors als intervals</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/calc_borders.html?DbPAR=BASIC">Formatació de les vores al Calc amb macros</a></li>\
            </ul></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">Servei SFDocuments.Chart</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">Servei SFDatabases.Database</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_dataset.html?DbPAR=BASIC">Servei SFDatabases.Dataset</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_datasheet.html?DbPAR=BASIC">Servei SFDatabases.Datasheet</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">Servei SFDialogs.Dialog</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">Servei SFDialogs.DialogControl</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">Servei ScriptForge.Dictionary</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">Servei SFDocuments.Document</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">Servei ScriptForge.Exception (SF_Exception)</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">Servei ScriptForge.FileSystem</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">Servei SFDocuments.Form</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">Servei SFDocuments.FormControl</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_formdocument.html?DbPAR=BASIC">Servei SFDocuments.FormDocument</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">Servei ScriptForge.L10N</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">Servei SFWidgets.Menu</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">Servei ScriptForge.Platform</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">Servei SFWidgets.PopupMenu</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">Servei ScriptForge.Region</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">Servei ScriptForge.Services</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">Servei ScriptForge.Session</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">Servei ScriptForge.String (SF_String)</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">Servei ScriptForge.TextStream</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">Servei ScriptForge.Timer</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_toolbar.html?DbPAR=BASIC">Servei SFWidgets.Toolbar</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_toolbarbutton.html?DbPAR=BASIC">Servei SFWidgets.ToolbarButton</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">Servei ScriptForge.UI</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">Servei SFUnitTests.UnitTest</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">Servei SFDocuments.Writer</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guies</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/macro_recording.html?DbPAR=BASIC">Enregistrament d&#39;una macro</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Canvi de les propietats dels controls de l&#39;editor de diàlegs</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Creació de controls a l&#39;editor de diàlegs</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programació d&#39;exemples per als controls de l&#39;editor de diàlegs</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Obertura d&#39;un diàleg amb Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Creació d&#39;un diàleg amb Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organització de biblioteques i mòduls</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020100.html?DbPAR=BASIC">Ús de variables</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01020200.html?DbPAR=BASIC">Ús d&#39;objectes</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01030300.html?DbPAR=BASIC">Depuració d&#39;un programa del Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/shared/01040000.html?DbPAR=BASIC">Documenta les macros generades per esdeveniments</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Exemples de programació en Basic</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">De BASIC a Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Ajuda de scripts de Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informació general i ús de la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/python/main0000.html?DbPAR=BASIC">Scripts en Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE per a Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organització dels scripts en Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_shell.html?DbPAR=BASIC">Consola interactiva de Python</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programació en Python</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: programació amb el Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_examples.html?DbPAR=BASIC">Exemples en Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">De Python a Basic</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070203"><label for="070203">Mòduls de Python</label><ul>\
    <li><a target="_top" href="ca/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Biblioteques ScriptForge</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: programació amb el Python</a></li>\
    <li><a target="_top" href="ca/text/sbasic/python/python_screen.html?DbPAR=BASIC">Python: entrada i sortida de i cap a la pantalla</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Eines de desenvolupament de scripts</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/dev_tools.html?DbPAR=BASIC">Eines de desenvolupament</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instal·lació del LibreOffice</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Canvi de l&#39;associació dels tipus de documents del Microsoft Office</a></li>\
    <li><a target="_top" href="ca/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Mode segur</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Temes d&#39;ajuda comuns</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informació general</label><ul>\
    <li><a target="_top" href="ca/text/shared/main0400.html?DbPAR=SHARED">Tecles de drecera</a></li>\
    <li><a target="_top" href="ca/text/shared/00/00000005.html?DbPAR=SHARED">Glossari general</a></li>\
    <li><a target="_top" href="ca/text/shared/00/00000002.html?DbPAR=SHARED">Glossari de termes d&#39;Internet</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/accessibility.html?DbPAR=SHARED">Accessibilitat al LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/keyboard.html?DbPAR=SHARED">Dreceres (accessibilitat del LibreOffice)</a></li>\
    <li><a target="_top" href="ca/text/shared/04/01010000.html?DbPAR=SHARED">Tecles de drecera generals del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/version_number.html?DbPAR=SHARED">Números de versió i de muntatge</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">El LibreOffice i el Microsoft Office</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/ms_user.html?DbPAR=SHARED">Ús del Microsoft Office i del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparació dels termes del Microsoft Office i del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Quant a la conversió de documents del Microsoft Office</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Canvi de l&#39;associació dels tipus de documents del Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opcions del LibreOffice</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01000000.html?DbPAR=SHARED">Opcions</a></li>\
    <li><input type="checkbox" id="100401"><label for="100401">LibreOffice</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01010100.html?DbPAR=SHARED">Dades de l&#39;usuari</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010600.html?DbPAR=SHARED">General</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010800.html?DbPAR=SHARED">Visualització</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010900.html?DbPAR=SHARED">Opcions d&#39;impressió</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010300.html?DbPAR=SHARED">Camins</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010700.html?DbPAR=SHARED">Lletres tipogràfiques</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01030300.html?DbPAR=SHARED">Seguretat</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01012000.html?DbPAR=SHARED">Aparença</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/java.html?DbPAR=SHARED">Avançat</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Configuració avançada</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01013000.html?DbPAR=SHARED">Accessibilitat</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100402"><label for="100402">Carrega/desa</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01010200.html?DbPAR=SHARED">General</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01020000.html?DbPAR=SHARED">Opcions de Carrega o desa</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01130100.html?DbPAR=SHARED">Propietats VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100403"><label for="100403">Languages and Locales</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01140000.html?DbPAR=SHARED">Llengües (Opcions)</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01150000.html?DbPAR=SHARED">Opcions de configuració de la llengua</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01010400.html?DbPAR=SHARED">Ajudes a l&#39;escriptura</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100404"><label for="100404">LibreOffice Writer</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01040000.html?DbPAR=SHARED">Opcions del document de text</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100405"><label for="100405">LibreOffice Writer/Web</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01050000.html?DbPAR=SHARED">Opcions del document HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100406"><label for="100406">LibreOffice Calc</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01060000.html?DbPAR=SHARED">Opcions del full de càlcul</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100407"><label for="100407">LibreOffice Impress</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01070000.html?DbPAR=SHARED">Opcions de la presentació</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100408"><label for="100408">LibreOffice Draw</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01080000.html?DbPAR=SHARED">Opcions de dibuix</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100409"><label for="100409">LibreOffice Math</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01090000.html?DbPAR=SHARED">Fórmula</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100410"><label for="100410">LibreOffice Base</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01160000.html?DbPAR=SHARED">Opcions de fonts de dades</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100412"><label for="100412">Diagrames</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01110000.html?DbPAR=SHARED">Opcions del diagrama</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100413"><label for="100413">Internet</label><ul>\
    <li><a target="_top" href="ca/text/shared/optionen/01030000.html?DbPAR=SHARED">Opcions d&#39;Internet</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Auxiliars</label><ul>\
    <li><a target="_top" href="ca/text/shared/autopi/01000000.html?DbPAR=SHARED">Auxiliar</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Auxiliar de cartes</label><ul>\
    <li><a target="_top" href="ca/text/shared/autopi/01010000.html?DbPAR=SHARED">Auxiliar de cartes</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Auxiliar de faxos</label><ul>\
    <li><a target="_top" href="ca/text/shared/autopi/01020000.html?DbPAR=SHARED">Auxiliar de faxos</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Auxiliar d&#39;agendes</label><ul>\
    <li><a target="_top" href="ca/text/shared/autopi/01040000.html?DbPAR=SHARED">Auxiliar d&#39;agendes</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Auxiliar convertidor de documents</label><ul>\
    <li><a target="_top" href="ca/text/shared/autopi/01130000.html?DbPAR=SHARED">Convertidor de documents</a></li>\
      </ul></li>\
    <li><a target="_top" href="ca/text/shared/autopi/01150000.html?DbPAR=SHARED">Auxiliar convertidor d&#39;euros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuració del LibreOffice</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configuració del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/01/packagemanager.html?DbPAR=SHARED">Gestor d&#39;extensions</a></li>\
    <li><a target="_top" href="ca/text/shared/optionen/01012000.html?DbPAR=SHARED">Aparença</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Addició de botons a les barres d&#39;eines</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/workfolder.html?DbPAR=SHARED">Canvi del directori de treball</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registre d&#39;una llibreta d&#39;adreces</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/formfields.html?DbPAR=SHARED">Inserció i edició de botons</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Treball amb la interfície d&#39;usuari</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navegació per arribar als objectes ràpidament</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/navigator.html?DbPAR=SHARED">Navegador per a la visió general de documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/autohide.html?DbPAR=SHARED">Mostrar, amagar i acoblar finestres</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/textmode_change.html?DbPAR=SHARED">Commutació entre el mode d&#39;inserció i el mode de sobreescriptura</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Ús de les barres d&#39;eines</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Signatures digitals</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Quant a les signatures digitals</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Aplicació de signatures digitals</a></li>\
    <li><a target="_top" href="ca/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="ca/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="ca/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signatura de PDF existents</a></li>\
    <li><a target="_top" href="ca/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="ca/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Impressions, faxos i enviaments</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/labels_database.html?DbPAR=SHARED">Impressió d&#39;etiquetes d&#39;adreça</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Impressió en blanc i negre</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/email.html?DbPAR=SHARED">Enviament de documents via correu electrònic</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/fax.html?DbPAR=SHARED">Enviament de faxos i configuració del LibreOffice per enviar faxos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Arrossegar i deixar anar</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop.html?DbPAR=SHARED">Arrossegar i deixar anar dins d&#39;un document del LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Moure i copiar text en documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Còpia d&#39;àrees d&#39;un full de càlcul a documents de text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Còpia de gràfics entre documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserció d&#39;objectes des de la Galeria</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Arrossegar i deixar anar amb la visualització de la font de dades</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copiar i enganxar</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Còpia d&#39;objectes de dibuix a altres documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Còpia de gràfics entre documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserció d&#39;objectes des de la Galeria</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Còpia d&#39;àrees d&#39;un full de càlcul a documents de text</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Diagrames i gràfics</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserció de diagrames</a></li>\
    <li><a target="_top" href="ca/text/schart/main0000.html?DbPAR=SHARED">Diagrames del LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Càrregues, desaments, importacions, exportacions i PDF</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/doc_open.html?DbPAR=SHARED">Obertura de documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/import_ms.html?DbPAR=SHARED">Obertura de documents desats en altres formats</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/doc_save.html?DbPAR=SHARED">Desar documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Desament automàtic de documents</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Ús de fitxers remots</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/export_ms.html?DbPAR=SHARED">Desar documents en altres formats</a></li>\
    <li><a target="_top" href="ca/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exporta com a PDF</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importació i exportació de dades en format de text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Enllaços i referències</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserció d&#39;enllaços</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Enllaços relatius i absoluts</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Edició d&#39;enllaços</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Control de les versions dels documents</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparació de versions d&#39;un document</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Fusió de versions</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Enregistrament de canvis</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining.html?DbPAR=SHARED">Enregistrament i visualització de canvis</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Acceptació o rebuig de canvis</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Gestió de versions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiquetes i targetes de visita</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/labels.html?DbPAR=SHARED">Creació i impressió d&#39;etiquetes i de targetes de visita</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserció de dades externes</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserció de dades des de fulls de càlcul</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserció de dades a partir de documents de text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserir, editar i desar mapes de bits</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Addició de gràfics a la Galeria</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funcions automàtiques</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Desactivació del reconeixement automàtic d&#39;URL</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Cerques i substitucions</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/data_search2.html?DbPAR=SHARED">Cerca amb un filtre de formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_search.html?DbPAR=SHARED">Cerca de taules i de documents de formulari</a></li>\
    <li><a target="_top" href="ca/text/shared/01/02100001.html?DbPAR=SHARED">Llista d&#39;expressions regulars</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guies</label><ul>\
    <li><a target="_top" href="ca/text/shared/guide/linestyles.html?DbPAR=SHARED">Aplicació d&#39;estils de línia</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/text_color.html?DbPAR=SHARED">Canvi del color del text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/change_title.html?DbPAR=SHARED">Canvi del títol d&#39;un document</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/round_corner.html?DbPAR=SHARED">Creació de cantonades arrodonides</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/background.html?DbPAR=SHARED">Definició dels colors de fons o dels gràfics de fons</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definició d&#39;estils de línia</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Edició d&#39;objectes gràfics</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/line_intext.html?DbPAR=SHARED">Dibuix de línies al text</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/aaa_start.html?DbPAR=SHARED">Primers passos</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserció d&#39;objectes des de la Galeria</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserció de caràcters especials</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/tabs.html?DbPAR=SHARED">Inserció i edició de tabulacions</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/protection.html?DbPAR=SHARED">Protecció de continguts al LibreOffice</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Protecció dels registres</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selecció de la màxima àrea imprimible en una pàgina</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selecció d&#39;unitats de mesura</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/language_select.html?DbPAR=SHARED">Selecció de la llengua del document</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Disseny de taula</a></li>\
    <li><a target="_top" href="ca/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Desactivació dels pics i de la numeració per a paràgrafs individuals</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
