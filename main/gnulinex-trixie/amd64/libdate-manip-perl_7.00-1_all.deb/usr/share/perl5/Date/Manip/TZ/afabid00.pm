package #
Date::Manip::TZ::afabid00;
# Copyright (c) 2008-2026 Sullivan Beck.  All rights reserved.
# This program is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'tzdata' is run.
#    Generated on: Tue Sep  1 12:20:28 EDT 2026
#    Data version: tzdata2026c
#    Code version: tzcode2026c

# This module contains data from the zoneinfo time zone database.  The original
# data was obtained from the URL:
#    ftp://ftp.iana.org/tz

use strict;
use warnings;
require 5.010000;

our (%Dates,%LastRule);
END {
   undef %Dates;
   undef %LastRule;
}

our ($VERSION);
$VERSION='7.00';
END { undef $VERSION; }

%Dates         = (
   1    =>
     [
        [ [1,1,2,0,0,0],[1,1,1,23,43,52],'-00:16:08',[0,-16,-8],
          'LMT',0,[1912,1,1,0,16,7],[1911,12,31,23,59,59],
          '0001010200:00:00','0001010123:43:52','1912010100:16:07','1911123123:59:59' ],
     ],
   1912 =>
     [
        [ [1912,1,1,0,16,8],[1912,1,1,0,16,8],'+00:00:00',[0,0,0],
          'GMT',0,[9999,12,31,0,0,0],[9999,12,31,0,0,0],
          '1912010100:16:08','1912010100:16:08','9999123100:00:00','9999123100:00:00' ],
     ],
);

%LastRule      = (
);

1;
