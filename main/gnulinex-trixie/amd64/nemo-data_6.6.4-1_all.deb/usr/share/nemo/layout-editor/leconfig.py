# Generated file - DO NOT EDIT.  Edit config.py.in instead.

LOCALE_DIR="/usr/share/locale"
PACKAGE="nemo"
VERSION="6.6.4"
PKG_DATADIR="/usr/share/nemo"
