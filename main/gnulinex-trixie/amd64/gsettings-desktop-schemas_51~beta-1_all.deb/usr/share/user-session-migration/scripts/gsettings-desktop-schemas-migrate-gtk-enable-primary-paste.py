#!/usr/bin/env python3

# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: 2026 Canonical Ltd.
# SPDX-FileCopyrightText: 2026 Simon McVittie
# SPDX-FileContributor: Alessandro Astone <alessandro.astone@canonical.com>
# SPDX-FileContributor: Simon McVittie <smcv@debian.org>

import sys
from pathlib import Path

import gi
gi.require_version('Gio', '2.0')
from gi.repository import Gio

# Created by the preinst on upgrades from versions less than 50.0;
# not created on new installations
UPGRADE_FLAG = Path("/var/lib/gsettings-desktop-schemas/older-than-v50.stamp")

SCHEMA_ID = 'org.gnome.desktop.interface'
KEY_NAME = 'gtk-enable-primary-paste'
OLD_DEFAULT = True

if UPGRADE_FLAG.exists():
    print(f'Upgraded from GNOME 49 or older, migrating {KEY_NAME}...')
    settings = Gio.Settings.new(SCHEMA_ID)
    user_val = settings.get_user_value(KEY_NAME)

    if user_val is None:
        print(f'Keeping old default {KEY_NAME} = {OLD_DEFAULT}')
        settings.set_boolean(KEY_NAME, OLD_DEFAULT)
        Gio.Settings.sync()
    else:
        print(f'Keeping user setting for {KEY_NAME}')
