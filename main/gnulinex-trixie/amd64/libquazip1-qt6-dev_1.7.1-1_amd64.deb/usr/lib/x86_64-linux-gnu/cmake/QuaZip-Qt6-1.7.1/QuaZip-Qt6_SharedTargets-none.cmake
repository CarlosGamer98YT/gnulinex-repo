#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QuaZip::QuaZip" for configuration "None"
set_property(TARGET QuaZip::QuaZip APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(QuaZip::QuaZip PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libquazip1-qt6.so.1.7.1"
  IMPORTED_SONAME_NONE "libquazip1-qt6.so.1.7"
  )

list(APPEND _cmake_import_check_targets QuaZip::QuaZip )
list(APPEND _cmake_import_check_files_for_QuaZip::QuaZip "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libquazip1-qt6.so.1.7.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
