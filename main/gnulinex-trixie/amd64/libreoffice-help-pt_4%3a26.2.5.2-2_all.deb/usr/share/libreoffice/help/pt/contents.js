document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Documentos de texto (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/swriter/main0000.html?DbPAR=WRITER">Bem-vindo à ajuda do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0503.html?DbPAR=WRITER">Características do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/main.html?DbPAR=WRITER">Instruções de utilização do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Acoplar e redimensionar janelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/04/01020000.html?DbPAR=WRITER">Teclas de atalho para o LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/words_count.html?DbPAR=WRITER">Contagem de palavras</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/keyboard.html?DbPAR=WRITER">Utilizar teclas de atalho (Acessibilidade do LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menus</label><ul>\
    <li><a target="_top" href="pt/text/swriter/main0100.html?DbPAR=WRITER">Menus</a></li>\
    <li><a target="_top" href="pt/text/shared/menu/PickList.html?DbPAR=WRITER">Menu Ficheiro</a></li>\
    <li><a target="_top" href="pt/text/shared/main_edit.html?DbPAR=WRITER">Editar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0103.html?DbPAR=WRITER">Ver</a></li>\
    <li><a target="_top" href="pt/text/shared/main0104.html?DbPAR=WRITER">Inserir</a></li>\
    <li><a target="_top" href="pt/text/shared/main_format.html?DbPAR=WRITER">Formato</a></li>\
    <li><a target="_top" href="pt/text/shared/menu/style_menu.html?DbPAR=WRITER">Estilos (menu)</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0110.html?DbPAR=WRITER">Tabela</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0120.html?DbPAR=WRITER">Menu Formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/main_tools.html?DbPAR=WRITER">Menu principal de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0107.html?DbPAR=WRITER">Janela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0108.html?DbPAR=WRITER">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt/text/swriter/main0200.html?DbPAR=WRITER">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0206.html?DbPAR=WRITER">Barra Marcas e numeração</a></li>\
    <li><a target="_top" href="pt/text/shared/01/classificationbar.html?DbPAR=WRITER">Classification Bar</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0210.html?DbPAR=WRITER">Barra Desenho</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0205.html?DbPAR=WRITER">Barra Propriedades do objeto de desenho</a></li>\
    <li><a target="_top" href="pt/text/shared/02/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="pt/text/shared/02/fontwork_toolbar.html?DbPAR=WRITER">Fontwork</a></li>\
    <li><a target="_top" href="pt/text/shared/02/01170000.html?DbPAR=WRITER">Controlos de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/main0226.html?DbPAR=WRITER">Barra Design de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/main0213.html?DbPAR=WRITER">Barra Navegação em formulários</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0202.html?DbPAR=WRITER">Barra Formatação</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0214.html?DbPAR=WRITER">Barra Fórmula</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0215.html?DbPAR=WRITER">Barra Moldura</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0203.html?DbPAR=WRITER">Barra Imagem</a></li>\
    <li><a target="_top" href="pt/text/swriter/02/18010000.html?DbPAR=WRITER">Inserir</a></li>\
    <li><a target="_top" href="pt/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barra de ferramentas LibreLogo</a></li>\
    <li><a target="_top" href="pt/text/swriter/mailmergetoolbar.html?DbPAR=WRITER">Barra de ferramentas Impressão em série</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0216.html?DbPAR=WRITER">Barra de Objetos OLE</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0210.html?DbPAR=WRITER">Barra de pré-visualização de impressão (Writer)</a></li>\
    <li><a target="_top" href="pt/text/shared/main0214.html?DbPAR=WRITER">Barra Design de consulta</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0213.html?DbPAR=WRITER">Réguas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0201.html?DbPAR=WRITER">Barra Padrão</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0208.html?DbPAR=WRITER">Barra de estado (Writer)</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0204.html?DbPAR=WRITER">Barra Tabela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0212.html?DbPAR=WRITER">Barra Dados da tabela</a></li>\
    <li><a target="_top" href="pt/text/swriter/main0220.html?DbPAR=WRITER">Barra Objeto de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Barra de ferramentas «Controlo de alterações»</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navegação em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navegar e selecionar com o teclado</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Mover e copiar texto em documentos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Reorganizar um documento através do Navegador</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hiperligações com o Navegador</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/navigator.html?DbPAR=WRITER">Navegador para documentos de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Utilizar o cursor direto</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatar documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Alterar orientação da página (horizontal ou vertical)</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_capital.html?DbPAR=WRITER">Alterar as maiúsculas e minúsculas do texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ocultar texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeçalhos e rodapés diferentes</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir um nome e número de capítulo num cabeçalho ou rodapé</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Aplicar formatação de texto ao escrever</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/reset_format.html?DbPAR=WRITER">Repor atributos do tipo de letra</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Aplicar estilos no modo de preenchimento de formato</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/wrap.html?DbPAR=WRITER">Moldar texto em redor de objetos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Utilizar uma moldura para centrar o texto numa página</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Enfatizar texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rodar texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserir e eliminar quebras de página</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Criar e aplicar estilos de página</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/subscript.html?DbPAR=WRITER">Converter um texto em sobrescrito ou subscrito</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Modelos e estilos</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Modelos e estilos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternar estilos de página em páginas ímpares e pares</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/change_header.html?DbPAR=WRITER">Criar um estilo de página com base na página atual</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/load_styles.html?DbPAR=WRITER">Utilizar estilos de outro documento ou modelo</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Criar novos estilos a partir de seleções</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Atualizar estilos a partir de seleções</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/spotlight_styles.html?DbPAR=WRITER">Spotlight Styles</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/template_manager.html?DbPAR=WRITER">Gestor de modelos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Imagens em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserir imagens</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserir uma imagem a partir de um ficheiro</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/gallery_insert.html?DbPAR=WRITER">Inserir objetos da galeria</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserir uma imagem digitalizada</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserir um gráfico do Calc num documento de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserir objetos gráficosimagens do LibreOffice Draw ou Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabelas em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ativar ou desativar o reconhecimento de números em tabelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificar linhas e colunas através do teclado</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/table_delete.html?DbPAR=WRITER">Eliminar tabelas ou conteúdo de uma tabela</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserir tabelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Repetir um cabeçalho de tabela numa nova página</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Redimensionar linhas e colunas numa tabela de texto</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objetos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Posicionar objetos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/wrap.html?DbPAR=WRITER">Moldar texto em redor de objetos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Secções e molduras em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/sections.html?DbPAR=WRITER">Utilizar secções</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserir, editar e associar molduras</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/section_edit.html?DbPAR=WRITER">Editar secções</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserir secções</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Índices remissivos e índices</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeração dos títulos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Índices definidos pelo utilizador</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Criar um índice remissivo</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_index.html?DbPAR=WRITER">Criar índices alfabéticos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Índices que abrangem vários documentos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Criar uma bibliografia</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Editar ou eliminar entradas de índice e tabela</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Atualizar, editar e eliminar índices e índices remissivos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definir entradas de índices ou de índices remissivos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatar um índice ou um índice remissivo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Campos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/fields.html?DbPAR=WRITER">Sobre os campos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir campo de data fixa ou variável</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/field_convert.html?DbPAR=WRITER">Converter um campo em texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/contentcontrols.html?DbPAR=WRITER">Utilização dos controlos de conteúdo no LibreOffice Writer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Cálculos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Efetuar cálculos em várias tabelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate.html?DbPAR=WRITER">Calcular em documentos de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcular e colar o resultado de uma fórmula num documento de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calcular totais de células em tabelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calcular fórmulas complexas em documentos de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Mostrar o resultado de um cálculo de tabela noutra tabela distinta</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elementos de texto especial</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/captions.html?DbPAR=WRITER">Utilizar legendas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Texto condicional</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Texto condicional para número de páginas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir campo de data fixa ou variável</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Adicionar campos de entrada</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserir número de página seguinte</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserir números de páginas em rodapés</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ocultar texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeçalhos e rodapés diferentes</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir um nome e número de capítulo num cabeçalho ou rodapé</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Consultar dados de utilizador nos campos ou condições</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserir e editar notas de rodapé ou notas finais</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Espaçamento entre notas de rodapé</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_footer.html?DbPAR=WRITER">Sobre cabeçalhos e rodapés</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatar cabeçalhos ou rodapés</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/text_animation.html?DbPAR=WRITER">Criar animações de texto</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Criar uma circular</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funções automáticas</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Adicionar exceções à lista Correção automática</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/autotext.html?DbPAR=WRITER">Utilizar texto automático</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Criar listas numeradas ou com marcas ao escrever</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/auto_off.html?DbPAR=WRITER">Desativar a correção automática</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificar ortografia automaticamente</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ativar ou desativar o reconhecimento de números em tabelas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Using Hyphenation</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeração e listas</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Adicionar números de título às legendas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Criar listas numeradas ou com marcas ao escrever</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeração dos títulos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinar listas numeradas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Adicionar números de linha</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definir intervalos de números</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Adicionar numeração</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Adicionar marcas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Corretor ortográfico, sinónimos e idiomas</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificar ortografia automaticamente</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Remover palavras de um dicionário definido pelo utilizador</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Dicionário de sinónimos</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Verificar ortografia e gramática</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Dicas para resolução de problemas</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insert Text Before a Table at the Top of Page</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Avançar para o marcador específico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Carregar, guardar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/send2html.html?DbPAR=WRITER">Guardar documentos de texto em formato HTML</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserir um documento de texto completo</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/auto_redact.html?DbPAR=WRITER">Ocultação automática</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Modelo global de documentos</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Modelos globais de documentos e subdocumentos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Ligações e referências</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/references.html?DbPAR=WRITER">Inserir referências cruzadas</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hiperligações com o Navegador</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Imprimir</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Selecionar bandejas de papel da impressora</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/print_preview.html?DbPAR=WRITER">Pré-visualizar uma página antes de imprimir</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/print_small.html?DbPAR=WRITER">Imprimir várias páginas numa folha</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Criar e aplicar estilos de página</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Localizar e substituir</label><ul>\
    <li><a target="_top" href="pt/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Utilizar expressões regulares em pesquisas</a></li>\
    <li><a target="_top" href="pt/text/shared/01/02100001.html?DbPAR=WRITER">Lista de expressões regulares</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documentos HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="pt/text/shared/07/09000000.html?DbPAR=WRITER">Páginas web</a></li>\
    <li><a target="_top" href="pt/text/shared/02/01170700.html?DbPAR=WRITER">Filtros e formulários HTML</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/send2html.html?DbPAR=WRITER">Guardar documentos de texto em formato HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Folhas de cálculo (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/scalc/main0000.html?DbPAR=CALC">Bem-vindo à ajuda do LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0503.html?DbPAR=CALC">Características do LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/keyboard.html?DbPAR=CALC">Teclas de atalho (Acessibilidade do LibreOffice Calc)</a></li>\
    <li><a target="_top" href="pt/text/scalc/04/01020000.html?DbPAR=CALC">Teclas de atalho em folhas de cálculo</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="pt/text/scalc/05/02140000.html?DbPAR=CALC">Códigos de erro no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060112.html?DbPAR=CALC">Add-in para programação no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/main.html?DbPAR=CALC">Instruções de utilização do LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menus</label><ul>\
    <li><a target="_top" href="pt/text/scalc/main0100.html?DbPAR=CALC">Menus</a></li>\
    <li><a target="_top" href="pt/text/shared/menu/PickList.html?DbPAR=CALC">Menu Ficheiro</a></li>\
    <li><a target="_top" href="pt/text/shared/main_edit.html?DbPAR=CALC">Editar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0103.html?DbPAR=CALC">Ver</a></li>\
    <li><a target="_top" href="pt/text/shared/main0104.html?DbPAR=CALC">Inserir</a></li>\
    <li><a target="_top" href="pt/text/shared/main_format.html?DbPAR=CALC">Formato</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0116.html?DbPAR=CALC">Folha</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0112.html?DbPAR=CALC">Dados</a></li>\
    <li><a target="_top" href="pt/text/shared/main_tools.html?DbPAR=CALC">Menu principal de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0107.html?DbPAR=CALC">Janela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0108.html?DbPAR=CALC">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt/text/scalc/main0200.html?DbPAR=CALC">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/02/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0202.html?DbPAR=CALC">Barra Formatação</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0203.html?DbPAR=CALC">Barra Propriedades do objeto de desenho</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0205.html?DbPAR=CALC">Barra Formatação de texto</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0206.html?DbPAR=CALC">Barra de fórmulas</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0208.html?DbPAR=CALC">Barra de estado</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0210.html?DbPAR=CALC">Barra Pré-visualizar impressão</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0214.html?DbPAR=CALC">Barra Imagem</a></li>\
    <li><a target="_top" href="pt/text/scalc/main0218.html?DbPAR=CALC">Barra Ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0201.html?DbPAR=CALC">Barra Padrão</a></li>\
    <li><a target="_top" href="pt/text/shared/main0212.html?DbPAR=CALC">Barra Dados da tabela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0213.html?DbPAR=CALC">Barra Navegação em formulários</a></li>\
    <li><a target="_top" href="pt/text/shared/main0214.html?DbPAR=CALC">Barra Design de consulta</a></li>\
    <li><a target="_top" href="pt/text/shared/main0226.html?DbPAR=CALC">Barra Design de formulário</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Tipos de funções e operadores</label><ul>\
    <li><a target="_top" href="pt/text/scalc/01/04060000.html?DbPAR=CALC">Assistente de funções</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060100.html?DbPAR=CALC">Funções por categoria</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060107.html?DbPAR=CALC">Funções de matriz</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060120.html?DbPAR=CALC">Funções de operações Bit</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060101.html?DbPAR=CALC">Funções de base de dados</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060102.html?DbPAR=CALC">Funções de data e hora</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060103.html?DbPAR=CALC">Funções financeiras - Parte 1</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060119.html?DbPAR=CALC">Funções Financeiras - Parte Dois</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060118.html?DbPAR=CALC">Funções Financeiras - Parte Três</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060104.html?DbPAR=CALC">Funções de informação</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060105.html?DbPAR=CALC">Funções lógicas</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060106.html?DbPAR=CALC">Funções matemáticas</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060108.html?DbPAR=CALC">Funções estatísticas</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060181.html?DbPAR=CALC">Funções de Estatística - Parte Um</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060182.html?DbPAR=CALC">Funções de Estatística - Parte Dois</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060183.html?DbPAR=CALC">Funções de Estatística - Parte Três</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060184.html?DbPAR=CALC">Funções de Estatística - Parte 4</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060185.html?DbPAR=CALC">Funções de Estatística - Parte Cinco</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060109.html?DbPAR=CALC">Funções de folha de cálculo</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060110.html?DbPAR=CALC">Funções de texto</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060111.html?DbPAR=CALC">Funções Add-in</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060115.html?DbPAR=CALC">Funções add-in, lista de funções de análise - Parte um</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060116.html?DbPAR=CALC">Funções add-in, lista de funções de análise - Parte dois</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/04060199.html?DbPAR=CALC">Operadores no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Funções definidas pelo utilizador</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Carregar, guardar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/webquery.html?DbPAR=CALC">Inserir dados externos na tabela (WebQuery)</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/html_doc.html?DbPAR=CALC">Guardar e abrir folhas em HTML</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importar e exportar ficheiros de texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/auto_redact.html?DbPAR=CALC">Ocultação automática</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatação</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rodar texto</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/text_wrap.html?DbPAR=CALC">Escrever texto em várias linhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatar números como texto</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/super_subscript.html?DbPAR=CALC">Texto sobrescrito/subscrito</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/row_height.html?DbPAR=CALC">Alterar a altura da linha ou a largura da coluna</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Aplicar formatação condicional</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Destacar números negativos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Atribuir formatos por fórmula</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Introduzir números com zeros à esquerda</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/format_table.html?DbPAR=CALC">Formatar folhas de cálculo</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/format_value.html?DbPAR=CALC">Formatar números com casas decimais</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/value_with_name.html?DbPAR=CALC">Nomear células</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rodar tabelas (Transpor)</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/rename_table.html?DbPAR=CALC">Mudar o nome das folhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/year2000.html?DbPAR=CALC">Anos 19xx/20xx</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Utilizar números arredondados</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/currency_format.html?DbPAR=CALC">Células com formato monetário</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/autoformat.html?DbPAR=CALC">Utilizar Formato automático em tabelas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserir e editar comentários</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/design.html?DbPAR=CALC">Selecionar temas para folhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Introduzir frações</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtros e ordenação</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/filters.html?DbPAR=CALC">Aplicar filtros</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/autofilter.html?DbPAR=CALC">Aplicar Filtro automático</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/sorted_list.html?DbPAR=CALC">Aplicar listas de ordenação</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Impressão</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/print_title_row.html?DbPAR=CALC">Imprimir linhas ou colunas em todas as páginas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/print_landscape.html?DbPAR=CALC">Imprimir folhas em formato horizontal</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/print_details.html?DbPAR=CALC">Imprimir detalhes de folhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/print_exact.html?DbPAR=CALC">Definir número de páginas para impressão</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Intervalos de dados</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/database_define.html?DbPAR=CALC">Definir intervalos de base de dados</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrar intervalos de células</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/database_sort.html?DbPAR=CALC">Ordenar dados</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Tabela dinâmica</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot.html?DbPAR=CALC">Tabela dinâmica</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Criar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Eliminar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Editar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selecionar intervalos de saída da tabela dinâmica</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Atualizar tabelas dinâmicas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Gráfico dinâmico</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart.html?DbPAR=CALC">Gráfico dinâmico</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Criar gráficos dinâmicos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editar gráficos dinâmicos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrar gráfico dinâmicos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Atualizar gráficos dinâmicos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Eliminar gráficos dinâmicos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08095"><label for="08095">Análise de dados</label><ul>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_sampling.html?DbPAR=CALC">Data Sampling in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_descriptive.html?DbPAR=CALC">Descriptive Statistics in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_anova.html?DbPAR=CALC">ANOVA</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_correlation.html?DbPAR=CALC">Data Correlation in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_covariance.html?DbPAR=CALC">Data Covariance in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_exposmooth.html?DbPAR=CALC">Exponential Smoothing in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_movingavg.html?DbPAR=CALC">Moving Average in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_regression.html?DbPAR=CALC">Análise de regressão</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_test_t.html?DbPAR=CALC">Paired t-test in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_test_f.html?DbPAR=CALC">F Test Statistics in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_test_z.html?DbPAR=CALC">Z Test Statistics in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_test_chisqr.html?DbPAR=CALC">Chi Square Statistics in Calc</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/statistics_fourier.html?DbPAR=CALC">Fourier Analysis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Cenários</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/scenario.html?DbPAR=CALC">Utilizar cenários</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotal</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Utilização da ferramenta Subtotal</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referências</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Endereços e referências, absolutos e relativos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/r1c1syntax.html?DbPAR=CALC">R1C1 Syntax</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referenciar uma célula noutra folha</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referenciar URLs noutras folhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referenciar células ao arrastar e largar</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/address_auto.html?DbPAR=CALC">Reconhecer nomes como endereço</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Ver, selecionar e copiar</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/table_view.html?DbPAR=CALC">Alterar vistas de tabelas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/formula_value.html?DbPAR=CALC">Mostrar fórmulas ou valores</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/line_fix.html?DbPAR=CALC">Fixar linhas ou colunas como cabeçalhos</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navegar através dos separadores de folhas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copiar para folhas múltiplas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copiar apenas células visíveis</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selecionar várias células</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/move_dragdrop.html?DbPAR=CALC">Mover células ao arrastar e largar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Fórmulas e cálculos</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/formulas.html?DbPAR=CALC">Efetuar cálculos com fórmulas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copiar fórmulas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/formula_enter.html?DbPAR=CALC">Introduzir fórmulas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/formula_value.html?DbPAR=CALC">Mostrar fórmulas ou valores</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/calculate.html?DbPAR=CALC">Calcular em folhas de cálculo</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/calc_date.html?DbPAR=CALC">Calcular com datas e horas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/calc_series.html?DbPAR=CALC">Cálculo automático de série</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Calcular diferenças horárias</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/matrixformula.html?DbPAR=CALC">Introduzir fórmulas matriz</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Proteção</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/cell_protect.html?DbPAR=CALC">Proteger células contra alterações</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Desproteger células</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Escrever macros no Calc</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Ler e escrever valores em intervalos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatar bordas no Calc com macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Diversos</label><ul>\
    <li><a target="_top" href="pt/text/scalc/guide/auto_off.html?DbPAR=CALC">Desativar alterações automáticas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidar dados</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/goalseek.html?DbPAR=CALC">Aplicar Atingir objetivo</a></li>\
    <li><a target="_top" href="pt/text/scalc/01/solver.html?DbPAR=CALC">Sistema de resolução</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/multioperation.html?DbPAR=CALC">Aplicar operações múltiplas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/multitables.html?DbPAR=CALC">Aplicar folhas múltiplas</a></li>\
    <li><a target="_top" href="pt/text/scalc/guide/validity.html?DbPAR=CALC">Validação do conteúdo das células</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Apresentações (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/simpress/main0000.html?DbPAR=IMPRESS">Bem-vindo à ajuda do LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0503.html?DbPAR=IMPRESS">Características do LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Utilizar teclas de atalho no LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt/text/simpress/04/01020000.html?DbPAR=IMPRESS">Teclas de atalho no LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt/text/simpress/04/presenter.html?DbPAR=IMPRESS">Teclas de atalho da Consola do apresentador</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruções de utilização do LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menus</label><ul>\
    <li><a target="_top" href="pt/text/simpress/main0100.html?DbPAR=IMPRESS">Menus</a></li>\
    <li><a target="_top" href="pt/text/shared/menu/PickList.html?DbPAR=IMPRESS">Menu Ficheiro</a></li>\
    <li><a target="_top" href="pt/text/shared/main_edit.html?DbPAR=IMPRESS">Editar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0103.html?DbPAR=IMPRESS">Ver</a></li>\
    <li><a target="_top" href="pt/text/shared/main0104.html?DbPAR=IMPRESS">Inserir</a></li>\
    <li><a target="_top" href="pt/text/shared/main_format.html?DbPAR=IMPRESS">Formato</a></li>\
    <li><a target="_top" href="pt/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapositivo</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0114.html?DbPAR=IMPRESS">Apresentação de diapositivos</a></li>\
    <li><a target="_top" href="pt/text/shared/main_tools.html?DbPAR=IMPRESS">Menu principal de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0107.html?DbPAR=IMPRESS">Janela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0108.html?DbPAR=IMPRESS">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt/text/simpress/main0200.html?DbPAR=IMPRESS">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0210.html?DbPAR=IMPRESS">Barra Desenho</a></li>\
    <li><a target="_top" href="pt/text/shared/main0227.html?DbPAR=IMPRESS">Barra Editar pontos</a></li>\
    <li><a target="_top" href="pt/text/shared/02/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0226.html?DbPAR=IMPRESS">Barra Design de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/main0213.html?DbPAR=IMPRESS">Barra Navegação em formulários</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0214.html?DbPAR=IMPRESS">Barra Imagem</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0202.html?DbPAR=IMPRESS">Barra Linha e preenchimento</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0213.html?DbPAR=IMPRESS">Barra Opções</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0211.html?DbPAR=IMPRESS">Barra Tópicos</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0209.html?DbPAR=IMPRESS">Réguas</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0212.html?DbPAR=IMPRESS">Barra Organizador de diapositivos</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0204.html?DbPAR=IMPRESS">Barra Vista de diapositivos</a></li>\
    <li><a target="_top" href="pt/text/shared/main0201.html?DbPAR=IMPRESS">Barra Padrão</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0206.html?DbPAR=IMPRESS">Barra de estado</a></li>\
    <li><a target="_top" href="pt/text/shared/main0204.html?DbPAR=IMPRESS">Barra Tabela</a></li>\
    <li><a target="_top" href="pt/text/simpress/main0203.html?DbPAR=IMPRESS">Barra Formatação de texto</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Carregar, guardar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importar páginas HTML para apresentações</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animações em formato GIF</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir imagens</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Ocultação automática</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatar</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Carregar estilos de linha e seta</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Criar gradiente de preenchimento</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Substituir cores</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Organizar, alinhar e distribuir objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/background.html?DbPAR=IMPRESS">Alterar o preenchimento do fundo do diapositivo</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/footer.html?DbPAR=IMPRESS">Adicionar um cabeçalho ou um rodapé a todas as páginas</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Alterar e adicionar uma página mestre</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover objetos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Imprimir</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/printing.html?DbPAR=IMPRESS">Imprimir apresentações</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Imprimir um diapositivo para ajustar ao formato do papel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efeitos</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animações em formato GIF</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animar objetos em Diapositivos de apresentação</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Transições de diapositivos animadas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Transição entre dois objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Criar imagens GIF com animações</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objetos, imagens e mapas de bits</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combinar objetos e construir formas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Agrupar objetos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Desenhar setores e segmentos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicar objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformações</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rodar objetos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Compor objetos 3D</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Ligar linhas</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto em objetos de desenho</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Converter imagens de mapas de bits em gráficos vetoriais</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Converter objetos 2D em curvas, polígonos e objetos 3D</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Carregar estilos de linha e seta</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Desenhar curvas</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Editar curvas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir imagens</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Selecionar objetos subjacentes</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Criar um fluxograma</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Texto em apresentações</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Adicionar texto</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto em objetos de desenho</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visualizar</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Alterar a ordem dos diapositivos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Ampliar e reduzir com o teclado</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Apresentação</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/show.html?DbPAR=IMPRESS">Mostrar uma Apresentação de diapositivos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Utilizar a Consola do apresentador</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Guia do Impress Remote</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/individual.html?DbPAR=IMPRESS">Criar uma apresentação de diapositivos personalizada</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Apresentação cronometrada para troca de diapositivos</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Desenhos (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/main0000.html?DbPAR=DRAW">Bem-vindo à ajuda do LibreOffice Draw</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main0503.html?DbPAR=DRAW">Características do LibreOffice Draw</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Teclas de atalho em objetos de desenho</a></li>\
    <li><a target="_top" href="pt/text/sdraw/04/01020000.html?DbPAR=DRAW">Teclas de atalho em desenhos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/main.html?DbPAR=DRAW">Instruções de utilização do LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/main0100.html?DbPAR=DRAW">Menus</a></li>\
    <li><a target="_top" href="pt/text/shared/menu/PickList.html?DbPAR=DRAW">Menu Ficheiro</a></li>\
    <li><a target="_top" href="pt/text/shared/main_edit.html?DbPAR=DRAW">Editar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0103.html?DbPAR=DRAW">Ver</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main_insert.html?DbPAR=DRAW">Inserir</a></li>\
    <li><a target="_top" href="pt/text/shared/main_format.html?DbPAR=DRAW">Formato</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main_page.html?DbPAR=DRAW">Página</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="pt/text/shared/main_tools.html?DbPAR=DRAW">Menu principal de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/main0107.html?DbPAR=DRAW">Janela</a></li>\
    <li><a target="_top" href="pt/text/shared/main0108.html?DbPAR=DRAW">Ajuda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/main0200.html?DbPAR=DRAW">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Definições 3D</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main0210.html?DbPAR=DRAW">Barra Desenho</a></li>\
    <li><a target="_top" href="pt/text/shared/main0227.html?DbPAR=DRAW">Barra Editar pontos</a></li>\
    <li><a target="_top" href="pt/text/shared/02/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="pt/text/shared/main0226.html?DbPAR=DRAW">Barra Design de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/main0213.html?DbPAR=DRAW">Barra Navegação em formulários</a></li>\
    <li><a target="_top" href="pt/text/sdraw/main0213.html?DbPAR=DRAW">Barra Opções</a></li>\
    <li><a target="_top" href="pt/text/shared/main0201.html?DbPAR=DRAW">Barra Padrão</a></li>\
    <li><a target="_top" href="pt/text/shared/main0204.html?DbPAR=DRAW">Barra Tabela</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Carregar, guardar, importar e exportar</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir imagens</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatação</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Carregar estilos de linha e seta</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/gradient.html?DbPAR=DRAW">Criar gradiente de preenchimento</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Substituir cores</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Organizar, alinhar e distribuir objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/background.html?DbPAR=DRAW">Alterar o preenchimento do fundo do diapositivo</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/masterpage.html?DbPAR=DRAW">Alterar e adicionar uma página mestre</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover objetos</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Impressão</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/printing.html?DbPAR=DRAW">Imprimir apresentações</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Imprimir um diapositivo para ajustar ao formato do papel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efeitos</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Transição entre dois objetos</a></li>\
    <li><a target="_top" href="pt/text/shared/01/05350000.html?DbPAR=DRAW">Efeitos 3D</a></li>\
    <li><a target="_top" href="pt/text/simpress/02/10030000.html?DbPAR=DRAW">Transformações</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objetos, imagens e mapas de bits</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combinar objetos e construir formas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Desenhar setores e segmentos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicar objetos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rodar objetos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Compor objetos 3D</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Ligar linhas</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto em objetos de desenho</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/vectorize.html?DbPAR=DRAW">Converter imagens de mapas de bits em gráficos vetoriais</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/3d_create.html?DbPAR=DRAW">Converter objetos 2D em curvas, polígonos e objetos 3D</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Carregar estilos de linha e seta</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_draw.html?DbPAR=DRAW">Desenhar curvas</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/line_edit.html?DbPAR=DRAW">Editar curvas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir imagens</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/table_insert.html?DbPAR=DRAW">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover objetos</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/select_object.html?DbPAR=DRAW">Selecionar objetos subjacentes</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/orgchart.html?DbPAR=DRAW">Criar um fluxograma</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupos e camadas</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/groups.html?DbPAR=DRAW">Agrupar objetos</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/layers.html?DbPAR=DRAW">Acerca de camadas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/01/insert_layer.html?DbPAR=DRAW">Inserir camada</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Trabalhar com camadas</a></li>\
    <li><a target="_top" href="pt/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Mover objetos entre camadas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Texto em desenhos</label><ul>\
    <li><a target="_top" href="pt/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Adicionar texto</a></li>\
    <li><a target="_top" href="pt/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto em objetos de desenho</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visualizar</label><ul>\
    <li><a target="_top" href="pt/text/simpress/guide/change_scale.html?DbPAR=DRAW">Ampliar e reduzir com o teclado</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Bases de dados (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informação genérica</label><ul>\
    <li><a target="_top" href="pt/text/sdatabase/main.html?DbPAR=BASE">Base de dados do LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/database_main.html?DbPAR=BASE">Resumo da base de dados</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_new.html?DbPAR=BASE">Criar uma nova base de dados</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_tables.html?DbPAR=BASE">Trabalhar com tabelas</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_queries.html?DbPAR=BASE">Trabalhar com consultas</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_forms.html?DbPAR=BASE">Trabalhar com formulários</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_reports.html?DbPAR=BASE">Criar relatórios</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_register.html?DbPAR=BASE">Registar e eliminar uma base de dados</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_im_export.html?DbPAR=BASE">Importar e exportar dados no Base</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Executar comandos SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Fórmulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/smath/main0000.html?DbPAR=MATH">Bem-vindo à ajuda do LibreOffice Math</a></li>\
    <li><a target="_top" href="pt/text/smath/main0503.html?DbPAR=MATH">Características do LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elementos de fórmula do LibreOffice</label><ul>\
    <li><a target="_top" href="pt/text/smath/01/03090100.html?DbPAR=MATH">Operadores unários/binários</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090200.html?DbPAR=MATH">Relações</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090800.html?DbPAR=MATH">Operações de conjuntos</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090400.html?DbPAR=MATH">Funções</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090300.html?DbPAR=MATH">Operadores</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090600.html?DbPAR=MATH">Atributos</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090500.html?DbPAR=MATH">Parênteses retos</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03090700.html?DbPAR=MATH">Formato</a></li>\
    <li><a target="_top" href="pt/text/smath/01/03091600.html?DbPAR=MATH">Outros símbolos</a></li>\
      </ul></li>\
    <li><a target="_top" href="pt/text/smath/guide/main.html?DbPAR=MATH">Instruções de utilização do LibreOffice Math</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/keyboard.html?DbPAR=MATH">Atalhos (Acessibilidade do LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Referência de comandos e de menu</label><ul>\
    <li><a target="_top" href="pt/text/smath/main0100.html?DbPAR=MATH">Menus</a></li>\
    <li><a target="_top" href="pt/text/smath/main0200.html?DbPAR=MATH">Barras de ferramentas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Trabalhar com fórmulas</label><ul>\
    <li><a target="_top" href="pt/text/smath/guide/align.html?DbPAR=MATH">Alinhar manualmente partes da fórmula</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/color.html?DbPAR=MATH">Aplicar cor a partes de fórmulas</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/attributes.html?DbPAR=MATH">Alterar atributos padrão</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/brackets.html?DbPAR=MATH">Unir partes da fórmula entre parênteses</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/comment.html?DbPAR=MATH">Introduzir comentários</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/newline.html?DbPAR=MATH">Introduzir quebras de linha</a></li>\
    <li><a target="_top" href="pt/text/smath/guide/parentheses.html?DbPAR=MATH">Introduzir parênteses</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Gráficos e diagramas</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informações gerais</label><ul>\
    <li><a target="_top" href="pt/text/schart/main0000.html?DbPAR=CHART">Gráficos no LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/schart/main0503.html?DbPAR=CHART">Características do LibreOffice Chart</a></li>\
    <li><a target="_top" href="pt/text/schart/04/01020000.html?DbPAR=CHART">Atalhos para gráficos</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros e scripts</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/main0601.html?DbPAR=BASIC">Ajuda do LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programação com o LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glossário do LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01010210.html?DbPAR=BASIC">Princípios básicos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaxe</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01030100.html?DbPAR=BASIC">Resumo do IDE</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01030200.html?DbPAR=BASIC">O Editor Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01050100.html?DbPAR=BASIC">Janela de monitorização</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barra de ferramentas Macro</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Suporte para macros VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Referência de comandos</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Opções do compilador</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020300.html?DbPAR=BASIC">Utilização de procedimentos, funções ou propriedades</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliotecas, módulos e caixas de diálogo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagramas de sintaxe</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funções, instruções e operadores</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/03040000.html?DbPAR=BASIC">Constantes do BASIC</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variáveis</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operadores lógicos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadores de comparação</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120000.html?DbPAR=BASIC">Cadeias</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funções de data e hora</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operadores matemáticos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funções numéricas</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funções trigonométricas</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funções de E/S de ecrã</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funções de E/S de ficheiro</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090000.html?DbPAR=BASIC">Controlar a execução do programa</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funções de tratamento de erros</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130000.html?DbPAR=BASIC">Outros comandos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080300.html?DbPAR=BASIC">Gerar números aleatórios</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Objetos do UNO</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Utilização das funções do Calc em macros</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Funções VBA exclusivas</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/vba_objects.html?DbPAR=BASIC">Objetos suportados pelo VBA</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090400.html?DbPAR=BASIC">Mais instruções</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Lista alfabética de funções, instruções e operadores</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080601.html?DbPAR=BASIC">Função Abs</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operador AND</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104200.html?DbPAR=BASIC">Função Array</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120101.html?DbPAR=BASIC">Função Asc</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120111.html?DbPAR=BASIC">Função AscW</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080101.html?DbPAR=BASIC">Função Atn</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130100.html?DbPAR=BASIC">Instrução Beep</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010301.html?DbPAR=BASIC">Função Blue</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090401.html?DbPAR=BASIC">Instrução Call</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/CallByName.html?DbPAR=BASIC">Função CallByName</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090102.html?DbPAR=BASIC">Instrução Select...Case</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100100.html?DbPAR=BASIC">Função CBool</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120105.html?DbPAR=BASIC">Função CByte</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100050.html?DbPAR=BASIC">Função CCur</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030116.html?DbPAR=BASIC">Função CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030115.html?DbPAR=BASIC">Função CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030114.html?DbPAR=BASIC">Função CDateFromUnoTime</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030113.html?DbPAR=BASIC">Función CDateToUnoTime</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030112.html?DbPAR=BASIC">Função CDateFromUnoDate</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030111.html?DbPAR=BASIC">Função CDateToUnoDate</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030108.html?DbPAR=BASIC">Função CDateFromlso</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030107.html?DbPAR=BASIC">Função CDateToIso</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100300.html?DbPAR=BASIC">Função CDate</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100400.html?DbPAR=BASIC">Função CDbl</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100060.html?DbPAR=BASIC">Função CDec</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020401.html?DbPAR=BASIC">Instrução ChDir</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020402.html?DbPAR=BASIC">Instrução ChDrive</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090402.html?DbPAR=BASIC">Função Choose</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120102.html?DbPAR=BASIC">Função Chr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120112.html?DbPAR=BASIC">Função ChrW [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100500.html?DbPAR=BASIC">Função CInt</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100600.html?DbPAR=BASIC">Função Clng</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instrução Close</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/collection.html?DbPAR=BASIC">Objeto de coleção</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100700.html?DbPAR=BASIC">Instrução Const</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120313.html?DbPAR=BASIC">Função ConvertFromURL</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120312.html?DbPAR=BASIC">Função ConvertToURL</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080102.html?DbPAR=BASIC">Função Cos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132400.html?DbPAR=BASIC">Função CreateObject</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131800.html?DbPAR=BASIC">Função CreateUnoDialog</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132000.html?DbPAR=BASIC">Função CreateUnoListener</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131600.html?DbPAR=BASIC">Função CreateUnoService</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/CreateUnoSvcWithArgs.html?DbPAR=BASIC">Função CreateUnoServiceWithArguments</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131500.html?DbPAR=BASIC">Função CreateUnoStruct</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132300.html?DbPAR=BASIC">Função CreateUnoValue</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100900.html?DbPAR=BASIC">Função CSng</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101000.html?DbPAR=BASIC">Função CStr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020403.html?DbPAR=BASIC">Função CurDir</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100070.html?DbPAR=BASIC">Função CVar</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03100080.html?DbPAR=BASIC">Função CVErr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030301.html?DbPAR=BASIC">Função de data</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030110.html?DbPAR=BASIC">Função DateAdd</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030120.html?DbPAR=BASIC">Função DateDiff</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030130.html?DbPAR=BASIC">Função DatePart</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030101.html?DbPAR=BASIC">Função DateSerial</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030102.html?DbPAR=BASIC">Função DateValue</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030103.html?DbPAR=BASIC">Função Day</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140000.html?DbPAR=BASIC">Função DDB [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090403.html?DbPAR=BASIC">Instrução Declare</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101100.html?DbPAR=BASIC">Instrução DefBool</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101110.html?DbPAR=BASIC">Instrução DefCur</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101300.html?DbPAR=BASIC">Instrução DefDate</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101400.html?DbPAR=BASIC">Instrução DefDbl</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101120.html?DbPAR=BASIC">Instrução DefErr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101500.html?DbPAR=BASIC">Instrução DefInt</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101600.html?DbPAR=BASIC">Instrução DefLng</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101700.html?DbPAR=BASIC">Instrução DefObj</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101130.html?DbPAR=BASIC">Instrução DefSng</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03101140.html?DbPAR=BASIC">Instrução DefStr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102000.html?DbPAR=BASIC">Instrução DefVar</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104300.html?DbPAR=BASIC">Função DimArray</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102100.html?DbPAR=BASIC">Instrução Dim</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020404.html?DbPAR=BASIC">Função Dir</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090201.html?DbPAR=BASIC">Instrução Do...Loop</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/doEvents.html?DbPAR=BASIC">Função DoEvents</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090404.html?DbPAR=BASIC">Instrução End</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/enum.html?DbPAR=BASIC">Instrução Enum</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130800.html?DbPAR=BASIC">Função Environ</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020301.html?DbPAR=BASIC">Função Eof</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104600.html?DbPAR=BASIC">Função EqualUnoObjects</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operador Eqv</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104700.html?DbPAR=BASIC">Instrução de apagamento</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050100.html?DbPAR=BASIC">Função Erl</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050200.html?DbPAR=BASIC">Função Err</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Erro no objeto VBA</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050300.html?DbPAR=BASIC">Função Error</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funções de tratamento de erros</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090412.html?DbPAR=BASIC">Instrução Exit</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080201.html?DbPAR=BASIC">Função Exp</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020405.html?DbPAR=BASIC">Função FileAttr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020406.html?DbPAR=BASIC">Instrução FileCopy</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020407.html?DbPAR=BASIC">Função FileDateTime</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020415.html?DbPAR=BASIC">Função FileExists</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020408.html?DbPAR=BASIC">Função FileLen</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103800.html?DbPAR=BASIC">Função FindObject</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103900.html?DbPAR=BASIC">Função FindPropertyObject</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080501.html?DbPAR=BASIC">Função Fix</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090202.html?DbPAR=BASIC">Instrução For...Next</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090202.html?DbPAR=BASIC">Instrução For...Next</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120301.html?DbPAR=BASIC">Função Format</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03150000.html?DbPAR=BASIC">Função FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03170010.html?DbPAR=BASIC">Função FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03170020.html?DbPAR=BASIC">Função FormatPercent [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080503.html?DbPAR=BASIC">Função Frac</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020102.html?DbPAR=BASIC">Função FreeFile</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090405.html?DbPAR=BASIC">Função FreeLibrary</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090406.html?DbPAR=BASIC">Instrução Function</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140001.html?DbPAR=BASIC">Função FV [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020409.html?DbPAR=BASIC">Função GetAttr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132500.html?DbPAR=BASIC">Função GetDefaultContext</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132100.html?DbPAR=BASIC">Função GetGuiType</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131700.html?DbPAR=BASIC">Função GetProcessServiceManager</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Função GetPathSeparator</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131000.html?DbPAR=BASIC">Função GetSolarVersion</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130700.html?DbPAR=BASIC">Função GetSystemTicks</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020201.html?DbPAR=BASIC">Instrução Get</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103450.html?DbPAR=BASIC">Instrução Global</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090301.html?DbPAR=BASIC">Instrução GoSub...Return</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090302.html?DbPAR=BASIC">Instrução GoTo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010302.html?DbPAR=BASIC">Função Green</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104400.html?DbPAR=BASIC">Função HasUnoInterfaces</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080801.html?DbPAR=BASIC">Função Hex</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030201.html?DbPAR=BASIC">Função Hour</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090103.html?DbPAR=BASIC">Função IIf</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090101.html?DbPAR=BASIC">Instrução If...Then...Else</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operador Imp</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120401.html?DbPAR=BASIC">Função InStr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120411.html?DbPAR=BASIC">Função InStrRev [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03160000.html?DbPAR=BASIC">Função de entrada [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010201.html?DbPAR=BASIC">Função InputBox</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020202.html?DbPAR=BASIC">Instrução Input#</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080502.html?DbPAR=BASIC">Função Int</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140002.html?DbPAR=BASIC">Função IPmt [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140003.html?DbPAR=BASIC">Função IRR [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Operador Is</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102200.html?DbPAR=BASIC">Função IsArray</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102300.html?DbPAR=BASIC">Função IsDate</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102400.html?DbPAR=BASIC">Função IsEmpty</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102450.html?DbPAR=BASIC">Função IsError</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104000.html?DbPAR=BASIC">Função IsMissing</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102600.html?DbPAR=BASIC">Função IsNull</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102700.html?DbPAR=BASIC">Função IsNumeric</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102800.html?DbPAR=BASIC">Função IsObject</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104500.html?DbPAR=BASIC">Função IsUnoStruct</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120315.html?DbPAR=BASIC">Função Join</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020410.html?DbPAR=BASIC">Instrução Kill</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102900.html?DbPAR=BASIC">Função LBound</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120302.html?DbPAR=BASIC">Função LCase</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120304.html?DbPAR=BASIC">Instrução LSet</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120305.html?DbPAR=BASIC">Função LTrim</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120303.html?DbPAR=BASIC">Função Left</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120402.html?DbPAR=BASIC">Função Len</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103100.html?DbPAR=BASIC">Instrução Let</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020203.html?DbPAR=BASIC">Entrada de linha n.º # Declaração</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020302.html?DbPAR=BASIC">Função Loc</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020303.html?DbPAR=BASIC">Função Lof</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080202.html?DbPAR=BASIC">Função Log</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120306.html?DbPAR=BASIC">Função Mid, Instrução Mid</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030202.html?DbPAR=BASIC">Função Minute</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140004.html?DbPAR=BASIC">Função MIRR [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020411.html?DbPAR=BASIC">Instrução MkDir</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operador Mod</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030104.html?DbPAR=BASIC">Função Month</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03150002.html?DbPAR=BASIC">Função MonthName [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010102.html?DbPAR=BASIC">Função MsgBox</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020412.html?DbPAR=BASIC">Instrução Name</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">Novo operador</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operador Not</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030203.html?DbPAR=BASIC">Função Now</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140005.html?DbPAR=BASIC">Função NPer [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140006.html?DbPAR=BASIC">Função NPV [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funções numéricas</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080802.html?DbPAR=BASIC">Função Oct</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03050500.html?DbPAR=BASIC">Instrução On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090303.html?DbPAR=BASIC">Instrução On...GoSub; Instrução On...GoTo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instrução Open</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103200.html?DbPAR=BASIC">Instrução Option Base</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103300.html?DbPAR=BASIC">Instrução Option Explicit</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103350.html?DbPAR=BASIC">Instrução Option VBASupport</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03104100.html?DbPAR=BASIC">Opcional (na instrução Function)</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operador Or</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/partition.html?DbPAR=BASIC">Função de partição</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140007.html?DbPAR=BASIC">Função Pmt [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140008.html?DbPAR=BASIC">Função PPmt [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010103.html?DbPAR=BASIC">Imprimir# Extrato</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/property.html?DbPAR=BASIC">Declaração de bens</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103400.html?DbPAR=BASIC">Instrução Public</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020204.html?DbPAR=BASIC">Instrução Put#</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140009.html?DbPAR=BASIC">Função PV [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010304.html?DbPAR=BASIC">Função QBColor</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140010.html?DbPAR=BASIC">Função Rate [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080301.html?DbPAR=BASIC">Instrução Randomize</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03102101.html?DbPAR=BASIC">Instrução ReDim</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010303.html?DbPAR=BASIC">Função Red</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090407.html?DbPAR=BASIC">Instrução Rem</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/replace.html?DbPAR=BASIC">Função «Substituir»</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020104.html?DbPAR=BASIC">Instrução Reset</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/Resume.html?DbPAR=BASIC">Declaração no currículo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010305.html?DbPAR=BASIC">Função RGB</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03010306.html?DbPAR=BASIC">Função RGB [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120307.html?DbPAR=BASIC">Função Right</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020413.html?DbPAR=BASIC">Instrução RmDir</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080302.html?DbPAR=BASIC">Função Rnd</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03170000.html?DbPAR=BASIC">Função Round [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120308.html?DbPAR=BASIC">Instrução RSet</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120309.html?DbPAR=BASIC">Função RTrim</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030204.html?DbPAR=BASIC">Função Second</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020304.html?DbPAR=BASIC">Função Seek</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020305.html?DbPAR=BASIC">Declaração Seek#</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090102.html?DbPAR=BASIC">Instrução Select...Case</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020414.html?DbPAR=BASIC">Instrução SetAttr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103700.html?DbPAR=BASIC">Instrução Set</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080701.html?DbPAR=BASIC">Função Sgn</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130500.html?DbPAR=BASIC">Função Shell</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080103.html?DbPAR=BASIC">Função Sin</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140011.html?DbPAR=BASIC">Função SLN [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120201.html?DbPAR=BASIC">Função Space e Spc</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120201.html?DbPAR=BASIC">Função Space e Spc</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120314.html?DbPAR=BASIC">Função Split</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080401.html?DbPAR=BASIC">Função Sqr</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080400.html?DbPAR=BASIC">Cálculo de raiz quadrada</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Objeto StarDesktop</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103500.html?DbPAR=BASIC">Instrução Static</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090408.html?DbPAR=BASIC">Instrução Stop</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120403.html?DbPAR=BASIC">Função StrComp</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/strconv.html?DbPAR=BASIC">Função StrConv [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120103.html?DbPAR=BASIC">Função Str</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120412.html?DbPAR=BASIC">Função StrReverse [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120202.html?DbPAR=BASIC">Função String</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090409.html?DbPAR=BASIC">Instrução Sub</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090410.html?DbPAR=BASIC">Função Switch</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03140012.html?DbPAR=BASIC">Função SYD [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03080104.html?DbPAR=BASIC">Função Tan</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objeto ThisComponent</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">Este objeto `DatabaseDocument`</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030205.html?DbPAR=BASIC">Função TimeSerial</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030206.html?DbPAR=BASIC">Função TimeValue</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030302.html?DbPAR=BASIC">Função de tempo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030303.html?DbPAR=BASIC">Função Timer</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120311.html?DbPAR=BASIC">Função Trim</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131300.html?DbPAR=BASIC">Função TwipsPerPixelX</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03131400.html?DbPAR=BASIC">Função TwipsPerPixelY</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090413.html?DbPAR=BASIC">Instrução Type</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103600.html?DbPAR=BASIC">Função TypeName; Função VarType</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03103000.html?DbPAR=BASIC">Função UBound</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120310.html?DbPAR=BASIC">Função UCase</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120104.html?DbPAR=BASIC">Função Val</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130600.html?DbPAR=BASIC">Instrução Wait</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03130610.html?DbPAR=BASIC">Instrução WaitUntil</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030105.html?DbPAR=BASIC">Função WeekDay</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03150001.html?DbPAR=BASIC">Função WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090203.html?DbPAR=BASIC">Instrução While...Wend</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03090411.html?DbPAR=BASIC">Instrução With</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03020205.html?DbPAR=BASIC">Instrução Write</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operador XOR</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03030106.html?DbPAR=BASIC">Função Year</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operador "-"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operador "*"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operador "+"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operador "/"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070700.html?DbPAR=BASIC">Operador "\"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operador "^"</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03120300.html?DbPAR=BASIC">Editar conteúdo de cadeias</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020100.html?DbPAR=BASIC">Utilizar variáveis</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagramas de sintaxe</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Bibliotecas avançadas em BASIC</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteca TOOLS</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteca DEPOT</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteca EURO</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteca FORMWIZARD</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteca GIMMICKS</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Biblioteca ImportWizard</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteca SCHEDULE</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteca SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteca TEMPLATE</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Biblioteca WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Biblioteca ScriptForge</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Bibliotecas ScriptForge</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_toc.html?DbPAR=BASIC">List of all ScriptForge methods and properties</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">Serviço ScriptForge.Array (SF_Array)</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">Serviço SFDocuments.Base</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">Serviço ScriptForge.Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><input type="checkbox" id="07010501"><label for="07010501">Exemplos de scripts</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/guide/read_write_values.html?DbPAR=BASIC">Ler e escrever valores em intervalos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/calc_borders.html?DbPAR=BASIC">Formatar bordas no Calc com macros</a></li>\
            </ul></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">Serviço SFDatabases.Database</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_dataset.html?DbPAR=BASIC">Serviço SFDatabases.Dataset</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_datasheet.html?DbPAR=BASIC">Serviço SFDatabases.Datasheet</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">Serviço SFDialogs.Dialog</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">Serviço SFDialogs.DialogControl</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">Serviço ScriptForge.Dictionary</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">Serviço SFDocuments.Document</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">Serviço ScriptForge.Exception (SF_Exception)</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">Serviço ScriptForge.FileSystem</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_formdocument.html?DbPAR=BASIC">SFDocuments.FormDocument service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_toolbar.html?DbPAR=BASIC">SFWidgets.Toolbar service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_toolbarbutton.html?DbPAR=BASIC">SFWidgets.ToolbarButton service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guias</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/macro_recording.html?DbPAR=BASIC">Gravar uma macro</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Alterar propriedades dos controlos no editor de caixas de diálogo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Criar controlos no Editor de caixas de diálogo</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Exemplos de programação para controlos no editor de caixas de diálogos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Abrir uma caixa de diálogo com Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Criar uma caixa de diálogo do Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organizar bibliotecas e módulos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020100.html?DbPAR=BASIC">Utilizar variáveis</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01020200.html?DbPAR=BASIC">Utilizar objetos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01030300.html?DbPAR=BASIC">Depurar um programa do Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/shared/01040000.html?DbPAR=BASIC">Documentação sobre macros orientadas por eventos</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Exemplos de programação em Basic</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">De Basic para Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Ajuda para scripts em Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/python/main0000.html?DbPAR=BASIC">Scripts em Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE para Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organização de scripts Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_shell.html?DbPAR=BASIC">Consola interativa Python</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programar com Python</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: programar com Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_examples.html?DbPAR=BASIC">Exemplos em Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Do Python ao Basic</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070203"><label for="070203">Módulos Python</label><ul>\
    <li><a target="_top" href="pt/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Bibliotecas ScriptForge</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: programar com Python</a></li>\
    <li><a target="_top" href="pt/text/sbasic/python/python_screen.html?DbPAR=BASIC">O ficheiro de saída padrão do Python não está disponível ao executar macros do Python no menu . Consulte  para mais informações.</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Ferramentas de desenvolvimento de scripts</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instalação do LibreOffice</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Alterar a associação de tipos de documentos do Microsoft Office</a></li>\
    <li><a target="_top" href="pt/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Tópicos de ajuda</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informações gerais</label><ul>\
    <li><a target="_top" href="pt/text/shared/main0400.html?DbPAR=SHARED">Teclas de atalho</a></li>\
    <li><a target="_top" href="pt/text/shared/00/00000005.html?DbPAR=SHARED">Glossário geral</a></li>\
    <li><a target="_top" href="pt/text/shared/00/00000002.html?DbPAR=SHARED">Glossário de termos da Internet</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/accessibility.html?DbPAR=SHARED">Acessibilidade no LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/keyboard.html?DbPAR=SHARED">Atalhos (Acessibilidade do LibreOffice)</a></li>\
    <li><a target="_top" href="pt/text/shared/04/01010000.html?DbPAR=SHARED">Teclas de atalho gerais no LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/version_number.html?DbPAR=SHARED">Versões e números de compilação</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice e Microsoft Office</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/ms_user.html?DbPAR=SHARED">Utilizar o Microsoft Office e o LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparar os termos de utilização do Microsoft Office e do LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Sobre a conversão de documentos do Microsoft Office</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Alterar a associação de tipos de documentos do Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opções do LibreOffice</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01000000.html?DbPAR=SHARED">Opções</a></li>\
    <li><input type="checkbox" id="100401"><label for="100401">LibreOffice</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01010100.html?DbPAR=SHARED">Dados do utilizador</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010600.html?DbPAR=SHARED">Geral</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010800.html?DbPAR=SHARED">Ver</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010900.html?DbPAR=SHARED">Opções de impressão</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010300.html?DbPAR=SHARED">Caminhos</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010700.html?DbPAR=SHARED">Tipos de letra</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01030300.html?DbPAR=SHARED">Segurança</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/java.html?DbPAR=SHARED">Avançado</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Configuração avançada</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE do Basic</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01013000.html?DbPAR=SHARED">Acessibilidade</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100402"><label for="100402">Carregar/Guardar</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01010200.html?DbPAR=SHARED">Geral</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01020000.html?DbPAR=SHARED">Opções Carregar/Guardar</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01130100.html?DbPAR=SHARED">Propriedades de VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100403"><label for="100403">Idiomas e configurações regionais</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01150000.html?DbPAR=SHARED">Opções de definição de idioma</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01010400.html?DbPAR=SHARED">Auxiliares de escrita</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100404"><label for="100404">LibreOffice Writer</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01040000.html?DbPAR=SHARED">Opções de documento de texto</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100405"><label for="100405">LibreOffice Writer/Web</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01050000.html?DbPAR=SHARED">Opções do documento HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100406"><label for="100406">LibreOffice Calc</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01060000.html?DbPAR=SHARED">Opções de folha de cálculo</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100407"><label for="100407">LibreOffice Impress</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01070000.html?DbPAR=SHARED">Opções de apresentação</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100408"><label for="100408">LibreOffice Draw</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01080000.html?DbPAR=SHARED">Opções de desenho</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100409"><label for="100409">LibreOffice Math</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01090000.html?DbPAR=SHARED">Fórmula</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100410"><label for="100410">LibreOffice Base</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01160000.html?DbPAR=SHARED">Opções de origens de dados</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100412"><label for="100412">Gráficos</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01110000.html?DbPAR=SHARED">Opções de gráfico</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100413"><label for="100413">Internet</label><ul>\
    <li><a target="_top" href="pt/text/shared/optionen/01030000.html?DbPAR=SHARED">Opções de Internet</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Assistentes</label><ul>\
    <li><a target="_top" href="pt/text/shared/autopi/01000000.html?DbPAR=SHARED">Assistente</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Assistente de cartas</label><ul>\
    <li><a target="_top" href="pt/text/shared/autopi/01010000.html?DbPAR=SHARED">Assistente de cartas</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Assistente de faxes</label><ul>\
    <li><a target="_top" href="pt/text/shared/autopi/01020000.html?DbPAR=SHARED">Assistente de faxes</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Assistente de agendas</label><ul>\
    <li><a target="_top" href="pt/text/shared/autopi/01040000.html?DbPAR=SHARED">Assistente de agenda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Assistente de conversão de documentos</label><ul>\
    <li><a target="_top" href="pt/text/shared/autopi/01130000.html?DbPAR=SHARED">Conversor de documentos</a></li>\
      </ul></li>\
    <li><a target="_top" href="pt/text/shared/autopi/01150000.html?DbPAR=SHARED">Assistente de conversão de euros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configurar o LibreOffice</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configurar o LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/01/packagemanager.html?DbPAR=SHARED">Gestor de extensões</a></li>\
    <li><a target="_top" href="pt/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Adicionar botões a barras de ferramentas</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/workfolder.html?DbPAR=SHARED">Alterar o diretório de trabalho</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registar um livro de endereços</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/formfields.html?DbPAR=SHARED">Inserir e editar botões</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Trabalhar com a interface</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navegação para objetos Quickly Reach</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/navigator.html?DbPAR=SHARED">Navegador para resumo dos documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/autohide.html?DbPAR=SHARED">Mostrar, acoplar e ocultar janelas</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/textmode_change.html?DbPAR=SHARED">Alternar entre o modo de inserção e o modo de substituição</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Utilizar barras de ferramentas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Assinaturas digitais</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Sobre assinaturas digitais</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Aplicar assinaturas digitais</a></li>\
    <li><a target="_top" href="pt/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="pt/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="pt/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="pt/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="pt/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Imprimir, faxes e envios</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/labels_database.html?DbPAR=SHARED">Imprimir etiquetas de endereços</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Imprimir a preto e branco</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/fax.html?DbPAR=SHARED">Enviar faxes e configurar o LibreOffice para enviar faxes</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Arrastar e largar</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop.html?DbPAR=SHARED">Arrastar e largar dentro de um documento do LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Mover e copiar texto em documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de folha de cálculo para documentos de texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar imagens entre documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserir objetos da galeria</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Arrastar e largar com a vista de origem de dados</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copiar e colar</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copiar objetos de desenho para outros documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar imagens entre documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserir objetos da galeria</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de folha de cálculo para documentos de texto</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Gráficos e diagramas</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserir gráficos</a></li>\
    <li><a target="_top" href="pt/text/schart/main0000.html?DbPAR=SHARED">Gráficos no LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Carregar, guardar, importar, exportar, PDF</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/doc_open.html?DbPAR=SHARED">Abrir documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/import_ms.html?DbPAR=SHARED">Abrir documentos guardados noutros formatos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/doc_save.html?DbPAR=SHARED">Guardar documentos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Guardar documentos automaticamente</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Utilizar ficheiros remotos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/export_ms.html?DbPAR=SHARED">Guardar documentos noutros formatos</a></li>\
    <li><a target="_top" href="pt/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportar como PDF</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importar e exportar dados em formato de texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Ligações e referências</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserir hiperligações</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Ligações relativas e absolutas</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Editar hiperligações</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Registo da versão do documento</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparar versões de um documento</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Unir versões</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Registar alterações</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining.html?DbPAR=SHARED">Gravar e mostrar alterações</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Aceitar ou rejeitar alterações</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Gestão de versões</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiquetas e cartões de visita</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/labels.html?DbPAR=SHARED">Criar e imprimir etiquetas e cartões de visitas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserir dados externos</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserir dados de folhas de cálculo</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserir dados de documentos de texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserir, editar e guardar mapas de bits</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Adicionar imagens à Galeria</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funções automáticas</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Desativar reconhecimento automático de URL</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Localizar e substituir</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/data_search2.html?DbPAR=SHARED">Procurar com um filtro de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_search.html?DbPAR=SHARED">Procurar tabelas e documentos de formulário</a></li>\
    <li><a target="_top" href="pt/text/shared/01/02100001.html?DbPAR=SHARED">Lista de expressões regulares</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guias</label><ul>\
    <li><a target="_top" href="pt/text/shared/guide/linestyles.html?DbPAR=SHARED">Aplicar estilos de linha</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/text_color.html?DbPAR=SHARED">Alterar a cor do texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/change_title.html?DbPAR=SHARED">Alterar o título de um documento</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/round_corner.html?DbPAR=SHARED">Criar cantos arredondados</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/background.html?DbPAR=SHARED">Definir cores ou imagens de fundo</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definir estilos de linha</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editar objetos gráficos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/line_intext.html?DbPAR=SHARED">Desenhar linhas no texto</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/aaa_start.html?DbPAR=SHARED">Primeiros passos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserir objetos da galeria</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserir espaços incondicionais, hífenes e hífenes opcionais</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserir caracteres especiais</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/tabs.html?DbPAR=SHARED">Inserir e editar marcas de tabulação</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/protection.html?DbPAR=SHARED">Proteger conteúdo no LibreOffice</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Proteger registos</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selecionar a área máxima de impressão numa página</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selecionar unidades de medida</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/language_select.html?DbPAR=SHARED">Selecionar o idioma do documento</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Design de tabela</a></li>\
    <li><a target="_top" href="pt/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Desativar marcas e numeração para parágrafos individuais</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
