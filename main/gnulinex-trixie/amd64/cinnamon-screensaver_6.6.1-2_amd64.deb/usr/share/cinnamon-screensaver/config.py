# Generated file - DO NOT EDIT.  Edit config.py.in instead.

prefix="/usr"
datadir="/usr/share"
localedir=datadir+"/locale"
pkgdatadir="/usr/share/cinnamon-screensaver"
libdir="/usr/lib/x86_64-linux-gnu"
pkglibdir="/usr/libexec/cinnamon-screensaver"
PACKAGE="cinnamon-screensaver"
VERSION="6.6.1"
GETTEXT_PACKAGE="cinnamon-screensaver"
