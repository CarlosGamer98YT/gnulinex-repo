document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/main0000.html?DbPAR=WRITER">Welcome to the LibreOffice Writer Help</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writer Features</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/main.html?DbPAR=WRITER">Instructions for Using LibreOffice Writer</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Docking and Resizing Windows</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/04/01020000.html?DbPAR=WRITER">Shortcut Keys for LibreOffice Writer</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/words_count.html?DbPAR=WRITER">Counting Words</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/keyboard.html?DbPAR=WRITER">Using Shortcut Keys (LibreOffice Writer Accessibility)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menus</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/main0100.html?DbPAR=WRITER">Menus</a></li>\
    <li><a target="_top" href="en-GB/text/shared/menu/PickList.html?DbPAR=WRITER">File Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_edit.html?DbPAR=WRITER">Edit</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0103.html?DbPAR=WRITER">View</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0104.html?DbPAR=WRITER">Insert</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_format.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="en-GB/text/shared/menu/style_menu.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0110.html?DbPAR=WRITER">Table</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_tools.html?DbPAR=WRITER">Main Tools Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0107.html?DbPAR=WRITER">Window</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0108.html?DbPAR=WRITER">Help</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Toolbars</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/main0200.html?DbPAR=WRITER">Toolbars</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0206.html?DbPAR=WRITER">Bullets and Numbering Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/classificationbar.html?DbPAR=WRITER">Classification Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0210.html?DbPAR=WRITER">Drawing Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0205.html?DbPAR=WRITER">Drawing Object Properties Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/fontwork_toolbar.html?DbPAR=WRITER">Fontwork</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/01170000.html?DbPAR=WRITER">Form Controls</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0226.html?DbPAR=WRITER">Form Design Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0213.html?DbPAR=WRITER">Form Navigation Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0202.html?DbPAR=WRITER">Formatting Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0214.html?DbPAR=WRITER">Formula Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0215.html?DbPAR=WRITER">Frame Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/02/18010000.html?DbPAR=WRITER">Insert</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/mailmergetoolbar.html?DbPAR=WRITER">Mail Merge Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0214.html?DbPAR=WRITER">Query Design Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0213.html?DbPAR=WRITER">Rulers</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0201.html?DbPAR=WRITER">Standard Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0204.html?DbPAR=WRITER">Table Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0212.html?DbPAR=WRITER">Table Data Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/main0220.html?DbPAR=WRITER">Text Object Bar</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigating Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigating and Selecting With the Keyboard</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Moving and Copying Text in Documents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Rearranging a Document by Using the Navigator</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserting Hyperlinks With the Navigator</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigator for Text Documents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Using the Direct Cursor</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatting Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Changing Page Orientation (Landscape or Portrait)</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_capital.html?DbPAR=WRITER">Changing the Case of Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Hiding Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Defining Different Headers and Footers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserting a Chapter Name and Number in a Header or a Footer</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Applying Text Formatting While You Type</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/reset_format.html?DbPAR=WRITER">Resetting Font Attributes</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Applying Styles in Fill Format Mode</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/wrap.html?DbPAR=WRITER">Wrapping Text Around Objects</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Using a Frame to Centre Text on a Page</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Emphasising Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rotating Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserting and Deleting Page Breaks</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creating and Applying Page Styles</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/subscript.html?DbPAR=WRITER">Making Text Superscript or Subscript</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Templates and Styles</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Templates and Styles</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternating Page Styles on Odd and Even Pages</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/change_header.html?DbPAR=WRITER">Creating a Page Style Based on the Current Page</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/load_styles.html?DbPAR=WRITER">Using Styles From Another Document or Template</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Creating New Styles From Selections</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Updating Styles From Selections</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/spotlight_styles.html?DbPAR=WRITER">Spotlight Styles</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Graphics in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserting Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserting a Graphic From a File</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/gallery_insert.html?DbPAR=WRITER">Inserting Objects From the Gallery</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserting a Scanned Image</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserting a Calc Chart into a Text Document</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserting Graphics From LibreOffice Draw or Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tables in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Turning Number Recognition On or Off in Tables</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modifying Rows and Columns by Keyboard</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/table_delete.html?DbPAR=WRITER">Deleting Tables or the Contents of a Table</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserting Tables</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Repeating a Table Header on a New Page</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Resizing Rows and Columns in a Text Table</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objects in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Positioning Objects</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/wrap.html?DbPAR=WRITER">Wrapping Text Around Objects</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections and Frames in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/sections.html?DbPAR=WRITER">Using Sections</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing and Linking Frames</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/section_edit.html?DbPAR=WRITER">Editing Sections</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserting Sections</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables of Contents and Indexes</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">User-Defined Indexes</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Creating a Table of Contents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_index.html?DbPAR=WRITER">Creating Alphabetical Indexes</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Indexes Covering Several Documents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Creating a Bibliography</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Editing or Deleting Index and Table Entries</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Updating, Editing and Deleting Indexes and Tables of Contents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Defining Index or Table of Contents Entries</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatting an Index or a Table of Contents</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fields in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/fields.html?DbPAR=WRITER">About Fields</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserting a Fixed or Variable Date Field</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/field_convert.html?DbPAR=WRITER">Converting a Field into Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/contentcontrols.html?DbPAR=WRITER">Using Content Controls in LibreOffice Writer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Calculating in Text Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Calculating Across Tables</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate.html?DbPAR=WRITER">Calculating in Text Documents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calculating and Pasting the Result of a Formula in a Text Document</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calculating Cell Totals in Tables</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calculating Complex Formulae in Text Documents</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Displaying the Result of a Table Calculation in a Different Table</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Special Text Elements</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/captions.html?DbPAR=WRITER">Using Captions</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Conditional Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Conditional Text for Page Counts</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserting a Fixed or Variable Date Field</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Adding Input Fields</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserting Page Numbers of Continuation Pages</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserting Page Numbers in Footers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Hiding Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Defining Different Headers and Footers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserting a Chapter Name and Number in a Header or a Footer</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Querying User Data in Fields or Conditions</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserting and Editing Footnotes or Endnotes</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Spacing Between Footnotes</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_footer.html?DbPAR=WRITER">About Headers and Footers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatting Headers or Footers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animating Text</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Creating a Form Letter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatic Functions</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Adding Exceptions to the AutoCorrect List</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/autotext.html?DbPAR=WRITER">Using AutoText</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creating Numbered or Bulleted Lists as You Type</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/auto_off.html?DbPAR=WRITER">Turning Off AutoCorrect</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatically Check Spelling</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Turning Number Recognition On or Off in Tables</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Using Hyphenation</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numbering and Lists</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Adding Heading Numbers to Captions</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creating Numbered or Bulleted Lists as You Type</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combining Numbered Lists</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Adding Line Numbers</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Defining Number Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Adding Numbering</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Adding Bullets</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Spell Checking, Thesaurus and Languages</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatically Check Spelling</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Removing Words From a User-Defined Dictionary</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Thesaurus</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Checking Spelling Manually</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Troubleshooting Tips</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insert Text Before a Table at the Top of Page</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Going to Specific Bookmark</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/send2html.html?DbPAR=WRITER">Saving Text Documents in HTML Format</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/markdown.html?DbPAR=WRITER">Markdown</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserting an Entire Text Document</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Master Documents</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Master Documents and Sub-documents</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links and References</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/references.html?DbPAR=WRITER">Inserting Cross-References</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserting Hyperlinks With the Navigator</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Printing</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Selecting printer paper trays</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/print_preview.html?DbPAR=WRITER">Previewing a Page Before Printing</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/print_small.html?DbPAR=WRITER">Printing Multiple Pages on One Sheet</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creating and Applying Page Styles</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Searching and Replacing</label><ul>\
    <li><a target="_top" href="en-GB/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/02100001.html?DbPAR=WRITER">List of Regular Expressions</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/07/09000000.html?DbPAR=WRITER">Web Pages</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/01170700.html?DbPAR=WRITER">HTML Filters and Forms</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/send2html.html?DbPAR=WRITER">Saving Text Documents in HTML Format</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/main0000.html?DbPAR=CALC">Welcome to the LibreOffice Calc Help</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc Features</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/keyboard.html?DbPAR=CALC">Shortcut Keys (LibreOffice Calc Accessibility)</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/04/01020000.html?DbPAR=CALC">Shortcut Keys for Spreadsheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/05/02140000.html?DbPAR=CALC">Error Codes in LibreOffice Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060112.html?DbPAR=CALC">Add-in for Programming in LibreOffice Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/main.html?DbPAR=CALC">Instructions for Using LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menus</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/main0100.html?DbPAR=CALC">Menus</a></li>\
    <li><a target="_top" href="en-GB/text/shared/menu/PickList.html?DbPAR=CALC">File Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_edit.html?DbPAR=CALC">Edit</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0103.html?DbPAR=CALC">View</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0104.html?DbPAR=CALC">Insert</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_format.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0112.html?DbPAR=CALC">Data</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_tools.html?DbPAR=CALC">Main Tools Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0107.html?DbPAR=CALC">Window</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0108.html?DbPAR=CALC">Help</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Toolbars</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/main0200.html?DbPAR=CALC">Toolbars</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0202.html?DbPAR=CALC">Formatting Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0203.html?DbPAR=CALC">Drawing Object Properties Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0205.html?DbPAR=CALC">Text Formatting Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0206.html?DbPAR=CALC">Formula Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0208.html?DbPAR=CALC">Status Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0210.html?DbPAR=CALC">Print Preview Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/main0218.html?DbPAR=CALC">Tools Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0201.html?DbPAR=CALC">Standard Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0212.html?DbPAR=CALC">Table Data Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0213.html?DbPAR=CALC">Form Navigation Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0214.html?DbPAR=CALC">Query Design Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0226.html?DbPAR=CALC">Form Design Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Functions Types and Operators</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060000.html?DbPAR=CALC">Function Wizard</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060100.html?DbPAR=CALC">Functions by Category</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060107.html?DbPAR=CALC">Array Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060101.html?DbPAR=CALC">Database Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060102.html?DbPAR=CALC">Date & Time Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060103.html?DbPAR=CALC">Financial Functions Part One</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060119.html?DbPAR=CALC">Financial Functions Part Two</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060118.html?DbPAR=CALC">Financial Functions Part Three</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060104.html?DbPAR=CALC">Information Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060105.html?DbPAR=CALC">Logical Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060106.html?DbPAR=CALC">Mathematical Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060108.html?DbPAR=CALC">Statistics Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060181.html?DbPAR=CALC">Statistical Functions Part One</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060182.html?DbPAR=CALC">Statistical Functions Part Two</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060183.html?DbPAR=CALC">Statistical Functions Part Three</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060184.html?DbPAR=CALC">Statistical Functions Part Four</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060185.html?DbPAR=CALC">Statistical Functions Part Five</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060109.html?DbPAR=CALC">Spreadsheet Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060110.html?DbPAR=CALC">Text Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060111.html?DbPAR=CALC">Add-in Functions</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060115.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part One</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060116.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part Two</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/04060199.html?DbPAR=CALC">Operators in LibreOffice Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/userdefined_function.html?DbPAR=CALC">User-Defined Functions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/webquery.html?DbPAR=CALC">Inserting External Data in Table (WebQuery)</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/html_doc.html?DbPAR=CALC">Saving and Opening Sheets in HTML</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importing and Exporting Text Files</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatting</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotating Text</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/text_wrap.html?DbPAR=CALC">Writing Multi-line Text</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatting Numbers as Text</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/super_subscript.html?DbPAR=CALC">Text Superscript / Subscript</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/row_height.html?DbPAR=CALC">Changing Row Height or Column Width</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Applying Conditional Formatting</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Highlighting Negative Numbers</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Assigning Formats by Formula</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Entering a Number with Leading Zeros</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/format_table.html?DbPAR=CALC">Formatting Spreadsheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/format_value.html?DbPAR=CALC">Formatting Numbers With Decimals</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/value_with_name.html?DbPAR=CALC">Naming Cells</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotating Tables (Transposing)</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/rename_table.html?DbPAR=CALC">Renaming Sheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx Years</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Using Rounded Off Numbers</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/currency_format.html?DbPAR=CALC">Cells in Currency Format</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/autoformat.html?DbPAR=CALC">Using AutoFormat for Tables</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserting and Editing Comments</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/design.html?DbPAR=CALC">Selecting Themes for Sheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Entering Fractions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtering and Sorting</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/filters.html?DbPAR=CALC">Applying Filters</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/autofilter.html?DbPAR=CALC">Applying AutoFilter</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/sorted_list.html?DbPAR=CALC">Applying Sort Lists</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Printing</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/print_title_row.html?DbPAR=CALC">Printing Rows or Columns on Every Page</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/print_landscape.html?DbPAR=CALC">Printing Sheets in Landscape Format</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/print_details.html?DbPAR=CALC">Printing Sheet Details</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/print_exact.html?DbPAR=CALC">Defining Number of Pages for Printing</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Data Ranges</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/database_define.html?DbPAR=CALC">Defining Database Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtering Cell Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/database_sort.html?DbPAR=CALC">Sorting Data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Table</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot.html?DbPAR=CALC">Pivot Table</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Creating Pivot Tables</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Deleting Pivot Tables</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Editing Pivot Tables</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtering Pivot Tables</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selecting Pivot Table Output Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Updating Pivot Tables</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08095"><label for="08095">Data Analysis</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_sampling.html?DbPAR=CALC">Data Sampling in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_descriptive.html?DbPAR=CALC">Descriptive Statistics in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_anova.html?DbPAR=CALC">ANOVA</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_correlation.html?DbPAR=CALC">Data Correlation in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_covariance.html?DbPAR=CALC">Data Covariance in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_exposmooth.html?DbPAR=CALC">Exponential Smoothing in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_movingavg.html?DbPAR=CALC">Moving Average in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_regression.html?DbPAR=CALC">Regression Analysis</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_test_t.html?DbPAR=CALC">Paired t-test in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_test_f.html?DbPAR=CALC">F Test Statistics in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_test_z.html?DbPAR=CALC">Z Test Statistics in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_test_chisqr.html?DbPAR=CALC">Chi Square Statistics in Calc</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/statistics_fourier.html?DbPAR=CALC">Fourier Analysis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenarios</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/scenario.html?DbPAR=CALC">Using Scenarios</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">References</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Addresses and References, Absolute and Relative</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/r1c1syntax.html?DbPAR=CALC">R1C1 Syntax</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referencing a Cell in Another Sheet</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referencing URLs in other Sheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referencing Cells by Drag-and-Drop</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/address_auto.html?DbPAR=CALC">Recognising Names as Addressing</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Viewing, Selecting, Copying</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/table_view.html?DbPAR=CALC">Changing Table Views</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/formula_value.html?DbPAR=CALC">Displaying Formulae or Values</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/line_fix.html?DbPAR=CALC">Freezing Rows or Columns as Headers</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigating Through Sheet Tabs</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copying to Multiple Sheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cellcopy.html?DbPAR=CALC">Only Copy Visible Cells</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selecting Multiple Cells</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/move_dragdrop.html?DbPAR=CALC">Moving Cells by Drag-and-Drop</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulae and Calculations</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/formulas.html?DbPAR=CALC">Calculating With Formulae</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copying Formulae</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/formula_enter.html?DbPAR=CALC">Entering Formulae</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/formula_value.html?DbPAR=CALC">Displaying Formulae or Values</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/calculate.html?DbPAR=CALC">Calculating in Spreadsheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/calc_date.html?DbPAR=CALC">Calculating With Dates and Times</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/calc_series.html?DbPAR=CALC">Automatically Calculating Series</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Calculating Time Differences</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/matrixformula.html?DbPAR=CALC">Entering Matrix Formulae</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulae</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Protection</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cell_protect.html?DbPAR=CALC">Protecting Cells from Changes</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Unprotecting Cells</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Writing Calc Macros</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Miscellaneous</label><ul>\
    <li><a target="_top" href="en-GB/text/scalc/guide/auto_off.html?DbPAR=CALC">Deactivating Automatic Changes</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidating Data</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/goalseek.html?DbPAR=CALC">Applying Goal Seek</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/01/solver.html?DbPAR=CALC">Solver</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/multioperation.html?DbPAR=CALC">Applying Multiple Operations</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/multitables.html?DbPAR=CALC">Applying Multiple Sheets</a></li>\
    <li><a target="_top" href="en-GB/text/scalc/guide/validity.html?DbPAR=CALC">Validity of Cell Content</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/main0000.html?DbPAR=IMPRESS">Welcome to the LibreOffice Impress Help</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress Features</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Using Shortcut Keys in LibreOffice Impress</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/04/01020000.html?DbPAR=IMPRESS">Shortcut Keys for LibreOffice Impress</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/main.html?DbPAR=IMPRESS">Instructions for Using LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menus</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/main0100.html?DbPAR=IMPRESS">Menus</a></li>\
    <li><a target="_top" href="en-GB/text/shared/menu/PickList.html?DbPAR=IMPRESS">File Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0103.html?DbPAR=IMPRESS">View</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0104.html?DbPAR=IMPRESS">Insert</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0114.html?DbPAR=IMPRESS">Slide Show</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_tools.html?DbPAR=IMPRESS">Main Tools Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0107.html?DbPAR=IMPRESS">Window</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0108.html?DbPAR=IMPRESS">Help</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Toolbars</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/main0200.html?DbPAR=IMPRESS">Toolbars</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0210.html?DbPAR=IMPRESS">Drawing Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0227.html?DbPAR=IMPRESS">Edit Points Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0226.html?DbPAR=IMPRESS">Form Design Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0213.html?DbPAR=IMPRESS">Form Navigation Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0202.html?DbPAR=IMPRESS">Line and Filling Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0213.html?DbPAR=IMPRESS">Options Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0211.html?DbPAR=IMPRESS">Outline Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0209.html?DbPAR=IMPRESS">Rulers</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0212.html?DbPAR=IMPRESS">Slide Sorter Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0204.html?DbPAR=IMPRESS">Slide View Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0201.html?DbPAR=IMPRESS">Standard Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0206.html?DbPAR=IMPRESS">Status Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0204.html?DbPAR=IMPRESS">Table Bar</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/main0203.html?DbPAR=IMPRESS">Text Formatting Bar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importing HTML Pages Into Presentations</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Colour, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exporting Animations in GIF Format</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserting Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatting</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Colour, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Loading Line and Arrow Styles</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Defining Custom Colours</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Creating Gradient Fills</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Replacing Colours</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Arranging, Aligning and Distributing Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/background.html?DbPAR=IMPRESS">Changing the Slide Background Fill</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/footer.html?DbPAR=IMPRESS">Adding a Header or a Footer to All Slides</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Moving Objects</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Printing</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/printing.html?DbPAR=IMPRESS">Printing Presentations</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Printing a Slide to Fit a Paper Size</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effects</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exporting Animations in GIF Format</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animating Objects in Presentation Slides</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animating Slide Transitions</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Cross-Fading Two Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Creating Animated GIF Images</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objects, Graphics and Bitmaps</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combining Objects and Constructing Shapes</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Grouping Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Drawing Sectors and Segments</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicating Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rotating Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Assembling 3-D Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Connecting Lines</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converting Text Characters into Drawing Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Converting Bitmap Images into Vector Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Converting 2-D Objects to Curves, Polygons, and 3-D Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Loading Line and Arrow Styles</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Drawing Curves</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Editing Curves</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserting Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Moving Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Selecting Underlying Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Creating a Flowchart</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Adding Text</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converting Text Characters into Drawing Objects</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Viewing</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Changing the Slide Order</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zooming With the Keypad</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/show.html?DbPAR=IMPRESS">Showing a Slide Show</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/individual.html?DbPAR=IMPRESS">Creating a Custom Slide Show</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Rehearse Timings of Slide Changes</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/main0000.html?DbPAR=DRAW">Welcome to the LibreOffice Draw Help</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw Features</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Shortcut Keys for Drawing Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/04/01020000.html?DbPAR=DRAW">Shortcut Keys for Drawings</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/main.html?DbPAR=DRAW">Instructions for Using LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/main0100.html?DbPAR=DRAW">Menus</a></li>\
    <li><a target="_top" href="en-GB/text/shared/menu/PickList.html?DbPAR=DRAW">File Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0103.html?DbPAR=DRAW">View</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main_tools.html?DbPAR=DRAW">Main Tools Menu</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0107.html?DbPAR=DRAW">Window</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0108.html?DbPAR=DRAW">Help</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/main0200.html?DbPAR=DRAW">Toolbars</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3-D Settings</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main0210.html?DbPAR=DRAW">Drawing Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0227.html?DbPAR=DRAW">Edit Points Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/02/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0226.html?DbPAR=DRAW">Form Design Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0213.html?DbPAR=DRAW">Form Navigation Bar</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/main0213.html?DbPAR=DRAW">Options Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0201.html?DbPAR=DRAW">Standard Bar</a></li>\
    <li><a target="_top" href="en-GB/text/shared/main0204.html?DbPAR=DRAW">Table Bar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing and Exporting</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Colour, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserting Graphics</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Colour, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Loading Line and Arrow Styles</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/color_define.html?DbPAR=DRAW">Defining Custom Colours</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/gradient.html?DbPAR=DRAW">Creating Gradient Fills</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Replacing Colours</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Arranging, Aligning and Distributing Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/background.html?DbPAR=DRAW">Changing the Slide Background Fill</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/move_object.html?DbPAR=DRAW">Moving Objects</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/printing.html?DbPAR=DRAW">Printing Presentations</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Printing a Slide to Fit a Paper Size</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Cross-Fading Two Objects</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/05350000.html?DbPAR=DRAW">3-D Effects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics and Bitmaps</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combining Objects and Constructing Shapes</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Drawing Sectors and Segments</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicating Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rotating Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Assembling 3-D Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Connecting Lines</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converting Text Characters into Drawing Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/vectorize.html?DbPAR=DRAW">Converting Bitmap Images into Vector Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/3d_create.html?DbPAR=DRAW">Converting 2-D Objects to Curves, Polygons, and 3-D Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Loading Line and Arrow Styles</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_draw.html?DbPAR=DRAW">Drawing Curves</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/line_edit.html?DbPAR=DRAW">Editing Curves</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserting Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/table_insert.html?DbPAR=DRAW">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/move_object.html?DbPAR=DRAW">Moving Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/select_object.html?DbPAR=DRAW">Selecting Underlying Objects</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/orgchart.html?DbPAR=DRAW">Creating a Flowchart</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/groups.html?DbPAR=DRAW">Grouping Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/01/insert_layer.html?DbPAR=DRAW">Insert Layer</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="en-GB/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Adding Text</a></li>\
    <li><a target="_top" href="en-GB/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converting Text Characters into Drawing Objects</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="en-GB/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zooming With the Keypad</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="en-GB/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/database_main.html?DbPAR=BASE">Database Overview</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_new.html?DbPAR=BASE">Creating a New Database</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_tables.html?DbPAR=BASE">Working with Tables</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_queries.html?DbPAR=BASE">Working with Queries</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_forms.html?DbPAR=BASE">Working with Forms</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_reports.html?DbPAR=BASE">Creating Reports</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_register.html?DbPAR=BASE">Registering and Deleting a Database</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_im_export.html?DbPAR=BASE">Importing and Exporting Data in Base</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Executing SQL Commands</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulae (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/smath/main0000.html?DbPAR=MATH">Welcome to the LibreOffice Math Help</a></li>\
    <li><a target="_top" href="en-GB/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math Features</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="en-GB/text/smath/01/03090100.html?DbPAR=MATH">Unary/Binary Operators</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090200.html?DbPAR=MATH">Relations</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090800.html?DbPAR=MATH">Set Operations</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090400.html?DbPAR=MATH">Functions</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090300.html?DbPAR=MATH">Operators</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090600.html?DbPAR=MATH">Attributes</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090500.html?DbPAR=MATH">Brackets</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="en-GB/text/smath/01/03091600.html?DbPAR=MATH">Other Symbols</a></li>\
      </ul></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/main.html?DbPAR=MATH">Instructions for Using LibreOffice Math</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/keyboard.html?DbPAR=MATH">Shortcuts (LibreOffice Math Accessibility)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Command and Menu Reference</label><ul>\
    <li><a target="_top" href="en-GB/text/smath/main0100.html?DbPAR=MATH">Menus</a></li>\
    <li><a target="_top" href="en-GB/text/smath/main0200.html?DbPAR=MATH">Toolbars</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Working with Formulae</label><ul>\
    <li><a target="_top" href="en-GB/text/smath/guide/align.html?DbPAR=MATH">Manually Aligning Formula Parts</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/color.html?DbPAR=MATH">Applying Colour to Formula Parts</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/attributes.html?DbPAR=MATH">Changing Default Attributes</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/brackets.html?DbPAR=MATH">Merging Formula Parts in Brackets</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/comment.html?DbPAR=MATH">Entering Comments</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/newline.html?DbPAR=MATH">Entering Line Breaks</a></li>\
    <li><a target="_top" href="en-GB/text/smath/guide/parentheses.html?DbPAR=MATH">Inserting Brackets</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Charts and Diagrams</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">General Information</label><ul>\
    <li><a target="_top" href="en-GB/text/schart/main0000.html?DbPAR=CHART">Charts in LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/schart/main0503.html?DbPAR=CHART">LibreOffice Chart Features</a></li>\
    <li><a target="_top" href="en-GB/text/schart/04/01020000.html?DbPAR=CHART">Shortcuts for Charts</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic Help</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programming with LibreOffice Basic</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic Glossary</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01010210.html?DbPAR=BASIC">Basics</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntax</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE Overview</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01030200.html?DbPAR=BASIC">The Basic Editor</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01050100.html?DbPAR=BASIC">Watch Window</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/main0211.html?DbPAR=BASIC">Macro Toolbar</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020500.html?DbPAR=BASIC">Libraries, Modules and Dialogs</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variables</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logical Operators</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120000.html?DbPAR=BASIC">Strings</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030000.html?DbPAR=BASIC">Date and Time Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070000.html?DbPAR=BASIC">Mathematical Operators</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeric Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometric Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010000.html?DbPAR=BASIC">Screen I/O Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020000.html?DbPAR=BASIC">File I/O Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090000.html?DbPAR=BASIC">Controlling Program Execution</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050000.html?DbPAR=BASIC">Error-Handling Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130000.html?DbPAR=BASIC">Other Commands</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generating Random Numbers</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/vba_objects.html?DbPAR=BASIC">VBA Supported Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090400.html?DbPAR=BASIC">Further Statements</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/CreateUnoSvcWithArgs.html?DbPAR=BASIC">CreateUnoServiceWithArguments Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/doEvents.html?DbPAR=BASIC">DoEvents Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050000.html?DbPAR=BASIC">Error-Handling Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03170020.html?DbPAR=BASIC">FormatPercent Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeric Functions</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080400.html?DbPAR=BASIC">Square Root Calculation</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03120300.html?DbPAR=BASIC">Editing String Contents</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020100.html?DbPAR=BASIC">Using Variables</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge Library</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_toc.html?DbPAR=BASIC">List of all ScriptForge methods and properties</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><input type="checkbox" id="07010501"><label for="07010501">Example Scripts</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/read_write_values.html?DbPAR=BASIC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/calc_borders.html?DbPAR=BASIC">Formatting Borders in Calc with Macros</a></li>\
            </ul></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_contextmenu.html?DbPAR=BASIC">SFWidgets.ContextMenu service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_dataset.html?DbPAR=BASIC">SFDatabases.Dataset service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_datasheet.html?DbPAR=BASIC">SFDatabases.Datasheet service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_formdocument.html?DbPAR=BASIC">SFDocuments.FormDocument service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_toolbar.html?DbPAR=BASIC">SFWidgets.Toolbar service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_toolbarbutton.html?DbPAR=BASIC">SFWidgets.ToolbarButton service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/macro_recording.html?DbPAR=BASIC">Recording a Macro</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Changing the Properties of Controls in the Dialog Editor</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Creating Controls in the Dialog Editor</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programming Examples for Controls in the Dialog Editor</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Creating a Basic Dialog</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organising Libraries and Modules</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020100.html?DbPAR=BASIC">Using Variables</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01020200.html?DbPAR=BASIC">Using Objects</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01030300.html?DbPAR=BASIC">Debugging a Basic Program</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organisation</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/running_scripts.html?DbPAR=BASIC">Running Python Scripts</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070203"><label for="070203">Python Modules</label><ul>\
    <li><a target="_top" href="en-GB/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="en-GB/text/sbasic/python/python_screen.html?DbPAR=BASIC">Python : Screen Input/Output</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Script Development Tools</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Changing the Association of Microsoft Office Document Types</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Troubleshoot Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Common Help Topics</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">General Information</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/main0400.html?DbPAR=SHARED">Shortcut Keys</a></li>\
    <li><a target="_top" href="en-GB/text/shared/00/00000005.html?DbPAR=SHARED">General Glossary</a></li>\
    <li><a target="_top" href="en-GB/text/shared/00/00000002.html?DbPAR=SHARED">Glossary of Internet Terms</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/accessibility.html?DbPAR=SHARED">Accessibility in LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/keyboard.html?DbPAR=SHARED">Shortcuts (LibreOffice Accessibility)</a></li>\
    <li><a target="_top" href="en-GB/text/shared/04/01010000.html?DbPAR=SHARED">General Shortcut Keys in LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/version_number.html?DbPAR=SHARED">Versions and Build Numbers</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice and Microsoft Office</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/ms_user.html?DbPAR=SHARED">Using Microsoft Office and LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparing Microsoft Office and LibreOffice Terms</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">About Converting Microsoft Office Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Changing the Association of Microsoft Office Document Types</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Options</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01000000.html?DbPAR=SHARED">Options</a></li>\
    <li><input type="checkbox" id="100401"><label for="100401">LibreOffice</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010100.html?DbPAR=SHARED">User Data</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010600.html?DbPAR=SHARED">General</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010800.html?DbPAR=SHARED">View</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010900.html?DbPAR=SHARED">Print Options</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010300.html?DbPAR=SHARED">Paths</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010700.html?DbPAR=SHARED">Fonts</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01030300.html?DbPAR=SHARED">Security</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01013000.html?DbPAR=SHARED">Accessibility</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100402"><label for="100402">Load/Save</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010200.html?DbPAR=SHARED">General</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA Properties</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01030500.html?DbPAR=SHARED">HTML compatibility</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100403"><label for="100403">Languages and Locales</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01150000.html?DbPAR=SHARED">Language Setting Options</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01010400.html?DbPAR=SHARED">Writing Aids</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100404"><label for="100404">LibreOffice Writer</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01040000.html?DbPAR=SHARED">Text Document Options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100405"><label for="100405">LibreOffice Writer/Web</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML Document Options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100406"><label for="100406">LibreOffice Calc</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01060000.html?DbPAR=SHARED">Spreadsheet Options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100407"><label for="100407">LibreOffice Impress</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01070000.html?DbPAR=SHARED">Presentation Options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100408"><label for="100408">LibreOffice Draw</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01080000.html?DbPAR=SHARED">Drawing Options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100409"><label for="100409">LibreOffice Math</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01090000.html?DbPAR=SHARED">Formula</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100410"><label for="100410">LibreOffice Base</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01160000.html?DbPAR=SHARED">Data sources options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100412"><label for="100412">Charts</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01110000.html?DbPAR=SHARED">Chart options</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100413"><label for="100413">Internet</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet options</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wizards</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01000000.html?DbPAR=SHARED">Wizard</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Letter Wizard</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01010000.html?DbPAR=SHARED">Letter Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Fax Wizard</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01020000.html?DbPAR=SHARED">Fax Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Agenda Wizard</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01040000.html?DbPAR=SHARED">Agenda Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Document Converter Wizard</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01130000.html?DbPAR=SHARED">Document Converter</a></li>\
      </ul></li>\
    <li><a target="_top" href="en-GB/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro Converter Wizard</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuring LibreOffice</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configuring LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/packagemanager.html?DbPAR=SHARED">Extension Manager</a></li>\
    <li><a target="_top" href="en-GB/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Adding Buttons to Toolbars</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/workfolder.html?DbPAR=SHARED">Changing Your Working Directory</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registering an Address Book</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/formfields.html?DbPAR=SHARED">Inserting and Editing Buttons</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Working with the User Interface</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigation to Quickly Reach Objects</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator for Document Overview</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/autohide.html?DbPAR=SHARED">Showing, Docking and Hiding Windows</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/textmode_change.html?DbPAR=SHARED">Switching Between Insert Mode and Overwrite Mode</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Using Toolbars</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/digital_signatures.html?DbPAR=SHARED">About Digital Signatures</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Applying Digital Signatures</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printing, Faxing, Sending</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/labels_database.html?DbPAR=SHARED">Printing Address Labels</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Printing in Black and White</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/fax.html?DbPAR=SHARED">Sending Faxes and Configuring LibreOffice for Faxing</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Drag & Drop</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop.html?DbPAR=SHARED">Dragging-and-Dropping Within a LibreOffice Document</a></li>\
    <li><a target="_top" href="en-GB/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Moving and Copying Text in Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copying Spreadsheet Areas to Text Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copying Graphics Between Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserting Objects From the Gallery</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Drag-and-Drop With the Data Source View</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copy and Paste</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copying Drawing Objects Into Other Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copying Graphics Between Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserting Objects From the Gallery</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copying Spreadsheet Areas to Text Documents</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Charts and Diagrams</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserting Charts</a></li>\
    <li><a target="_top" href="en-GB/text/schart/main0000.html?DbPAR=SHARED">Charts in LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/doc_open.html?DbPAR=SHARED">Opening Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/import_ms.html?DbPAR=SHARED">Opening documents saved in other formats</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/doc_save.html?DbPAR=SHARED">Saving Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Saving Documents Automatically</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/export_ms.html?DbPAR=SHARED">Saving Documents in Other Formats</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Export as PDF</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importing and Exporting Data in Text Format</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links and References</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserting Hyperlinks</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relative and Absolute Links</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Editing Hyperlinks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Document Version Tracking</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparing Versions of a Document</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Merging Versions</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Recording Changes</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining.html?DbPAR=SHARED">Recording and Displaying Changes</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Accepting or Rejecting Changes</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Version Management</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Labels and Business Cards</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/labels.html?DbPAR=SHARED">Creating and Printing Labels and Business Cards</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserting External Data</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserting Data From Spreadsheets</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserting Data From Text Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserting, Editing, Saving Bitmaps</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Adding Graphics to the Gallery</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatic Functions</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Turning off Automatic URL Recognition</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Searching and Replacing</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_search2.html?DbPAR=SHARED">Searching With a Form Filter</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_search.html?DbPAR=SHARED">Searching Tables and Form Documents</a></li>\
    <li><a target="_top" href="en-GB/text/shared/01/02100001.html?DbPAR=SHARED">List of Regular Expressions</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="en-GB/text/shared/guide/linestyles.html?DbPAR=SHARED">Applying Line Styles</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/text_color.html?DbPAR=SHARED">Changing the Colour of Text</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/change_title.html?DbPAR=SHARED">Changing the Title of a Document</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/round_corner.html?DbPAR=SHARED">Creating Round Corners</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/background.html?DbPAR=SHARED">Defining Background Colours or Background Graphics</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Colour, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Defining Line Styles</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editing Graphic Objects</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/line_intext.html?DbPAR=SHARED">Drawing Lines in Text</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/aaa_start.html?DbPAR=SHARED">First Steps</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserting Objects From the Gallery</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserting Special Characters</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/tabs.html?DbPAR=SHARED">Inserting and Editing Tab Stops</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/protection.html?DbPAR=SHARED">Protecting Content in LibreOffice</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Protecting Records</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selecting the Maximum Printable Area on a Page</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selecting Measurement Units</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/language_select.html?DbPAR=SHARED">Selecting the Document Language</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Table Design</a></li>\
    <li><a target="_top" href="en-GB/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Turning off Bullets and Numbering for Individual Paragraphs</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
