[Return to Presets](./#tokyo-night)

# Tokyo Night Preset

This preset is inspired by [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Screenshot of Tokyo Night preset](/presets/img/tokyo-night.png)

### Prerequisites

- A [Nerd Font](https://www.nerdfonts.com/) installed and enabled in your terminal

### Configuration

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/tokyo-night.toml){download}

<<< @/public/presets/toml/tokyo-night.toml
