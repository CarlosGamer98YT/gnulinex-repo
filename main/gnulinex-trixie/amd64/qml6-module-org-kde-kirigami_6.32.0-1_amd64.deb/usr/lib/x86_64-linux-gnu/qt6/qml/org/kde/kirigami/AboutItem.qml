/*
 *  SPDX-FileCopyrightText: 2018 Aleix Pol Gonzalez <aleixpol@blue-systems.com>
 *  SPDX-FileCopyrightText: 2023 ivan tkachenko <me@ratijas.tk>
 *
 *  SPDX-License-Identifier: LGPL-2.0-or-later
 */
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import QtQuick.Window
import org.kde.kirigami.platform as Platform
import org.kde.kirigami.primitives as Primitives
import org.kde.kirigami.forms as KF
import org.kde.kirigami.controls as KC

//TODO: Kf6: move somewhere else which can depend from KAboutData?
/*!
  \qmltype AboutItem
  \inqmlmodule org.kde.kirigami
  \brief An about item that displays the about data.

  Allows to show the copyright notice of the application
  together with the contributors and some information of which platform it's
  running on.

  \since 5.87
 */
Item {
    id: aboutItem
    /*!
      \brief This property holds an object with the same shape as KAboutData.

      Example usage:
      \badcode
      aboutData: {
          "displayName" : "KirigamiApp",
          "productName" : "kirigami/app",
          "componentName" : "kirigamiapp",
          "shortDescription" : "A Kirigami example",
          "homepage" : "",
          "bugAddress" : "submit@bugs.kde.org",
          "version" : "5.14.80",
          "otherText" : "",
          "authors" : [
              {
                  "name" : "...",
                  "task" : "",
                  "emailAddress" : "somebody@kde.org",
                  "webAddress" : "",
                  "ocsUsername" : ""
              }
          ],
          "credits" : [],
          "translators" : [],
          "licenses" : [
              {
                  "name" : "GPL v2",
                  "text" : "long, boring, license text",
                  "spdx" : "GPL-2.0"
              }
          ],
          "copyrightStatement" : "© 2010-2018 Plasma Development Team",
          "desktopFileName" : "org.kde.kirigamiapp"
       }
       \endcode

      \sa KAboutData
     */
    property var aboutData

    /*!
      \brief This property holds a link to a "Get Involved" page.

      default: "https://community.kde.org/Get_Involved" when application id starts with "org.kde.", otherwise it is empty.
     */
    property url getInvolvedUrl: aboutData.desktopFileName.startsWith("org.kde.") ? "https://community.kde.org/Get_Involved" : ""

    /*!
      \brief This property holds a link to a "Donate" page.

      default: "https://kde.org/community/donations" when application id starts with "org.kde.", otherwise it is empty.
     */
    property url donateUrl: aboutData.desktopFileName.startsWith("org.kde.") ? "https://kde.org/community/donations" : ""

    /*!
      \brief This property defines whether to show "Libraries in use".

      Set it to false when the about data describes a plugin rather than the
      application itself.

      default: \c true
      \since 6.32
     */
    property bool showLibraries: true

    property bool _usePageStack: false

    /*!
       \qmlproperty bool wideMode
       Deprecated: this property has no effect
     */
    property bool wideMode: false

    default property alias _content: form.data

    // if aboutData is a native KAboutData object, avatarUrl should be a proper url instance,
    // otherwise if it was defined as a string in pure JavaScript it should work too.
    readonly property bool __hasAvatars: aboutItem.aboutData.authors.some(__hasAvatar)

    function __hasAvatar(person): bool {
        return typeof person.avatarUrl !== "undefined"
            && person.avatarUrl.toString().length > 0;
    }

    /*!
      \brief This property controls whether to load avatars by URL.

      If set to false, a fallback "user" icon will be displayed.

      default: false
     */
    property bool loadAvatars: false

    implicitHeight: form.implicitHeight
    implicitWidth: form.implicitWidth

    Component {
        id: personDelegate

        KF.FormEntry {
            id: delegate

            // type: KAboutPerson | { name?, task?, emailAddress?, webAddress?, avatarUrl? }
            required property var modelData

            property bool hasAvatar: aboutItem.__hasAvatar(modelData)


            leadingItems: KC.Avatar {
                implicitWidth: Platform.Units.iconSizes.medium
                implicitHeight: implicitWidth
                name: delegate.modelData.name
                source: {
                    if (delegate.hasAvatar && aboutItem.loadAvatars) {
                        // Appending to the params of the url does not work, thus the search is set
                        const url = new URL(delegate.modelData.avatarUrl);
                        const params = new URLSearchParams(url.search);
                        params.append("s", width);
                        url.search = params.toString();
                        return url;
                    } else {
                        return "";
                    }
                }
            }

            contentItem: QQC2.Label {
                readonly property bool withTask: typeof(delegate.modelData.task) !== "undefined" && delegate.modelData.task.length > 0
                // Without a subtitle nothing else fills the row, which would push the name away from the avatar
                Layout.fillWidth: true
                text: delegate.modelData.name
                wrapMode: Text.WordWrap
            }

            subtitle: delegate.modelData.task

            trailingItems: [
                QQC2.ToolButton {
                    visible: typeof(delegate.modelData.ocsUsername) !== "undefined" && delegate.modelData.ocsUsername.length > 0
                    icon.name: "get-hot-new-stuff-symbolic"
                    QQC2.ToolTip.delay: Platform.Units.toolTipDelay
                    QQC2.ToolTip.visible: hovered
                    QQC2.ToolTip.text: qsTr("Visit %1's KDE Store page").arg(delegate.modelData.name)
                    onClicked: Qt.openUrlExternally("https://store.kde.org/u/%1".arg(delegate.modelData.ocsUsername))
                },
                QQC2.ToolButton {
                    visible: typeof(delegate.modelData.webAddress) !== "undefined" && delegate.modelData.webAddress.length > 0
                    icon.name: "globe"
                    QQC2.ToolTip.delay: Platform.Units.toolTipDelay
                    QQC2.ToolTip.visible: hovered
                    QQC2.ToolTip.text: (typeof(delegate.modelData.webAddress) === "undefined" && delegate.modelData.webAddress.length > 0) ? "" : delegate.modelData.webAddress
                    onClicked: Qt.openUrlExternally(delegate.modelData.webAddress)
                },
                QQC2.ToolButton {
                    visible: typeof(delegate.modelData.emailAddress) !== "undefined" && delegate.modelData.emailAddress.length > 0
                    icon.name: "mail-sent"
                    QQC2.ToolTip.delay: Platform.Units.toolTipDelay
                    QQC2.ToolTip.visible: hovered
                    QQC2.ToolTip.text: qsTr("Send an email to %1").arg(delegate.modelData.emailAddress)
                    onClicked: Qt.openUrlExternally("mailto:%1".arg(delegate.modelData.emailAddress))
                }
            ]
        }
    }

    KF.Form {
        id: form

        anchors.fill: parent

        KF.FormGroup {
            KF.FormEntry {
                contentItem: ColumnLayout {
                    KC.Heading {
                        Layout.fillWidth: true
                        text: aboutItem.aboutData.displayName + " " + aboutItem.aboutData.version
                    }
                    KC.Heading {
                        Layout.fillWidth: true
                        level: 3
                        type: KC.Heading.Type.Secondary
                        wrapMode: Text.WordWrap
                        text: aboutItem.aboutData.shortDescription
                    }
                }
                leadingItems: Primitives.Icon {
                    Layout.preferredHeight: Platform.Units.iconSizes.huge
                    Layout.preferredWidth: height
                    Layout.maximumWidth: aboutItem.width / 3;
                    Layout.rightMargin: Platform.Units.largeSpacing
                    source: aboutItem.aboutData.programLogo || Platform.Settings.applicationWindowIcon || aboutItem.aboutData.componentName
                }
            }
            KF.FormSeparator {
                visible: copyrightEntry.subtitle.length > 0
            }
            KF.FormEntry {
                id: copyrightEntry
                contentItem: QQC2.Label {
                    text: qsTr("Copyright")
                }
                // FIXME
                subtitle: aboutItem.aboutData.copyrightStatement
                visible: subtitle.length > 0
            }
        }

        KF.FormGroup {
            title: qsTr("License")
            visible: repLicenses.count > 0
            Repeater {
                id: repLicenses
                model: aboutItem.aboutData.licenses
                delegate: KF.FormAction {
                    id: licenseLinkButton
                    required property var modelData
                    action: KC.Action {
                        text: licenseLinkButton.modelData.name
                        onTriggered: {
                            // License texts are hard-wrapped at ~76 columns. Join each line with the
                            // next one so paragraphs wrap to the sheet's width, but keep empty lines
                            // and lines starting with whitespace (headings, list items) on their own.
                            licenseSheet.text = licenseLinkButton.modelData.text.replace(/([^\r\n])\r?\n(?!\s)/g, "$1 ")
                            licenseSheet.title = licenseLinkButton.modelData.name
                            licenseSheet.open()
                        }
                    }
                }
            }
        }

        KF.FormGroup {
            id: linksGroup

            readonly property bool hasHomepage: aboutItem.aboutData.homepage.toString().length > 0
            readonly property bool hasDonate: aboutItem.donateUrl.toString().length > 0
            readonly property bool hasGetInvolved: aboutItem.getInvolvedUrl.toString().length > 0
            readonly property string bugUrl: {
                const bugAddress = aboutItem.aboutData.bugAddress ?? "";
                if (bugAddress !== "submit@bugs.kde.org") {
                    // A plain email address can only be opened with a mailto: scheme.
                    if (bugAddress.includes("@") && !bugAddress.includes(":")) {
                        return "mailto:" + bugAddress;
                    }
                    return bugAddress;
                }
                const elements = (aboutItem.aboutData.productName ?? "").split('/');
                let url = `https://bugs.kde.org/enter_bug.cgi?format=guided&product=${elements[0]}&version=${aboutItem.aboutData.version}`;
                if (elements.length === 2) {
                    url += "&component=" + elements[1];
                }
                return url;
            }
            readonly property bool hasBugUrl: bugUrl.length > 0

            visible: hasHomepage || hasDonate || hasGetInvolved || hasBugUrl

            KF.FormAction {
                action: KC.Action {
                    icon.name: "globe-symbolic"
                    text: qsTr("Homepage")
                    onTriggered: {
                        Qt.openUrlExternally(aboutItem.aboutData.homepage)
                    }
                }
                triggerIcon.name: "open-link-symbolic"
                visible: linksGroup.hasHomepage
            }
            KF.FormSeparator {
                visible: linksGroup.hasHomepage && (linksGroup.hasDonate || linksGroup.hasGetInvolved || linksGroup.hasBugUrl)
            }
            KF.FormAction {
                action: KC.Action {
                    icon.name: "donate-symbolic"
                    text: qsTr("Donate")
                    onTriggered: {
                        Qt.openUrlExternally(aboutItem.donateUrl + "?app=" + aboutItem.aboutData.componentName)
                    }
                }
                triggerIcon.name: "open-link-symbolic"
                visible: linksGroup.hasDonate
            }
            KF.FormSeparator {
                visible: linksGroup.hasDonate && (linksGroup.hasGetInvolved || linksGroup.hasBugUrl)
            }
            KF.FormAction {
                action: KC.Action {
                    icon.name: "applications-development-symbolic"
                    text: qsTr("Get Involved")
                    onTriggered: {
                        Qt.openUrlExternally(aboutItem.getInvolvedUrl)
                    }
                }
                triggerIcon.name: "open-link-symbolic"
                visible: linksGroup.hasGetInvolved
            }
            KF.FormSeparator {
                visible: linksGroup.hasGetInvolved && linksGroup.hasBugUrl
            }
            KF.FormAction {
                action: KC.Action {
                    icon.name: "tools-report-bug-symbolic"
                    text: qsTr("Report a bug")
                    onTriggered: {
                        Qt.openUrlExternally(linksGroup.bugUrl)
                    }
                }
                triggerIcon.name: "open-link-symbolic"
                visible: linksGroup.hasBugUrl
            }
        }

        KF.FormGroup {
            title: qsTr("Libraries in use")
            visible: aboutItem.showLibraries
            Repeater {
                model: aboutItem.showLibraries ? Platform.Settings.information : null
                delegate: KF.FormEntry {
                    id: delegate
                    required property string modelData
                    contentItem:  QQC2.Label {
                        wrapMode: Text.WordWrap
                        id: libraries
                        text: delegate.modelData
                    }
                }
            }
        }

        QQC2.CheckBox {
            id: remoteAvatars
            visible: aboutItem.__hasAvatars
            checked: aboutItem.loadAvatars
            onToggled: aboutItem.loadAvatars = checked
            text: qsTr("Show author photos")
        }
        KF.FormGroup {
            title: qsTr("Authors")
            visible: repAuthors.count > 0
            Repeater {
                id: repAuthors
                model: aboutItem.aboutData.authors
                delegate: personDelegate
            }
        }

        KF.FormGroup {
            title: qsTr("Credits")
            visible: repCredits.count > 0
            Repeater {
                id: repCredits
                model: aboutItem.aboutData.credits
                delegate: personDelegate
            }
        }

        KF.FormGroup {
            title: qsTr("Translators")
            visible: repTranslators.count > 0
            Repeater {
                id: repTranslators
                model: aboutItem.aboutData.translators
                delegate: personDelegate
            }
        }

        OverlaySheet {
            id: licenseSheet
            width: Math.min(aboutItem.width - Platform.Units.gridUnit * 2, Platform.Units.gridUnit * 30, bodyLabel.implicitWidth)
            height: parent.Window.window.height - Platform.Units.gridUnit * 8
            property alias text: bodyLabel.text

            SelectableLabel {
                id: bodyLabel
                text: licenseSheet.text
                wrapMode: Text.Wrap
            }
        }
    }
}
