#   __
#  /__)  _  _     _   _ _/   _
# / (   (- (/ (/ (- _)  /  _)
#          /

"""
Requests HTTP Library
~~~~~~~~~~~~~~~~~~~~~

Requests is an HTTP library, written in Python, for human beings.
Basic GET usage:

   >>> import requests
   >>> r = requests.get('https://www.python.org')
   >>> r.status_code
   200
   >>> b'Python is a programming language' in r.content
   True

... or POST:

   >>> payload = dict(key1='value1', key2='value2')
   >>> r = requests.post('https://httpbin.org/post', data=payload)
   >>> print(r.text)
   {
     ...
     "form": {
       "key1": "value1",
       "key2": "value2"
     },
     ...
   }

The other HTTP methods are supported - see `requests.api`. Full documentation
is at <https://requests.readthedocs.io>.

:copyright: (c) 2017 by Kenneth Reitz.
:license: Apache 2.0, see LICENSE for more details.
"""

from __future__ import annotations

import warnings

from pip._vendor import urllib3

from .exceptions import RequestsDependencyWarning

charset_normalizer_version = None
chardet_version = None


def check_compatibility(
    urllib3_version: str,
    chardet_version: str | None,
    charset_normalizer_version: str | None,
) -> None:
    urllib3_version_list = urllib3_version.split(".")[:3]
    assert urllib3_version_list != ["dev"]  # Verify urllib3 isn't installed from git.

    # Sometimes, urllib3 only reports its version as 16.1.
    if len(urllib3_version_list) == 2:
        urllib3_version_list.append("0")

    # Check urllib3 for compatibility.
    major, minor, patch = urllib3_version_list  # noqa: F811
    major, minor, patch = int(major), int(minor), int(patch)
    # urllib3 >= 1.21.1
    assert major >= 1
    if major == 1:
        assert minor >= 21

    # Check charset_normalizer for compatibility.
    if chardet_version:
        major, minor, patch = chardet_version.split(".")[:3]
        major, minor, patch = int(major), int(minor), int(patch)
        # chardet_version >= 3.0.2, < 8.0.0
        assert (3, 0, 2) <= (major, minor, patch) < (8, 0, 0)
    elif charset_normalizer_version:
        major, minor, patch = charset_normalizer_version.split(".")[:3]
        major, minor, patch = int(major), int(minor), int(patch)
        # charset_normalizer >= 2.0.0 < 4.0.0
        assert (2, 0, 0) <= (major, minor, patch) < (4, 0, 0)
    else:
        # pip does not need or use character detection
        pass


def _check_cryptography(cryptography_version: str) -> None:
    # cryptography < 1.3.4
    try:
        cryptography_version_list = list(map(int, cryptography_version.split(".")))
    except ValueError:
        return

    if cryptography_version_list < [1, 3, 4]:
        warning = f"Old version of cryptography ({cryptography_version_list}) may cause slowdown."
        warnings.warn(warning, RequestsDependencyWarning)


# Check imported dependencies for compatibility.
try:
    check_compatibility(
        urllib3.__version__,  # type: ignore[reportPrivateImportUsage]
        chardet_version,  # type: ignore[reportUnknownArgumentType]
        charset_normalizer_version,
    )
except (AssertionError, ValueError):
    warnings.warn(
        f"urllib3 ({urllib3.__version__}) or chardet "  # type: ignore[reportPrivateImportUsage]
        f"({chardet_version})/charset_normalizer ({charset_normalizer_version}) "
        "doesn't match a supported version!",
        RequestsDependencyWarning,
    )

# Attempt to enable urllib3's fallback for SNI support
# if the standard library doesn't support SNI or the
# 'ssl' library isn't available.
try:
    # Note: This logic prevents upgrading cryptography on Windows, if imported
    #       as part of pip.
    from pip._internal.utils.compat import WINDOWS
    if WINDOWS:
        raise ImportError("pip internals: don't import cryptography on Windows")
    try:
        import ssl
    except ImportError:
        ssl = None

    if not getattr(ssl, "HAS_SNI", False):
        from pip._vendor.urllib3.contrib import pyopenssl

        pyopenssl.inject_into_urllib3()

        # Check cryptography version
        from cryptography import (  # type: ignore[reportMissingImports]
            __version__ as cryptography_version,  # type: ignore[reportUnknownVariableType]
        )

        _check_cryptography(cryptography_version)  # type: ignore[reportUnknownArgumentType]
except ImportError:
    pass

# urllib3's DependencyWarnings should be silenced.
from pip._vendor.urllib3.exceptions import DependencyWarning

warnings.simplefilter("ignore", DependencyWarning)

# Set default logging handler to avoid "No handler found" warnings.
import logging
from logging import NullHandler

from . import packages, utils
from .__version__ import (
    __author__,
    __author_email__,
    __build__,
    __cake__,
    __copyright__,
    __description__,
    __license__,
    __title__,
    __url__,
    __version__,
)
from .api import delete, get, head, options, patch, post, put, request
from .exceptions import (
    ConnectionError,
    ConnectTimeout,
    FileModeWarning,
    HTTPError,
    JSONDecodeError,
    ReadTimeout,
    RequestException,
    Timeout,
    TooManyRedirects,
    URLRequired,
)
from .models import PreparedRequest, Request, Response
from .sessions import Session, session
from .status_codes import codes

__all__ = (
    "ConnectionError",
    "ConnectTimeout",
    "HTTPError",
    "JSONDecodeError",
    "PreparedRequest",
    "ReadTimeout",
    "Request",
    "RequestException",
    "Response",
    "Session",
    "Timeout",
    "TooManyRedirects",
    "URLRequired",
    "codes",
    "delete",
    "get",
    "head",
    "options",
    "packages",
    "patch",
    "post",
    "put",
    "request",
    "session",
    "utils",
)

logging.getLogger(__name__).addHandler(NullHandler())

# FileModeWarnings go off per the default.
warnings.simplefilter("default", FileModeWarning, append=True)
