document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Metin Belgeleri (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice Writer Yardımına Hoş Geldiniz</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writer Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice Writer için Kullanım Yönergeleri</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Pencereleri kilitlemek ve yeniden boyutlandırmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writer için Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/words_count.html?DbPAR=WRITER">Kelimeleri Saymak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/keyboard.html?DbPAR=WRITER">Kısayol Tuşlarını Kullanmak (LibreOffice Writer Erişilebilirlik)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Komut ve Menü Referansı</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menüler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/main0100.html?DbPAR=WRITER">Menüler</a></li>\
    <li><a target="_top" href="tr/text/shared/menu/PickList.html?DbPAR=WRITER">Dosya Menüsü</a></li>\
    <li><a target="_top" href="tr/text/shared/main_edit.html?DbPAR=WRITER">Edit</a></li>\
    <li><a target="_top" href="tr/text/shared/main0103.html?DbPAR=WRITER">Görünüm</a></li>\
    <li><a target="_top" href="tr/text/shared/main0104.html?DbPAR=WRITER">Ekle</a></li>\
    <li><a target="_top" href="tr/text/shared/main_format.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="tr/text/shared/menu/style_menu.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0110.html?DbPAR=WRITER">Tablo</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0120.html?DbPAR=WRITER">Form Menüsü</a></li>\
    <li><a target="_top" href="tr/text/shared/main_tools.html?DbPAR=WRITER">Main Tools Menu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0107.html?DbPAR=WRITER">Window</a></li>\
    <li><a target="_top" href="tr/text/shared/main0108.html?DbPAR=WRITER">Yardım</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Araç çubukları</label><ul>\
    <li><a target="_top" href="tr/text/swriter/main0200.html?DbPAR=WRITER">Araç çubukları</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0206.html?DbPAR=WRITER">Madde İşaretleme ve Numaralama Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/01/classificationbar.html?DbPAR=WRITER">Classification Bar</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0210.html?DbPAR=WRITER">Çizim Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0205.html?DbPAR=WRITER">Çizim Nesne Özellikleri Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/02/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="tr/text/shared/02/fontwork_toolbar.html?DbPAR=WRITER">Fontwork</a></li>\
    <li><a target="_top" href="tr/text/shared/02/01170000.html?DbPAR=WRITER">Denetimler</a></li>\
    <li><a target="_top" href="tr/text/shared/main0226.html?DbPAR=WRITER">Form Tasarım Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0213.html?DbPAR=WRITER">Form Gezinme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0202.html?DbPAR=WRITER">Biçimlendirme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0214.html?DbPAR=WRITER">Formül Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0215.html?DbPAR=WRITER">Çerçeve Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0203.html?DbPAR=WRITER">Resim Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/02/18010000.html?DbPAR=WRITER">Ekle</a></li>\
    <li><a target="_top" href="tr/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/mailmergetoolbar.html?DbPAR=WRITER">Posta Birleştirme Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="tr/text/shared/main0214.html?DbPAR=WRITER">Sorgu Tasarım Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0213.html?DbPAR=WRITER">Cetveller</a></li>\
    <li><a target="_top" href="tr/text/shared/main0201.html?DbPAR=WRITER">Standart Çubuk</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0204.html?DbPAR=WRITER">Tablo Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0212.html?DbPAR=WRITER">Tablo Veri Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/main0220.html?DbPAR=WRITER">Metin Nesne Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Metin Belgelerinde Gezinmek</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Klavye İle Gezinmek ve Seçmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Belgelerdeki Metni Kopyalamak ve Taşımak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Gezgini Kullanarak Bir Belgeyi Tekrar Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Gezgin ile Köprüler Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/navigator.html?DbPAR=WRITER">Metin Belgeleri için Gezgin</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Serbest İmleci Kullanmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Metin Belgelerini Biçimlendirmek</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Sayfa Yönlendirmesini Değiştirme (Yatay veya Dikey)</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_capital.html?DbPAR=WRITER">Metnin Büyük/küçük harf durumunu değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Metni Gizleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Farklı Üst Bilgiler ve Alt Bilgiler Tanımlamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Üst bilgi veya Alt bilgiye Bölüm Adı veya Numarası Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Yazarken Metin Biçimlendirmesini Uygulamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/reset_format.html?DbPAR=WRITER">Metin Özniteliklerini Sıfırlamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Biçim Doldurma Kipinde Biçemleri Uygulamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/wrap.html?DbPAR=WRITER">Nesnelerin Etrafında Metin Dağılımı</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Sayfadaki Metni Ortalamak için bir Çerçeve Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Metni Vurgulamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Metni Döndürme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/page_break.html?DbPAR=WRITER">Sayfa Sonu Eklemek ve Silmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Sayfa Biçemleri Oluşturma ve Uygulama</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/subscript.html?DbPAR=WRITER">Metni Üst Simge veya Alt Simge Yapma</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Şablonlar ve Biçemler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Şablonlar ve Biçemler</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Tek ve Çift Sayfalarda Sayfa Biçemini Değişik Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/change_header.html?DbPAR=WRITER">Mevcut Sayfaya Tabanlı Bir Sayfa Biçemi Oluşturma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/load_styles.html?DbPAR=WRITER">Başka Bir Belgeden veya Şablondan Biçemleri Kullanma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Seçimlerden Yeni Biçemler Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Seçimlerden Biçemleri Güncelleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/spotlight_styles.html?DbPAR=WRITER">Spotlight Styles</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/template_manager.html?DbPAR=WRITER">Şablon Yöneticisi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Metin Belgelerinde Grafikler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Grafikleri Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Dosyadan Grafik Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/gallery_insert.html?DbPAR=WRITER">Galeri&#39;den Nesne Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Taranmış Bir Resim Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Metin Belgesine Calc Çizelgesi Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">LibreOffice Draw veya Impress&#39;den Grafik Eklemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Metin Belgelerinde Tablolar</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Tablolarda Numara Algılamayı Açmak veya Kapatmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/tablemode.html?DbPAR=WRITER">Satırları ve Sütunları Klavyeden Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/table_delete.html?DbPAR=WRITER">Tabloları veya Tablo İçeriğini Silme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/table_insert.html?DbPAR=WRITER">Tablo Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Yeni bir sayfada Tablo Başlığını Tekrar Etmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Metin Tablosunun Satırlarını ve Sütunlarını Boyutlandırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Metin Belgelerinde Nesneler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Nesneleri Konumlandırma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/wrap.html?DbPAR=WRITER">Nesnelerin Etrafında Metin Dağılımı</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Metin Belgelerinde Bölümler ve Çerçeveler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/sections.html?DbPAR=WRITER">Bölümleri Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/section_edit.html?DbPAR=WRITER">Bölümleri Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/section_insert.html?DbPAR=WRITER">Bölüm Eklemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">İçindekiler ve Dizin Tabloları</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Kullanıcı-Tanımlı Dizinler</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_toc.html?DbPAR=WRITER">İçindekiler Dizini Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_index.html?DbPAR=WRITER">Alfabetik Dizinler Oluşturma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Birkaç Belgeyi İçeren Dizinler</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Kaynakça Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Dizin ve Tablo Girişlerini Düzenlemek veya Silmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Dizinleri ve Tablo İçeriklerini Güncelleme, Düzenleme ve Silme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Dizin veya İçindekiler Dizini Girdilerini tanımlamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/indices_form.html?DbPAR=WRITER">Bir Dizini veya İçerikler Tablosunu Biçimlendirmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Metin Belgelerinde Alanlar</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/fields.html?DbPAR=WRITER">Alanlar Hakkında</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/fields_date.html?DbPAR=WRITER">Sabit veya Değişken Tarih Alanı Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/field_convert.html?DbPAR=WRITER">Bir Alanı Metne Dönüştürmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/contentcontrols.html?DbPAR=WRITER">Using Content Controls in LibreOffice Writer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Metin Belgelerinde Hesaplama Yapmak</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Birden çok Tablo Arasında Hesaplamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate.html?DbPAR=WRITER">Metin Belgelerinde Hesaplama Yapmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Hesaplama yapmak ve Formülün Sonucunu Metin Belgesine Yapıştırmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Tablodaki Hücre Toplamlarını Hesaplamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Metin Belgelerinde Karmaşık Formülleri Hesaplamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Tablo Hesaplamasının Sonucunu Başka Bir Tabloda Göstermek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Özel Metin Öğeleri</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/captions.html?DbPAR=WRITER">Başlık Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Koşullu Metin</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Sayfa Sayısı için Koşullu Metin</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/fields_date.html?DbPAR=WRITER">Sabit veya Değişken Tarih Alanı Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Giriş Alanları Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Devam Sayfalarının Numaralarını Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Alt Bilgilerde Sayfa Numaraları Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Metni Gizleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Farklı Üst Bilgiler ve Alt Bilgiler Tanımlamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Üst bilgi veya Alt bilgiye Bölüm Adı veya Numarası Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Alanlardaki veya Koşullardaki Kullanıcı Verisini Sorgulamak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Dipnot veya Sonnot Eklemek veya Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Dipnotlar Arasında Boşluk Bırakma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_footer.html?DbPAR=WRITER">Üst Bilgi ve Alt Bilgi Hakkında</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Üst Bilgiyi veya Alt Bilgiyi Biçimlendirmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/text_animation.html?DbPAR=WRITER">Metni Canlandırma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Bir Mektup Biçemi Oluşturmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Otomatik İşlevler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Otomatik Düzeltme Listesine İstisna Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/autotext.html?DbPAR=WRITER">Otomatik Metin Kullanımı</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Siz Yazarken Numaralandırılmış veya Madde İmleri eklenmiş Listeler Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/auto_off.html?DbPAR=WRITER">Otomatik Düzeltmeyi Kapatma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Otomatik İmla Denetimi</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Tablolarda Numara Algılamayı Açmak veya Kapatmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Using Hyphenation</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numaralama ve Listeler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Adding Heading Numbers to Captions</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Siz Yazarken Numaralandırılmış veya Madde İmleri eklenmiş Listeler Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numbering for Headings</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Numaralanmış Listeleri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Satır Numaraları Eklemek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Numara Aralıklarını Tanımlama</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Numaralamayı Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Madde İmleri Eklemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">İmla Denetimi, Sözlükler ve Diller</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Otomatik İmla Denetimi</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Kullanıcı Tanımlı Sözlükten Sözcükler Çıkarma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Eşanlamlılar sözlüğü</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Yazım Denetimi ve Dil Bilgisini Kontrol Etme</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Sorun Çözme Önerileri</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insert Text Before a Table at the Top of Page</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Özel Yer İmine Gitmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Yükleme, Kaydetme, İçe Aktarma, Dışa Aktarma ve Düzenleme</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/send2html.html?DbPAR=WRITER">Metin Belgelerini HTML Biçeminde Kaydetme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/markdown.html?DbPAR=WRITER">Markdown</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Bütün Metin Belgesi Ekleme</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Ana Belgeler</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Ana Belgeler ve Alt Belgeler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Bağlantılar ve Başvurular</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/references.html?DbPAR=WRITER">Çapraz Başvuru Ekleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Gezgin ile Köprüler Eklemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Yazdırma</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Yazıcı Kağıt Tepsisini Seçmek</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/print_preview.html?DbPAR=WRITER">Yazdırmadan Önce Bir Sayfayı Önizleme</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/print_small.html?DbPAR=WRITER">Bir Çalışma Sayfasındaki Çoklu Sayfaları Yazdırma</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Sayfa Biçemleri Oluşturma ve Uygulama</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Bulmak ve Değiştirmek</label><ul>\
    <li><a target="_top" href="tr/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="tr/text/shared/01/02100001.html?DbPAR=WRITER">Düzenli İfadeler Listesi</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Belgeleri (Writer Web)</label><ul>\
    <li><a target="_top" href="tr/text/shared/07/09000000.html?DbPAR=WRITER">Web Sayfaları</a></li>\
    <li><a target="_top" href="tr/text/shared/02/01170700.html?DbPAR=WRITER">HTML Süzgeçleri ve Formları</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/send2html.html?DbPAR=WRITER">Metin Belgelerini HTML Biçeminde Kaydetme</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Çalışma Sayfaları (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/scalc/main0000.html?DbPAR=CALC">LibreOffice Calc Yardımına Hoş Geldiniz</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/keyboard.html?DbPAR=CALC">Kısayol tuşları (LibreOffice Calc&#39;de erişilebilirlik)</a></li>\
    <li><a target="_top" href="tr/text/scalc/04/01020000.html?DbPAR=CALC">Hesap Tabloları için Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="tr/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calc Hata Kodları</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice Calc&#39;de Eklenti Programlaması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice Calc için Kullanım Yönergeleri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Komut ve Menü Referansı</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menüler</label><ul>\
    <li><a target="_top" href="tr/text/scalc/main0100.html?DbPAR=CALC">Menüler</a></li>\
    <li><a target="_top" href="tr/text/shared/menu/PickList.html?DbPAR=CALC">Dosya Menüsü</a></li>\
    <li><a target="_top" href="tr/text/shared/main_edit.html?DbPAR=CALC">Edit</a></li>\
    <li><a target="_top" href="tr/text/shared/main0103.html?DbPAR=CALC">Görünüm</a></li>\
    <li><a target="_top" href="tr/text/shared/main0104.html?DbPAR=CALC">Ekle</a></li>\
    <li><a target="_top" href="tr/text/shared/main_format.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0116.html?DbPAR=CALC">Çalışma Sayfası</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0112.html?DbPAR=CALC">Veri</a></li>\
    <li><a target="_top" href="tr/text/shared/main_tools.html?DbPAR=CALC">Main Tools Menu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0107.html?DbPAR=CALC">Window</a></li>\
    <li><a target="_top" href="tr/text/shared/main0108.html?DbPAR=CALC">Yardım</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Araç çubukları</label><ul>\
    <li><a target="_top" href="tr/text/scalc/main0200.html?DbPAR=CALC">Araç çubukları</a></li>\
    <li><a target="_top" href="tr/text/shared/02/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0202.html?DbPAR=CALC">Hesap Tablosu Nesne Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0203.html?DbPAR=CALC">Çizim Nesnesi Özellik Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0205.html?DbPAR=CALC">Metin Biçimlendirme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0206.html?DbPAR=CALC">Formül Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0208.html?DbPAR=CALC">Durum Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0210.html?DbPAR=CALC">Yazdırma Önizleme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0214.html?DbPAR=CALC">Resim Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/scalc/main0218.html?DbPAR=CALC">Ana Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0201.html?DbPAR=CALC">Standart Çubuk</a></li>\
    <li><a target="_top" href="tr/text/shared/main0212.html?DbPAR=CALC">Tablo Veri Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0213.html?DbPAR=CALC">Form Gezinme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0214.html?DbPAR=CALC">Sorgu Tasarım Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0226.html?DbPAR=CALC">Form Tasarım Çubuğu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">İşlev Türleri ve İşleçler</label><ul>\
    <li><a target="_top" href="tr/text/scalc/01/04060000.html?DbPAR=CALC">İşlev Sihirbazı</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060100.html?DbPAR=CALC">İşlev Kategorileri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060107.html?DbPAR=CALC">Dizi İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060120.html?DbPAR=CALC">Bit İşlem Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060101.html?DbPAR=CALC">Veritabanı İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060102.html?DbPAR=CALC">Tarih ve Zaman İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060103.html?DbPAR=CALC">Finansal İşlevler Kısım Bir</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060119.html?DbPAR=CALC">Finansal İşlevler Kısım İki</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060118.html?DbPAR=CALC">Finansal İşlevler Kısım Üç</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060104.html?DbPAR=CALC">Bilgi İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060105.html?DbPAR=CALC">Mantıksal İşlevler</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060106.html?DbPAR=CALC">Matematiksel İşlevler</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060108.html?DbPAR=CALC">İstatistik İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060181.html?DbPAR=CALC">İstatistiksel İşlevler Kısım Bir</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060182.html?DbPAR=CALC">İstatistiksel İşlevler Kısım İki</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060183.html?DbPAR=CALC">İstatistiksel İşlevler Kısım Üç</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060184.html?DbPAR=CALC">İstatistiksel İşlevler Kısım Dört</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060185.html?DbPAR=CALC">İstatistik İşlevleri Kısım Beş</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060109.html?DbPAR=CALC">Hesap Tablosu İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060110.html?DbPAR=CALC">Metin İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060111.html?DbPAR=CALC">Eklenti İşlevleri</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060115.html?DbPAR=CALC">Eklenti İşlevleri, Analiz İşlevlerinin Listesi Kısım Bir</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060116.html?DbPAR=CALC">Eklenti İşlevleri, Analiz İşlevlerinin Listesi Kısım İki</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice Calc İçindeki İşleçler</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Kullanıcı Tanımlı Fonksiyonlar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Yüklemek, Kaydetmek, İçe Aktarmak, Dışa Aktarmak ve Düzenlemek</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/webquery.html?DbPAR=CALC">Tablolardaki Harici Verinin Eklenmesi (WebSorgusu)</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/html_doc.html?DbPAR=CALC">Çalışma Sayfalarının HTML olarak Kaydedilmesi ve Açılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/csv_formula.html?DbPAR=CALC">Metin Dosyalarının İçe alınması ve Dışarı Aktarılması</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Biçimlendirme</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/text_rotate.html?DbPAR=CALC">Metin Döndürme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/text_wrap.html?DbPAR=CALC">Çok Satırlı Metinlerin Yazılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/text_numbers.html?DbPAR=CALC">Sayıların Metin Olarak Biçemlendirilmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/super_subscript.html?DbPAR=CALC">Metin Üst Simge / Alt Simge</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/row_height.html?DbPAR=CALC">Satır Yüksekliği veya Sütun Genişliğini Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Koşullu Biçimlendirme Uygulanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Negatif Sayıların Vurgulanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Formüllerle Biçemler Atama</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Sıfır ile Başlayan Sayıların Girilmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/format_table.html?DbPAR=CALC">Hesap Tablolarının Biçemlendirilmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/format_value.html?DbPAR=CALC">Sayıların Ondalık Olarak Biçimlenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/value_with_name.html?DbPAR=CALC">Hücrelerin Adlandırılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/table_rotate.html?DbPAR=CALC">Tabloları (Devrik) dönüştürme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/rename_table.html?DbPAR=CALC">Çalışma Sayfalarını Yeniden Adlandırma</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx Yılları</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Yuvarlaması Kapalı Sayıları Kullanma</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/currency_format.html?DbPAR=CALC">Para Birimi Biçimli Hücreler</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/autoformat.html?DbPAR=CALC">Tablolar için Otomatik Biçimlendir Kullanılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/note_insert.html?DbPAR=CALC">Notları Ekleme ve Düzenleme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/design.html?DbPAR=CALC">Çalışma Sayfaları için Tema Seçimi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Kesirlerin Girilmesi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Süzmek ve Sıralamak</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/filters.html?DbPAR=CALC">Süzgeçler Uygulanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/autofilter.html?DbPAR=CALC">Otomatik Süzgeç Uygulama</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/sorted_list.html?DbPAR=CALC">Sıralı Listelerin Uygulanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Yazdırma</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/print_title_row.html?DbPAR=CALC">Satırları veya Sütunları Her Sayfada Yazdırma</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/print_landscape.html?DbPAR=CALC">Çalışma Sayfalarının Yatay Yazdırılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/print_details.html?DbPAR=CALC">Sayfa Ayrıntılarının Yazdırılması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/print_exact.html?DbPAR=CALC">Yazdırmak için Sayfaların Belirlenmesi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Veri Aralıkları</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/database_define.html?DbPAR=CALC">Veritabanı Aralıklarının Belirlenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/database_filter.html?DbPAR=CALC">Hücre Aralıklarının Süzülmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/database_sort.html?DbPAR=CALC">Veri Sıralamak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Özet Tablo</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot.html?DbPAR=CALC">Özet Tablo</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Özet Tablo Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Veri Pilotu Tabloları Silmek</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Özet Tablolarının Düzenlenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Özet Tabloları Süzmek</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Özet Tablodan Çıktı Aralıkları Seçmek</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Özet Tabloları Güncellemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Özet Grafik</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart.html?DbPAR=CALC">Özet Grafik</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Özet Çizelge Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Özet Grafikleri Düzenleme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Özet Grafikleri Süzme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Özet Grafik Güncelleme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Özet Grafikleri Silme</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08095"><label for="08095">Veri Analizi</label><ul>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_sampling.html?DbPAR=CALC">Data Sampling in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_descriptive.html?DbPAR=CALC">Descriptive Statistics in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_anova.html?DbPAR=CALC">ANOVA</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_correlation.html?DbPAR=CALC">Data Correlation in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_covariance.html?DbPAR=CALC">Data Covariance in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_exposmooth.html?DbPAR=CALC">Exponential Smoothing in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_movingavg.html?DbPAR=CALC">Moving Average in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_regression.html?DbPAR=CALC">Regresyon Analizi</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_test_t.html?DbPAR=CALC">Paired t-test in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_test_f.html?DbPAR=CALC">F Test Statistics in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_test_z.html?DbPAR=CALC">Z Test Statistics in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_test_chisqr.html?DbPAR=CALC">Chi Square Statistics in Calc</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/statistics_fourier.html?DbPAR=CALC">Fourier Analysis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Senaryolar</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/scenario.html?DbPAR=CALC">Senaryoların Kullanılması</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Aratoplamlar</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referanslar</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresler ve Başvurular, Mutlak ve Göreceli</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/r1c1syntax.html?DbPAR=CALC">R1C1 Syntax</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referencing a Cell in Another Sheet</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referencing URLs in other Sheets</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Hücre Başvuruları Sürükle ve Bırak ile</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/address_auto.html?DbPAR=CALC">Adresleme için İsimlerin Tanınması</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Görüntülemek, Seçmek, Kopyalamak</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/table_view.html?DbPAR=CALC">Tablo Görünümünü Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/formula_value.html?DbPAR=CALC">Formüllerin veya Değerlerin Görüntülenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/line_fix.html?DbPAR=CALC">Satırların veya Sütunların Başlık Olarak Sabitlenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/multi_tables.html?DbPAR=CALC">Çalışma Sayfaları Sekmesi ile Gezinme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Çok Sayıda Çalışma Sayfasına Kopyalama</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cellcopy.html?DbPAR=CALC">Sadece Görünür Hücreleri Kopyala</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/mark_cells.html?DbPAR=CALC">Hücrelerin Çoklu Seçimi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/move_dragdrop.html?DbPAR=CALC">Hücrelerin Sürükleyip Bırakılmasıyla Taşınması</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formüller ve Hesaplamalar</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/formulas.html?DbPAR=CALC">Formüller İle Hesaplama</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/formula_copy.html?DbPAR=CALC">Formüllerin Kopyalanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/formula_enter.html?DbPAR=CALC">Formüllerin Girilmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/formula_value.html?DbPAR=CALC">Formüllerin veya Değerlerin Görüntülenmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/calculate.html?DbPAR=CALC">Çalışma Sayfalarında Hesaplamak</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/calc_date.html?DbPAR=CALC">Tarih ve Zaman ile Hesaplama Yapmak</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/calc_series.html?DbPAR=CALC">Serilerin Otomatik Hesaplanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Zaman Farklarının Hesaplanması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/matrixformula.html?DbPAR=CALC">Matris Formüllerinin Girilmesi</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Koruma</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/cell_protect.html?DbPAR=CALC">hücreleri değişikliklerden koruma</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Hücrelerin Korumasının Kaldırılması</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Calc Makroları Yazma</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Çeşitli</label><ul>\
    <li><a target="_top" href="tr/text/scalc/guide/auto_off.html?DbPAR=CALC">Otomatik Düzeltmelerin Durdurulması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/consolidate.html?DbPAR=CALC">Veri Birleştirme</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/goalseek.html?DbPAR=CALC">Hedef Ara Uygulaması</a></li>\
    <li><a target="_top" href="tr/text/scalc/01/solver.html?DbPAR=CALC">Çözücü</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/multioperation.html?DbPAR=CALC">Çoklu İşlemler Uygulaması</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/multitables.html?DbPAR=CALC">Çoklu Sayfalarla Çalışma</a></li>\
    <li><a target="_top" href="tr/text/scalc/guide/validity.html?DbPAR=CALC">Hücre İçeriklerinin Geçerliliği</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Sunum (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/simpress/main0000.html?DbPAR=IMPRESS">LibreOffice Impress Yardımına Hoş Geldiniz</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">LibreOffice Impress&#39;de Kısayol Tuşlarını Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impress için Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/simpress/04/presenter.html?DbPAR=IMPRESS">Sunum Paneli Klavye Kısayolları</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impress için Kullanım Yönergeleri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Komut ve Menü Referansı</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menüler</label><ul>\
    <li><a target="_top" href="tr/text/simpress/main0100.html?DbPAR=IMPRESS">Menüler</a></li>\
    <li><a target="_top" href="tr/text/shared/menu/PickList.html?DbPAR=IMPRESS">Dosya Menüsü</a></li>\
    <li><a target="_top" href="tr/text/shared/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="tr/text/shared/main0103.html?DbPAR=IMPRESS">Görünüm</a></li>\
    <li><a target="_top" href="tr/text/shared/main0104.html?DbPAR=IMPRESS">Ekle</a></li>\
    <li><a target="_top" href="tr/text/shared/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="tr/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0114.html?DbPAR=IMPRESS">Slayt Gösterisi</a></li>\
    <li><a target="_top" href="tr/text/shared/main_tools.html?DbPAR=IMPRESS">Main Tools Menu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0107.html?DbPAR=IMPRESS">Window</a></li>\
    <li><a target="_top" href="tr/text/shared/main0108.html?DbPAR=IMPRESS">Yardım</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Araç çubukları</label><ul>\
    <li><a target="_top" href="tr/text/simpress/main0200.html?DbPAR=IMPRESS">Araç Çubukları</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0210.html?DbPAR=IMPRESS">Çizim Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0227.html?DbPAR=IMPRESS">Nokta Düzenleme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/02/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="tr/text/shared/main0226.html?DbPAR=IMPRESS">Form Tasarım Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0213.html?DbPAR=IMPRESS">Form Gezinme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0214.html?DbPAR=IMPRESS">Resim Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0202.html?DbPAR=IMPRESS">Çizgi ve Doldurma Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0213.html?DbPAR=IMPRESS">Seçenek Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0211.html?DbPAR=IMPRESS">Anahat Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0209.html?DbPAR=IMPRESS">Cetveller</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0212.html?DbPAR=IMPRESS">Slayt Sıralama Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0204.html?DbPAR=IMPRESS">Slayt Görünüm Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0201.html?DbPAR=IMPRESS">Standart Çubuk</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0206.html?DbPAR=IMPRESS">Durum Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0204.html?DbPAR=IMPRESS">Tablo Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/simpress/main0203.html?DbPAR=IMPRESS">Metin Biçimlendirme Çubuğu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Yükleme, Kaydetme, İçe Aktarma, Dışa Aktarma ve Düzenleme</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML Sayfalarını Sunumlara İçe Aktarma</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">GIF Biçim&#39;indeki Canlandırmaları Dışa Aktarma</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafik Eklemek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Biçimlendirme</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Çizgi ve Ok Biçemlerini Yükleme</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Özel Renkleri Tanımlama</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Geçişli Dolgu Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Renkleri Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Nesneleri Düzenlemek, Hizalamak ve Dağıtmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/background.html?DbPAR=IMPRESS">Slayt Arkaplan Doldurması Değiştiriliyor</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/footer.html?DbPAR=IMPRESS">Bütün Slaytlara Üst Bilgi ve Alt Bilgi Ekleme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Nesneleri Hareket Ettirmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Yazdırma</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/printing.html?DbPAR=IMPRESS">Sunumları Yazdırmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Slaytı kağıt Boyutuna Uyacak Şekilde Yazdırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Etkiler</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">GIF Biçim&#39;indeki Canlandırmaları Dışa Aktarma</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Sunum Slaytlarında Nesneleri Canlandırma</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Slayt Geçişini Canlandırmak</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">İki Nesneyi Çapraz Geçirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Hareketli GIF Resim Oluşturmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Nesneler, Grafikler ve Biteşlemler</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Nesneleri Birleştirmek ve Şekil İnşa Etmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Nesneleri Grupla</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Dilimleri ve Bölümleri Çizmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Nesneleri Çoğaltmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Nesneleri Döndürmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">3D Nesneleri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Çizgileri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Metin Karakterlerini Çizim Nesnelerine Dönüştürmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Bit Eşlem Görüntüleri Vektör Grafiklere Çevirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">2 boyutlu (2B) nesneleri eğrilere, çokgenlere ve 3B nesnelere çevirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Çizgi ve Ok Biçemlerini Yükleme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Eğri Çizmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Eğirileri Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafik Eklemek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Nesneleri Hareket Ettirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Altta Kalan Nesneleri Seçmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Bir Akış grafiği oluşturmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Sunumlardaki Metin</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Metin Ekleme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Metin Karakterlerini Çizim Nesnelerine Dönüştürmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Görünüm</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Slayt Sırasını Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Klavye ile Yakınlaştırmak/Uzaklaştırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slayt Gösterileri</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/show.html?DbPAR=IMPRESS">Slayt Gösterisi Gösterme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Sunucu Panelini Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Uzaktan Kumanda</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/individual.html?DbPAR=IMPRESS">Özel Bir Slayt Gösterisi Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Slayt Değişimlerinin Zamanlama Provaları</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Çizimler (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Genel Bilgi ve Kullanıcı Arayüz Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice Draw Yardım Sayfansına Hoş Geldiniz</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Çizim Nesneleri İçin Kısayol Anahtarları</a></li>\
    <li><a target="_top" href="tr/text/sdraw/04/01020000.html?DbPAR=DRAW">Çizimler için Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw için Kullanım Yönergeleri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Komut ve Menü Başvurusu</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menüler</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/main0100.html?DbPAR=DRAW">Menüler</a></li>\
    <li><a target="_top" href="tr/text/shared/menu/PickList.html?DbPAR=DRAW">Dosya Menüsü</a></li>\
    <li><a target="_top" href="tr/text/shared/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="tr/text/shared/main0103.html?DbPAR=DRAW">Görünüm</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main_insert.html?DbPAR=DRAW">Ekle</a></li>\
    <li><a target="_top" href="tr/text/shared/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main_page.html?DbPAR=DRAW">Sayfa</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main_shape.html?DbPAR=DRAW">Şekil</a></li>\
    <li><a target="_top" href="tr/text/shared/main_tools.html?DbPAR=DRAW">Main Tools Menu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0107.html?DbPAR=DRAW">Window</a></li>\
    <li><a target="_top" href="tr/text/shared/main0108.html?DbPAR=DRAW">Yardım</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Araç çubukları</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/main0200.html?DbPAR=DRAW">Araç çubukları</a></li>\
    <li><a target="_top" href="tr/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3B Ayarları</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main0210.html?DbPAR=DRAW">Ana Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0227.html?DbPAR=DRAW">Nokta Düzenleme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/02/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="tr/text/shared/main0226.html?DbPAR=DRAW">Form Tasarım Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0213.html?DbPAR=DRAW">Form Gezinme Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/sdraw/main0213.html?DbPAR=DRAW">Seçenek çubuğu</a></li>\
    <li><a target="_top" href="tr/text/shared/main0201.html?DbPAR=DRAW">Standart Çubuk</a></li>\
    <li><a target="_top" href="tr/text/shared/main0204.html?DbPAR=DRAW">Tablo Çubuğu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Yükleme, Kaydetme, İçe Aktarma ve Dışa Aktarma</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafik Eklemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Biçimlendirme</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Çizgi ve Ok Biçemlerini Yükleme</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/color_define.html?DbPAR=DRAW">Özel Renkleri Tanımlama</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/gradient.html?DbPAR=DRAW">Geçişli Dolgu Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Renkleri Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Nesneleri Düzenlemek, Hizalamak ve Dağıtmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/background.html?DbPAR=DRAW">Slayt Arkaplan Doldurması Değiştiriliyor</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/move_object.html?DbPAR=DRAW">Nesneleri Hareket Ettirmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Yazdırma</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/printing.html?DbPAR=DRAW">Sunumları Yazdırmak</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Slaytı kağıt Boyutuna Uyacak Şekilde Yazdırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efektler</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">İki Nesneyi Çapraz Geçirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/01/05350000.html?DbPAR=DRAW">3B Efektler</a></li>\
    <li><a target="_top" href="tr/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Nesneler, Grafikler ve Biteşlemler</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Nesneleri Birleştirmek ve Şekil İnşa Etmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Dilimleri ve Bölümleri Çizmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Nesneleri Çoğaltmak</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Nesneleri Döndürmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">3D Nesneleri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Çizgileri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/text2curve.html?DbPAR=DRAW">Metin Karakterlerini Çizim Nesnelerine Dönüştürmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/vectorize.html?DbPAR=DRAW">Bit Eşlem Görüntüleri Vektör Grafiklere Çevirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/3d_create.html?DbPAR=DRAW">2 boyutlu (2B) nesneleri eğrilere, çokgenlere ve 3B nesnelere çevirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Çizgi ve Ok Biçemlerini Yükleme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_draw.html?DbPAR=DRAW">Eğri Çizmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/line_edit.html?DbPAR=DRAW">Eğirileri Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafik Eklemek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/table_insert.html?DbPAR=DRAW">Including Tables and Spreadsheets in Slides</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/move_object.html?DbPAR=DRAW">Nesneleri Hareket Ettirmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/select_object.html?DbPAR=DRAW">Altta Kalan Nesneleri Seçmek</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/orgchart.html?DbPAR=DRAW">Bir Akış grafiği oluşturmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Gruplar ve Katmanlar</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/groups.html?DbPAR=DRAW">Nesneleri Grupla</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/layers.html?DbPAR=DRAW">Katmanlar Hakkında</a></li>\
    <li><a target="_top" href="tr/text/sdraw/01/insert_layer.html?DbPAR=DRAW">Katman Ekle</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Katmanlarla Çalışmak.</a></li>\
    <li><a target="_top" href="tr/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Nesneleri Farklı Bir Katmana Taşıma</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Çizimlerdeki Metin</label><ul>\
    <li><a target="_top" href="tr/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Metin Ekleme</a></li>\
    <li><a target="_top" href="tr/text/simpress/guide/text2curve.html?DbPAR=DRAW">Metin Karakterlerini Çizim Nesnelerine Dönüştürmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Görünüm</label><ul>\
    <li><a target="_top" href="tr/text/simpress/guide/change_scale.html?DbPAR=DRAW">Klavye ile Yakınlaştırmak/Uzaklaştırmak</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Veritabanı İşlevselliği (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Genel Bilgiler</label><ul>\
    <li><a target="_top" href="tr/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Veritabanı</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/database_main.html?DbPAR=BASE">Veritabanı Genel Bakış</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_new.html?DbPAR=BASE">Yeni Veritabanı Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_tables.html?DbPAR=BASE">Tablolarla Çalışmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_queries.html?DbPAR=BASE">Sorgularla Çalışmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_forms.html?DbPAR=BASE">Formlar ile Çalışmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_reports.html?DbPAR=BASE">Rapor Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_register.html?DbPAR=BASE">Veritabanını Kaydetmek ve Silmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_im_export.html?DbPAR=BASE">Base&#39;de Verileri İçe ve Dışa Aktarmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQL Komutlarını Çalıştırmak</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formüller (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/smath/main0000.html?DbPAR=MATH">LibreOffice Math Yardımına Hoş Geldiniz</a></li>\
    <li><a target="_top" href="tr/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math Özellikleri</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formül Ögeleri</label><ul>\
    <li><a target="_top" href="tr/text/smath/01/03090100.html?DbPAR=MATH">Birli/ikili Operatörler</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090200.html?DbPAR=MATH">İlişkiler</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090800.html?DbPAR=MATH">Küme İşlemleri</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090400.html?DbPAR=MATH">İşlevler</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090300.html?DbPAR=MATH">İşleçler</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090600.html?DbPAR=MATH">Öznitelikler</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090500.html?DbPAR=MATH">Ayraçlar</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03090700.html?DbPAR=MATH">Biçim</a></li>\
    <li><a target="_top" href="tr/text/smath/01/03091600.html?DbPAR=MATH">Diğer Semboller</a></li>\
      </ul></li>\
    <li><a target="_top" href="tr/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Math için Kullanım Yönergeleri</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/keyboard.html?DbPAR=MATH">Kısayollar (LibreOffice Math Erişebilirlik)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Komut ve Menü Referansı</label><ul>\
    <li><a target="_top" href="tr/text/smath/main0100.html?DbPAR=MATH">Menüler</a></li>\
    <li><a target="_top" href="tr/text/smath/main0200.html?DbPAR=MATH">Araç Çubukları</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Formüller ile Çalışmak</label><ul>\
    <li><a target="_top" href="tr/text/smath/guide/align.html?DbPAR=MATH">Formül Bölümlerini Elle Hizalama</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/color.html?DbPAR=MATH">Formül Parçalarına Renk Uygulama</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/attributes.html?DbPAR=MATH">Varsayılan Özellikleri Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/brackets.html?DbPAR=MATH">Köşeli Parantezler içindeki Formül Kısımlarını Birleştirme</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/comment.html?DbPAR=MATH">Açıklama Girişi</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/newline.html?DbPAR=MATH">Satır Kesmeleri Giriliyor</a></li>\
    <li><a target="_top" href="tr/text/smath/guide/parentheses.html?DbPAR=MATH">Ayraç Ekleme</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Çizelge ve Diyagramlar</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Genel Bilgi</label><ul>\
    <li><a target="_top" href="tr/text/schart/main0000.html?DbPAR=CHART">LibreOffice Grafikleri</a></li>\
    <li><a target="_top" href="tr/text/schart/main0503.html?DbPAR=CHART">LibreOffice Çizelge Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/schart/04/01020000.html?DbPAR=CHART">Grafikler için Kısayol Tuşları</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makrolar ve Betik</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic Yardım</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01000000.html?DbPAR=BASIC">LibreOffice Basic ile Programlama</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic Sözlüğü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01010210.html?DbPAR=BASIC">Temel Bilgiler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sözdizimi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE Genel Bakış</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic Düzenleyicisi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01050100.html?DbPAR=BASIC">İzleme Penceresi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/main0211.html?DbPAR=BASIC">Macro Araç Çubuğu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">VBA Makro Desteği</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Komut Başvurusu</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020500.html?DbPAR=BASIC">Kütüphaneler, Modüller ve İletişim Öğeleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">İşlevler, İfadeler ve İşleçler</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/03040000.html?DbPAR=BASIC">Temel Sabitler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100000.html?DbPAR=BASIC">Değişkenler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060000.html?DbPAR=BASIC">Mantıksal Operatörler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03110100.html?DbPAR=BASIC">Karşılaştırma Operatörleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120000.html?DbPAR=BASIC">Karakter Dizileri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030000.html?DbPAR=BASIC">Tarih ve Zaman Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematiksel Operatörler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080000.html?DbPAR=BASIC">Sayısal Fonksiyonlar</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometrik İşlevler</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010000.html?DbPAR=BASIC">Ekran Girdi/Çıktı Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020000.html?DbPAR=BASIC">Dosya Girdi/Çıktı Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090000.html?DbPAR=BASIC">Program Çalışmasını Kontrol</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hata-İşleme Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130000.html?DbPAR=BASIC">Diğer Komutlar</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080300.html?DbPAR=BASIC">Rasgele Sayı Üretimi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Özel VBA fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/vba_objects.html?DbPAR=BASIC">VBA Supported Objects</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090400.html?DbPAR=BASIC">Diğer Deyimler</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">İşlevlerin, İfadelerin ve İşleçlerin Alfabetik Listesi</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060100.html?DbPAR=BASIC">VE Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010301.html?DbPAR=BASIC">Mavi Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020101.html?DbPAR=BASIC">Kapanış İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/CreateUnoSvcWithArgs.html?DbPAR=BASIC">CreateUnoServiceWithArguments Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030103.html?DbPAR=BASIC">Gün Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/doEvents.html?DbPAR=BASIC">DoEvents Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090404.html?DbPAR=BASIC">End İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050300.html?DbPAR=BASIC">Hata Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hata-İşleme Fonksiyonları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03170020.html?DbPAR=BASIC">FormatPercent Function [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020102.html?DbPAR=BASIC">BoşDosya Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020201.html?DbPAR=BASIC">Al İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010302.html?DbPAR=BASIC">Yeşil Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030201.html?DbPAR=BASIC">Saat Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Deyimi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020202.html?DbPAR=BASIC">Girdi# İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Fonksiyonu, Mid İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030202.html?DbPAR=BASIC">Dakika Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030104.html?DbPAR=BASIC">Ay Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020412.html?DbPAR=BASIC">İsim İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060400.html?DbPAR=BASIC">Değil Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030203.html?DbPAR=BASIC">Şimdi Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080000.html?DbPAR=BASIC">Sayısal Fonksiyonlar</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Deyimi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub İfadesi; On...GoTo İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020103.html?DbPAR=BASIC">Aç İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03104100.html?DbPAR=BASIC">Seçimsel (Fonksiyonu İfadesinde)</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060500.html?DbPAR=BASIC">Veya Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080301.html?DbPAR=BASIC">Rastgele İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010303.html?DbPAR=BASIC">Kırmızı Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020104.html?DbPAR=BASIC">Sıfırla İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030204.html?DbPAR=BASIC">Saniye Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020304.html?DbPAR=BASIC">Ara Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080400.html?DbPAR=BASIC">Kare Kök Hesaplama</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030303.html?DbPAR=BASIC">Zamanlayıcı İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Fonksiyonu; VarType Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030105.html?DbPAR=BASIC">HaftanınGünü Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Fonksiyonu [VBA]</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03090411.html?DbPAR=BASIC">With İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03020205.html?DbPAR=BASIC">Yaz İfadesi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03030106.html?DbPAR=BASIC">Yıl Fonksiyonu</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operatörü</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03120300.html?DbPAR=BASIC">Karakter Dizilerini Düzenleme</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020100.html?DbPAR=BASIC">Değişkenlerin Kullanımı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Gelişmiş Basic Kütüphaneleri</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Araçlar Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Kitaplığı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Kitaplığı</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge Kütüphanesi</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Kitaplıkları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_toc.html?DbPAR=BASIC">List of all ScriptForge methods and properties</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array servisi (SF_Array)</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base servisi</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><input type="checkbox" id="07010501"><label for="07010501">Örnek Betikler</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/guide/read_write_values.html?DbPAR=BASIC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/calc_borders.html?DbPAR=BASIC">Formatting Borders in Calc with Macros</a></li>\
            </ul></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_contextmenu.html?DbPAR=BASIC">SFWidgets.ContextMenu service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_dataset.html?DbPAR=BASIC">SFDatabases.Dataset service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_datasheet.html?DbPAR=BASIC">SFDatabases.Datasheet service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_formdocument.html?DbPAR=BASIC">SFDocuments.FormDocument service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_toolbar.html?DbPAR=BASIC">SFWidgets.Toolbar service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_toolbarbutton.html?DbPAR=BASIC">SFWidgets.ToolbarButton service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Kılavuzlar</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makro Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/control_properties.html?DbPAR=BASIC">İletişim Öğesi Düzenleyisinde Denetim Özelliklerini Değiştirme</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/insert_control.html?DbPAR=BASIC">İletişim Ögesinde Denetimler Oluşturur</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/sample_code.html?DbPAR=BASIC">İletişim Öğesi Denetimleri için Programlama Örnekleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Basit bir İletişim Öğesi Oluşturur</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01030400.html?DbPAR=BASIC">Kütüphaneleri ve Modülleri Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020100.html?DbPAR=BASIC">Değişkenlerin Kullanımı</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01020200.html?DbPAR=BASIC">Nesneler Kullanılır</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01030300.html?DbPAR=BASIC">Bir Basic Programında Hata Ayıklamak</a></li>\
    <li><a target="_top" href="tr/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programlama Örnekleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic&#39;ten Python&#39;a</a></li>\
    <li><a target="_top" href="tr/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Betikleri Yardım</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Genel Bilgi ve Kullanıcı Arayüzü Kullanımı</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Betikleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_ide.html?DbPAR=BASIC">Python için IDE</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Betikleri Düzenleyici</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/running_scripts.html?DbPAR=BASIC">Running Python Scripts</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Python ile Programlama</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Python ile Programlama</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python örnekleri</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python&#39;dan Basic&#39;e</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070203"><label for="070203">Python Modülleri</label><ul>\
    <li><a target="_top" href="tr/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Kitaplıkları</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Python ile Programlama</a></li>\
    <li><a target="_top" href="tr/text/sbasic/python/python_screen.html?DbPAR=BASIC">Python : Screen Input/Output</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Betik Geliştirme Araçları</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Kurulumu</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office Belge Türlerinin İlişkilendirilmesini Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Troubleshoot Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Genel Yardım Konuları</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Genel Bilgi</label><ul>\
    <li><a target="_top" href="tr/text/shared/main0400.html?DbPAR=SHARED">Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/shared/00/00000005.html?DbPAR=SHARED">Genel Sözlük</a></li>\
    <li><a target="_top" href="tr/text/shared/00/00000002.html?DbPAR=SHARED">İnternet Terimleri Sözlüğü</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice &#39;da Erişebilirlik</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/keyboard.html?DbPAR=SHARED">Kısayollar (LibreOffice&#39;da Erişebilirlik)</a></li>\
    <li><a target="_top" href="tr/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice&#39;da Genel Kısayol Tuşları</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/version_number.html?DbPAR=SHARED">Sürümler ve İnşa Numaraları</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice ve Microsoft Office</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/ms_user.html?DbPAR=SHARED">Microsoft Office ve LibreOffice Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Microsoft Office ve LibreOffice Terimlerini Karşılaştırmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office Belgelerinin Dönüştürülmesi Hakkında</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office Belge Türlerinin İlişkilendirilmesini Değiştirmek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Seçenekleri</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01000000.html?DbPAR=SHARED">Seçenekler</a></li>\
    <li><input type="checkbox" id="100401"><label for="100401">LibreOffice</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01010100.html?DbPAR=SHARED">Kullanıcı Verisi</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010600.html?DbPAR=SHARED">Genel</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010800.html?DbPAR=SHARED">Görünüm</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010900.html?DbPAR=SHARED">Yazdırma Seçenekleri</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010300.html?DbPAR=SHARED">Veri yolu</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010700.html?DbPAR=SHARED">Yazı Tipleri</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01030300.html?DbPAR=SHARED">Güvenlik</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/java.html?DbPAR=SHARED">Gelişmiş</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Uzman Yapılandırma</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Temel IDE</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01013000.html?DbPAR=SHARED">Erişilebilirlik</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100402"><label for="100402">Yükle/Kaydet</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01010200.html?DbPAR=SHARED">Genel</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA Özellikleri</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Ofis</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01030500.html?DbPAR=SHARED">HTML uyumluluğu</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100403"><label for="100403">Diller ve Yerel Ayarlar</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01150000.html?DbPAR=SHARED">Dil Ayar Seçenekleri</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01010400.html?DbPAR=SHARED">Yazım Yardımı</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100404"><label for="100404">LibreOffice Writer</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01040000.html?DbPAR=SHARED">Metin belgesi seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100405"><label for="100405">LibreOffice Writer/Web</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML Belgesi Seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100406"><label for="100406">LibreOffice Calc</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01060000.html?DbPAR=SHARED">Hesap Tablosu Seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100407"><label for="100407">LibreOffice Impress</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01070000.html?DbPAR=SHARED">Sunum Seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100408"><label for="100408">LibreOffice Draw</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01080000.html?DbPAR=SHARED">Çizim Seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100409"><label for="100409">LibreOffice Math</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01090000.html?DbPAR=SHARED">Formül</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100410"><label for="100410">LibreOffice Base</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01160000.html?DbPAR=SHARED">Veri kaynakları seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100412"><label for="100412">Çizelgeler</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01110000.html?DbPAR=SHARED">Çizelge seçenekleri</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100413"><label for="100413">İnternet</label><ul>\
    <li><a target="_top" href="tr/text/shared/optionen/01030000.html?DbPAR=SHARED">İnternet seçenekleri</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Sihirbazlar</label><ul>\
    <li><a target="_top" href="tr/text/shared/autopi/01000000.html?DbPAR=SHARED">Sihirbaz</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Mektup Sihirbazı</label><ul>\
    <li><a target="_top" href="tr/text/shared/autopi/01010000.html?DbPAR=SHARED">Mektup Sihirbazı</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Fax Sihirbazı</label><ul>\
    <li><a target="_top" href="tr/text/shared/autopi/01020000.html?DbPAR=SHARED">Faks Sihirbazı</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Ajanda Sihirbazı</label><ul>\
    <li><a target="_top" href="tr/text/shared/autopi/01040000.html?DbPAR=SHARED">Ajanda Sihirbazı</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Belge Dönüştürme Sihirbazı</label><ul>\
    <li><a target="_top" href="tr/text/shared/autopi/01130000.html?DbPAR=SHARED">Belge dönüştürücü</a></li>\
      </ul></li>\
    <li><a target="_top" href="tr/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro Dönüştürücü Sihirbazı</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOffice Yapılandırmak</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice&#39;i Yapılandırmak</a></li>\
    <li><a target="_top" href="tr/text/shared/01/packagemanager.html?DbPAR=SHARED">Eklenti Yöneticisi</a></li>\
    <li><a target="_top" href="tr/text/shared/optionen/01012000.html?DbPAR=SHARED">Appearance</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Araç Çubuklarına Düğme Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/workfolder.html?DbPAR=SHARED">Çalışma Dizinini Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Bir Adres Defterini Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/formfields.html?DbPAR=SHARED">Düğme Eklemek ve Düzenlemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Kullanıcı Arayüzü ile Çalışmak</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Nesnelere Hızlı Ulaşmak için Gezinme</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/navigator.html?DbPAR=SHARED">Belgeye Genel Bakış için Gezgin</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/autohide.html?DbPAR=SHARED">Pencereleri Gösterme, Çapalama ve Gizleme</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/textmode_change.html?DbPAR=SHARED">Ekleme ve Üzerine Yazm Kipleri Arasında Geçiş</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Araç Çubuklarını Kullanmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Sayısal İmzalar</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Sayısal İmzalar Hakkında</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Sayısal İmzaları Uygulamak</a></li>\
    <li><a target="_top" href="tr/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="tr/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="tr/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="tr/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="tr/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Yazdırmak, Fax Göndermek, Göndermek</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/labels_database.html?DbPAR=SHARED">Adres Etiketlerini Yazdırmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Siyah ve Beyaz Yazdırmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/fax.html?DbPAR=SHARED">Faks Göndermek ve LibreOffice&#39;i Faks için Yapılandırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Sürükle & Bırak</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop.html?DbPAR=SHARED">LibreOffice Belgelesi İçerisinde Sürüklemek ve Bırakmak</a></li>\
    <li><a target="_top" href="tr/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Belgelerdeki Metni Kopyalamak ve Taşımak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Çalışma Sayfası Alanlarını Metin Belgelerine Kopyalamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafikleri Belgeler Arasında Kopyalamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Galeri&#39;den Nesne Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Veri Kaynağı Görünümünde Sürükle ve Bırak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopyala ve Yapıştır</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Çizim Nesnelerini Başka Belgelere Kopyalamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafikleri Belgeler Arasında Kopyalamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Galeri&#39;den Nesne Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Çalışma Sayfası Alanlarını Metin Belgelerine Kopyalamak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Çizelge ve Diyagramlar</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/chart_insert.html?DbPAR=SHARED">Çizelge Eklemek</a></li>\
    <li><a target="_top" href="tr/text/schart/main0000.html?DbPAR=SHARED">LibreOffice Grafikleri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Yükle, Kaydet, İçe Aktar, Dışa Aktar, PDF</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/doc_open.html?DbPAR=SHARED">Belgeleri Açmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/import_ms.html?DbPAR=SHARED">Diğer biçimlerde kaydedilmiş belgeleri açmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/doc_save.html?DbPAR=SHARED">Belgeleri Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Belgeleri Otomatik Olarak Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Uzak Dosyaları Kullanmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/export_ms.html?DbPAR=SHARED">Belgeleri Başka Biçimlerde Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">PDF Olarak Aktar</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Metin Biçimindeki Verileri İçe ve Dışa Aktarmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Bağlantılar ve Başvurular</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Köprü Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Göreceli ve Mutlak Bağlantılar</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Köprüleri Düzenlemek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Belge Sürüm Kaydı</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Bir Belgenin Sürümlerini Karşılaştırmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Sürümleri Birleştirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Değişiklikleri Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining.html?DbPAR=SHARED">Değişiklikleri Kaydetmek ve Göstermek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Değişiklikleri Kabul Etmek veya Reddetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Sürüm Yönetimi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiketler ve Kartvizitler</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/labels.html?DbPAR=SHARED">Kartvizit ve Etiket Oluşturmak ve Yazdırmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Harici Veri Eklemek</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/copytable2application.html?DbPAR=SHARED">Çalışma Sayfalarından Veri Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/copytext2application.html?DbPAR=SHARED">Metin Belgelerinden Veri Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Bit Eşlemleri Eklemek, Düzenlemek ve Kaydetmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Galeriye Grafikler Ekleme</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Otomatik İşlevler</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Otomatik URL Tanımayı Kapatmak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Bulmak ve Değiştirmek</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/data_search2.html?DbPAR=SHARED">Form Süzgeciyle Aramak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_search.html?DbPAR=SHARED">Tabloları ve Form Belgelerini Aramak</a></li>\
    <li><a target="_top" href="tr/text/shared/01/02100001.html?DbPAR=SHARED">Düzenli İfadeler Listesi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Rehberler</label><ul>\
    <li><a target="_top" href="tr/text/shared/guide/linestyles.html?DbPAR=SHARED">Çizgi Biçimlerini Uygulamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/text_color.html?DbPAR=SHARED">Metin Rengini Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/change_title.html?DbPAR=SHARED">Belgenin Başlığını Değiştirmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/round_corner.html?DbPAR=SHARED">Yuvarlak Köşeler Oluşturmak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/background.html?DbPAR=SHARED">Arkaplan Renkleri veya Arkaplan Grafiklerini Tanımlamak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Çizgi Biçimlerini Belirlemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Grafik Nesnelerini Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/line_intext.html?DbPAR=SHARED">Metinde Çizgiler Çizmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/aaa_start.html?DbPAR=SHARED">Birinci Adım</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Galeri&#39;den Nesne Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Bölünemez Boşluklar, Tireler ve Yumuşak Tireler Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Özel Karakter Eklemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/tabs.html?DbPAR=SHARED">Sekme Duraklarını Eklemek ve Düzenlemek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/protection.html?DbPAR=SHARED">LibreOffice&#39;de İçeriği Korumaya Almak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Kayıtları Korumak</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Bir Sayfadaki Azami Yazdırılabilir Alanı Seçmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/measurement_units.html?DbPAR=SHARED">Ölçü Birimlerini Seçmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/language_select.html?DbPAR=SHARED">Belge Dilini Seçmek</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Tablo Tasarımı</a></li>\
    <li><a target="_top" href="tr/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Tekil Paragraflar için Numaralandırmayı ve Madde İmlerini Kapatmak</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
