%% $Id: hvfloat-multisub.inc 1348 2026-10-10 14:08:51Z herbert $
%%
%% Herbert Voss <hvoss@tug.org>
%% Copyright (C) 2003-26
%%
%% This program can be redistributed and/or modified under the terms
%% of the LaTeX Project Public License Distributed from CTAN archives
%% in directory macros/latex/base/lppl.txt.
%%
%% DESCRIPTION:
%%   "hvfloat" offers rotating of captions and objects for floats
%%

\ExplSyntaxOn

\def\getMultiCaptionAndLabel{%
  \ifhv@twoColumnCaption\hv@tempWidthA=\textwidth \else \hv@tempWidthA=\linewidth\fi
  \global\sbox\hvCaptionBox{\minipage[b]{\hv@tempWidthA}%
    \captionsetup{aboveskip=\z@,belowskip=\z@,position=below,parbox=none}%,skip=-1ex}%
    \expandafter\hvFloatSet\expandafter{\hv@save@setting}%    
    \parskip=-0.5\baselineskip
    \hv@cntb=\clist_count:N\l_clist_Type
    \advance\hv@cntb by \@ne
    \hv@cnta=1
    \loop
      \edef\@captype{\clist_item:Nn\l_clist_Type{\hv@cnta}}%
      \edef\@tempa{\clist_item:Nn\l_clist_LofCaption{\hv@cnta}}%
      \ifx\@tempa\@empty
        \caption{\clist_item:Nn\l_clist_Caption{\hv@cnta}}%
      \else
        \expandafter\caption\expandafter[\@tempa]{\clist_item:Nn\l_clist_Caption{\hv@cnta}}%
      \fi    
      \edef\@tempa{\clist_item:Nn\l_clist_Label{\hv@cnta}}%
      \ifx\@tempa\@empty
      \else
        \expandafter\label\expandafter{\clist_item:Nn\l_clist_Label{\hv@cnta}-cap}\fi
      \advance\hv@cnta by \@ne
    \ifnum\hv@cnta<\hv@cntb
    \repeat
    \vspace{-\baselineskip}%  no vspace at the end
  \endminipage}%
}

\def\getMultiObjectAndLabel{%
  \global\savebox\hvObjectBox{%
    \ifhv@vFill
      \minipage[b][\textheight][s]{\columnwidth}%
    \else
      \minipage{\columnwidth}%
    \fi
    \expandafter\hvFloatSet\expandafter{\hv@save@setting}%    
    \ifx\hvSet@objectPos\hv@Right\raggedleft\else
      \ifx\hvSet@objectPos\hv@Left\raggedleft\else
        \ifx\hvSet@objectPos\hv@Center\centering
    \fi\fi\fi
    \hv@cntb=\clist_count:N\l_clist_Type
    \advance\hv@cntb by \@ne
    \hv@cnta=1
    \loop
      \def\@temp{\clist_item:Nn\l_clist_Object{\hv@cnta}}%
      \ifhv@objectFrame\fbox[boxsep=\hv@fboxSep,,\hv@fboxLines]{\@temp}\else\@temp\fi
      \edef\@tempa{\clist_item:Nn\l_clist_Label{\hv@cnta}}%
      \edef\@tempb{\clist_item:Nn\l_clist_Type{\hv@cnta}}%
      \edef\@captype{hv@p\@tempb}%
      \ifx\@tempa\@empty
      \else
        \refstepcounter{\@captype}%
        \expandafter\label\expandafter{\clist_item:Nn\l_clist_Label{\hv@cnta}}%
      \fi
      \ifnum\hv@cnta<\clist_count:N\l_clist_Type\par\hv@vskip\fi
      \advance\hv@cnta by \@ne
    \ifnum\hv@cnta<\hv@cntb
      \ifhv@vFill\vfill\fi
    \repeat
  \endminipage}%
}
\def\getMultiSubCaptionAndLabel{%
  \global\sbox\hvCaptionBox{%
    \minipage{\linewidth}%
    \expandafter\hvFloatSet\expandafter{\hv@save@setting}%    
    \setlength\belowcaptionskip{5pt}%
    \setlength\abovecaptionskip{0pt}%
    \xdef\@captype{\clist_item:Nn\l_clist_Type{1}}%  the same for all subfloats
    \edef\@tempa{\clist_item:Nn\l_clist_LofCaption{1}}%
    \ifx\@tempa\@empty
      \caption{\clist_item:Nn\l_clist_Caption{1}}%
    \else
      \expandafter\caption\expandafter[\@tempa]{\clist_item:Nn\l_clist_Caption{1}}%
    \fi    
    \edef\@tempa{\clist_item:Nn\l_clist_Label{1}}%
    \ifx\@tempa\@empty\else\expandafter\label\expandafter{\clist_item:Nn\l_clist_Label{1}-cap}\fi
  \endminipage}%
}

\def\getMultiSubObjectAndLabel{%
  \global\savebox\hvObjectBox{%
    \expandafter\hvFloatSet\expandafter{\hv@save@setting}%    
    \ifhv@vFill
      \minipage[b][\textheight][s]{\columnwidth}%
      \captionsetup{belowskip=0pt}%
    \else
      \minipage{\columnwidth}%
    \fi
%    \ifx\hv@subcaption@format\@empty\else
%      \expandafter
%      \captionsetup\expandafter[\expandafter s\expandafter u\expandafter b\expandafter]\expandafter
%                             {\hv@subcaption@format}%
%    \fi
    \ifx\hvSet@objectPos\hv@Right\raggedleft\else
      \ifx\hvSet@objectPos\hv@Left\raggedleft\else
        \ifx\hvSet@objectPos\hv@Center\centering    
    \fi\fi\fi
    \hv@cntb=\clist_count:N\l_clist_Caption
    \advance\hv@cntb by \@ne
    \hv@cnta=2
    \edef\@captype{\clist_item:Nn\l_clist_Type{1}}%  the same for all subfloats
    \ifx\@tempa\@empty
    \else
%      \refstepcounter{\@captype}%
%      \expandafter\label\expandafter{\@tempa}%
    \fi
    \loop
      \def\@temp{\clist_item:Nn\l_clist_Object{\hv@cnta}}%
      \ifhv@objectFrame\fbox[boxsep=\hv@fboxSep,,\hv@fboxLines]{\@temp}\else\@temp\fi
      \begingroup
      \edef\@tempa{\clist_item:Nn\l_clist_LofCaption{\hv@cnta}}%
      \ifx\@tempa\@empty
        \subcaption{\clist_item:Nn\l_clist_Caption{\hv@cnta}}%
      \else
        \expandafter\subcaption\expandafter[\@tempa]{\clist_item:Nn\l_clist_Caption{\hv@cnta}}%
      \fi    
      \edef\@tempa{\clist_item:Nn\l_clist_Label{\hv@cnta}}%
      \ifx\@tempa\@empty
      \else
        \expandafter\label\expandafter{\clist_item:Nn\l_clist_Label{\hv@cnta}}%
      \fi
      \endgroup
      \ifnum\hv@cnta<\clist_count:N\l_clist_Type\par\hv@vskip\fi
      \advance\hv@cnta by \@ne
      \ifnum\hv@cnta<\hv@cntb
      \ifhv@vFill\vfill\fi
    \repeat
    \edef\@tempa{\clist_item:Nn\l_clist_Label{1}}%    the  main label at the end
    \ifx\@tempa\@empty
    \else
      \edef\@temp{hv@p\@captype}%
      \refstepcounter{\@temp}%
      \expandafter\label\expandafter{\@tempa}%
    \fi
  \endminipage}%
}
\ExplSyntaxOff

\endinput
