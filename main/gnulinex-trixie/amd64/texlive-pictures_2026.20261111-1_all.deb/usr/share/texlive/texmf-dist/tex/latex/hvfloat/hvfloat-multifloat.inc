%% $Id: hvfloat-multifloat.inc 1348 2026-10-10 14:08:51Z herbert $
%%
%% Herbert Voss <hvoss@tug.org>
%% Copyright (C) 2003-26
%%
%% This program can be redistributed and/or modified under the terms
%% of the LaTeX Project Public License Distributed from CTAN archives
%% in directory macros/latex/base/lppl.txt.
%%
%% DESCRIPTION:
%%   "hvfloat" offers rotating of captions and objects for floats
%%

\ExplSyntaxOn

\def\do@multiFloat+#1#2{%
  \clist_set:Nn\l_clist_Type{{#1}}%
  \clist_set:Nn\l_clist_Object{{#2}}%
  \@ifnextchar[\do@multiFloat@i{\do@multiFloat@i[]}%
}
\def\do@multiFloat@i[#1]#2#3{%  lof-caption, caption,label
  \ifx\relax#1\relax
    \clist_set:Nn\l_clist_LofCaption{{}}%
  \else
    \clist_set:Nn\l_clist_LofCaption{{#1}}%
  \fi
  \clist_set:Nn\l_clist_Caption{{#2}}%
  \ifx\relax#3\relax 
    \clist_set:Nn\l_clist_Label{{}}%
  \else
    \clist_set:Nn\l_clist_Label{{#3}}%
  \fi
  \@ifnextchar+{\do@multiFloat@ii}{}%
} 
\def\do@multiFloat@ii+#1#2{%
  \clist_put_right:Nn\l_clist_Type{{#1}}%
  \clist_put_right:Nn\l_clist_Object{{#2}}%
  \@ifnextchar[\do@multiFloat@iii{\do@multiFloat@iii[]}%
}

\def\do@multiFloat@iii[#1]#2#3{%  lof-caption, caption, label
  \ifx\relax#1\relax
    \clist_put_right:Nn\l_clist_LofCaption{{}}%
  \else
    \clist_put_right:Nn\l_clist_LofCaption{{#1}}%
  \fi
  \clist_put_right:Nn\l_clist_Caption{{#2}}%
  \ifx\relax#3\relax 
    \clist_put_right:Nn\l_clist_Label{{}}%
  \else
    \clist_put_right:Nn\l_clist_Label{{#3}}%
  \fi
  \@ifnextchar+\do@multiFloat@ii%
    {\def\hvSet@CapWidth{n}%
     \do@@@@hvFloat}%
} 

\ExplSyntaxOff

\endinput
