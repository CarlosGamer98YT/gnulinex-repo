"""Custom script for LibreOffice."""
