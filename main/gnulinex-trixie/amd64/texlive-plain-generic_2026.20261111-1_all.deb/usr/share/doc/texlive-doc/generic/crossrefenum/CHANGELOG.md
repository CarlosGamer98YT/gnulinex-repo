## Changes

```{=context}
\parindent=0pt
```

### 2022/11/11: Version 1.0

### 2023/02/20: Version 1.0.1

`\crossrefenum` is now protected against early expansion.

### 2023/02/20: Version 1.0.2

Fixed some minor issues in version numbers and in the manual.

### 2024/04/13: Version 1.1

Various fixes in the documentation and new convenience macro `\crfnm@declareType`.

The test suite now uses _lualatex_.

### 2025/08/07: Version 1.2 

The last argument of `\crossrefenum` can now be a comma-delimited list
instead of a list of groups. Lists of groups are still supported and will remain so.

The new macro `\crfnmsetup` now provides a key-value configuration interface,
thanks to Jonathan `\penalty-10000`{=context} P. Spratte's
[`expkv`](https://ctan.org/pkg/expkv-bundle) package.
The dependency to `expkv` can be removed by deactivating the key-value interface.

Various improvements in the manual.
