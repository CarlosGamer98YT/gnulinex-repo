# Stretchy
## version 0.1
## S. Lurp --- slurper04@gmail.com

Stretchy is a package for creating "stretchy" math symbols.
It provides various ready-made stretchy symbols, as well as auxillary macros for creating them.
Stretchy supports both pdfTeX and LuaTeX.

Stretchy has no dependencies.
Its documentation requires only the pdfToolbox toolkit and MeasureBox package to compile.

Stretchy is provided free of charge for use and distribution as an open source program under the MIT license.

