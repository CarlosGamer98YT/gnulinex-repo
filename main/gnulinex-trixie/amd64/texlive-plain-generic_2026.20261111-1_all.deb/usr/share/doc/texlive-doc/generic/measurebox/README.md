# MeasureBox
## version 1.0
## S. Lurp --- slurper04@gmail.com

MeasureBox is a (plain TeX) package for measuring material.
It is intended for precise measurements of glyphs so that they can be manipulated by other macros and packages
(e.g. the Stretchy package).

Its only dependency is the pdfToolbox package, which is currently only supported by plain-pdfTeX.

This package is provided for free use and distribution under the MIT license.

