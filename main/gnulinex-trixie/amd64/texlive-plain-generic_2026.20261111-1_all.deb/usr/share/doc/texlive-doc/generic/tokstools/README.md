# `tokstools` - A TeX/LaTeX set of tools for manipulating tokens

## Notice

This package is still in the experimental stage. Therefore, its behavior is not guaranteed to match the description in the manual, and bugs of varying severity may occur.

Additionally, some features, as well as their syntax, may be subject to change.

It requires any modern engine that supports etex primitives and can therefore be used with either TeX or LaTeX.

## Description

The tokstools package provides tools for manipulating tokens and implements “PEG”-style grammars in TeX. Predefined elementary patterns can be combined to form grammars that search for matches within tokens.

Two categories of macros are provided:
* those operating on individual tokens (`\toksdo`, `\tokscount`, and `\printtoks`)
* those operating on tokens that have matched a grammar (`\ifpegmatch`, `\pegcount`, and `\pegreplace`)

These matches can be counted, captured, modified, or replaced.

## License

Released under the LaTeX Project Public License v1.3c or later. See https://www.latex-project.org/lppl.txt
