%!
% Colour separation. 
% Ask dvips to do 4 pages. In bop-hook, cycle
% round CMYK color spaces.
%
% Sebastian Rahtz 30.9.93
% checked 7.1.94
% from Green Book, and Kunkel Graphic Design with PostScript
% (Green Book Listing 9-5, on page 153.)
%
% This work is placed in the public domain
/seppages  0  def 
userdict begin
/Min {% 3 items on stack
2 copy lt { pop }{ exch pop } ifelse
2 copy lt { pop }{ exch pop } ifelse
} def
/SetGray {
 1 exch sub systemdict begin adjustdot setgray end	
} def
/sethsbcolor {systemdict begin
  sethsbcolor currentrgbcolor end
  userdict begin setrgbcolor end}def 

/ToCMYK
% Red book p 305
  {
% subtract each colour from 1
  3 { 1 exch sub 3 1 roll } repeat
% define percent of black undercolor
% find minimum (k)
  3 copy  Min 
% remove undercolor
  blackUCR sub
  dup 0 lt {pop 0} if 
  /percent_UCR exch def 
%
% subtract that from each colour
%
  3 { percent_UCR sub 3 1 roll } repeat 
% work out black itself
  percent_UCR 1.25 mul % 1 exch sub
% stack should now have C M Y K
} def 
%
% crop marks
%
/cX 18 def 
/CM{gsave TR 0 cX neg moveto 0 cX lineto stroke
cX neg 0 moveto cX 0 lineto stroke grestore}def 
%
/bop-hook{cX dup TR
%
% which page are we producing
%
   seppages 1 add 
    /seppages exch def
     seppages 5 eq { /seppages  1  def } if
     seppages 1 eq { 
      /ColourName (CYAN) def 
      CYAN setupcolor    
      /WhichColour 3 def } if 
   seppages 2 eq { 
      /ColourName (MAGENTA) def 
      MAGENTA setupcolor 
     /WhichColour 2 def } if
   seppages 3 eq { 
      /ColourName (YELLOW) def
      YELLOW setupcolor  
      /WhichColour 1 def } if 
   seppages 4 eq { 
      /ColourName (BLACK) def 
      BLACK setupcolor   
      /WhichColour 0 def } if 
%
% crop marks
%
gsave .3 setlinewidth 
3 -7 moveto
/Helvetica findfont 6 scalefont setfont
ColourName show
0 0 CM 
vsize cX 2 mul sub dup hsize cX 2 mul sub dup isls{4 2 roll}if 0 CM 
exch CM 0 
exch CM 
grestore 0 cX -2 mul TR isls
{cX -2 mul 0 TR}if
	  } def end
% 
/separations 48 dict def
separations begin
   /cmykprocs [ %def
       % cyan
    { pop pop  pop SetGray  }
       % magenta
    { pop pop exch pop SetGray  }
       % yellow
    { pop 3 1 roll pop pop SetGray  }
       % black
    { 4 1 roll pop pop pop SetGray  }
   ] def
   /rgbprocs [ %def
       % cyan
    { ToCMYK pop pop pop SetGray }
       % magenta
    { ToCMYK pop pop exch pop SetGray }
       % yellow
    { ToCMYK pop 3 1 roll pop pop SetGray }
       % black
    { ToCMYK 4 1 roll pop pop pop SetGray  }
   ] def
   /testprocs [ %def
       % cyan
    { ToCMYK pop pop pop  }
       % magenta
    { ToCMYK pop pop exch pop  }
       % yellow
    { ToCMYK pop 3 1 roll pop pop  }
       % black
    { ToCMYK 4 1 roll pop pop pop   }
   ] def
   /screenangles [ %def
       105  % cyan
       75    % magenta
       0      % yellow
       45    % black
   ] def
end  % separations

% setupcolortakes 0, 1, 2, or 3 as its argument,
% for cyan, magenta, yellow, and black.
/CYAN 0 def           /MAGENTA 1 def
/YELLOW 2 def         /BLACK 3 def
/setupcolor{ %def
   userdict begin
       dup separations /cmykprocs get exch get
       /setcmykcolor exch def
       dup separations /rgbprocs get exch get
       /setrgbcolor exch def
       dup separations /testprocs get exch get
       /testrgbcolor exch def
       separations /screenangles get exch get
       currentscreen
           exch pop 3 -1 roll exch
       setscreen
       /setscreen { pop pop pop } def
%
% redefine setgray so that it only shows on the black separation
%
      /setgray {
       WhichColour 0 eq
       {systemdict begin adjustdot setgray end} 
       {pop systemdict begin 1 setgray end}
       ifelse}def 
   end
} bind def

%
% from Kunkel
%
/adjustdot { dup 0 eq { } { dup 1 exch sub .1 mul add} ifelse } def
%
% redefine existing operators
%
% Percent of undercolor removal
/magentaUCR .3 def  
/yellowUCR .07 def  
/blackUCR .4 def 
%
% Correct yellow and magenta
/correctMY {rgb2cym
  1 index yellowUCR mul sub 3 1 roll
  1 index magentaUCR mul sub 3 1 roll
  3 1 roll rgb2cym}def
% 
%(bluely green ) =
%CYAN setupcolor
%.1 .4 .5  testrgbcolor =
%MAGENTA setupcolor
%.1 .4 .5  testrgbcolor =
%YELLOW setupcolor
%.1 .4 .5  testrgbcolor =
%BLACK setupcolor
%.1 .4 .5  testrgbcolor =
%quit
