package builtin 0.019;

use v5.40;

# All code, including &import, is implemented by always-present
# functions in the perl interpreter itself.
# See also `builtin.c` in perl source

__END__

