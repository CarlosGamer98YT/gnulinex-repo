# -*- encoding: UTF-8 -*-
r"""
# Mandarin Chinese number names (simplified)
^0 零
1 一
2 二
3 三
4 四
5 五
6 六
7 七
8 八
9 九
^1(\d) 十$1
(\d)(\d) $1|十$2
(\d)0{2} $1百
(\d)0(\d) $1百零$2
(\d)(\d\d) $1百$2
(\d)0{3} $1千
(\d)0(\d\d) $1千零$2
(\d)(\d\d\d) $1千$2
(\d{1,4})0{4} $1|万
(\d{1,4})0(\d{3}) $1|万零$2
(\d{1,4})(\d{4}) $1|万$2
(\d{1,4})0{8} $1|亿
(\d{1,4})0(\d{7}) $1|亿零$2
(\d{1,4})(\d{8}) $1|亿$2
(\d{1,4})0{12} $1|兆
(\d{1,4})0(\d{11}) $1|兆零$2
(\d{1,4})(\d{12}) $1|兆$2
(\d{1,4})0{16} $1|京
(\d{1,4})0(\d{15}) $1|京零$2
(\d{1,4})(\d{16}) $1|京$2
(\d{1,4})0{20} $1|垓
(\d{1,4})0(\d{19}) $1|垓零$2
(\d{1,4})(\d{20}) $1|垓$2
(\d{1,4})0{24} $1|秭
(\d{1,4})0(\d{23}) $1|秭零$2
(\d{1,4})(\d{24}) $1|秭$2
(\d{1,4})0{28} $1|穰
(\d{1,4})0(\d{27}) $1|穰零$2
(\d{1,4})(\d{28}) $1|穰$2
(\d{1,4})0{32} $1|沟
(\d{1,4})0(\d{31}) $1|沟零$2
(\d{1,4})(\d{32}) $1|沟$2
(\d{1,4})0{36} $1|涧
(\d{1,4})0(\d{35}) $1|涧零$2
(\d{1,4})(\d{36}) $1|涧$2
(\d{1,4})0{40} $1|正
(\d{1,4})0(\d{39}) $1|正零$2
(\d{1,4})(\d{40}) $1|正$2
(\d{1,4})0{44} $1|载
(\d{1,4})0(\d{43}) $1|载零$2
(\d{1,4})(\d{44}) $1|载$2

# negative numbers

[-−](\d+) 负|$1

# decimals

"([-−]?\d+)[.,]" "$1|点"
"([-−]?\d+[.,]\d*)(\d)" $1||$2

# currency

# unit/subunit singular/plural

AUD 澳元
CHF 瑞士法郎
CNY 人民币
EUR 欧元
GBP 英镑
HKD 港币
JPY 日圆
MOP 澳门元
USD 美元

# 1/10 角
# 1/100 分

"([A-Z]{3}) ([-−]?\d+([.,]\d+)?)" $2$1

# Mandarin Chinese number names, formal numbers (大写) for legal and financial documents, simplified

== formal ==

^0 零
1 壹
2$ 贰
2 贰
3 叁
4 肆
5 伍
6 陆
7 柒
8 捌
9 玖
^1(\d) 拾$(formal \1)
(\d)(\d) $(formal \1)|拾$(formal \2)
(\d)0{2} $(formal \1)佰
(\d)0(\d) $(formal \1)佰零$(formal \2)
(\d)(\d\d) $(formal \1)佰$(formal \2)
(\d)0{3} $(formal \1)仟
(\d)0(\d\d) $(formal \1)仟零$(formal \2)
(\d)(\d\d\d) $(formal \1)仟$(formal \2)
(\d{1,4})0{4} $(formal \1)|万
(\d{1,4})0(\d{3}) $(formal \1)|万零$(formal \2)
(\d{1,4})(\d{4}) $(formal \1)|万$(formal \2)
(\d{1,4})0{8} $(formal \1)|亿
(\d{1,4})0(\d{7}) $(formal \1)|亿零$(formal \2)
(\d{1,4})(\d{8}) $(formal \1)|亿$(formal \2)
(\d{1,4})0{12} $(formal \1)|兆
(\d{1,4})0(\d{11}) $(formal \1)|兆零$(formal \2)
(\d{1,4})(\d{12}) $(formal \1)|兆$(formal \2)
(\d{1,4})0{16} $(formal \1)|京
(\d{1,4})0(\d{15}) $(formal \1)|京零$(formal \2)
(\d{1,4})(\d{16}) $(formal \1)|京$(formal \2)
(\d{1,4})0{20} $(formal \1)|垓
(\d{1,4})0(\d{19}) $(formal \1)|垓零$(formal \2)
(\d{1,4})(\d{20}) $(formal \1)|垓$(formal \2)
(\d{1,4})0{24} $(formal \1)|秭
(\d{1,4})0(\d{23}) $(formal \1)|秭零$(formal \2)
(\d{1,4})(\d{24}) $(formal \1)|秭$(formal \2)
(\d{1,4})0{28} $(formal \1)|穰
(\d{1,4})0(\d{27}) $(formal \1)|穰零$(formal \2)
(\d{1,4})(\d{28}) $(formal \1)|穰$(formal \2)
(\d{1,4})0{32} $(formal \1)|沟
(\d{1,4})0(\d{31}) $(formal \1)|沟零$(formal \2)
(\d{1,4})(\d{32}) $(formal \1)|沟$(formal \2)
(\d{1,4})0{36} $(formal \1)|涧
(\d{1,4})0(\d{35}) $(formal \1)|涧零$(formal \2)
(\d{1,4})(\d{36}) $(formal \1)|涧$(formal \2)
(\d{1,4})0{40} $(formal \1)|正
(\d{1,4})0(\d{39}) $(formal \1)|正零$(formal \2)
(\d{1,4})(\d{40}) $(formal \1)|正$(formal \2)
(\d{1,4})0{44} $(formal \1)|载
(\d{1,4})0(\d{43}) $(formal \1)|载零$(formal \2)
(\d{1,4})(\d{44}) $(formal \1)|载$(formal \2)

# negative numbers

[-−](\d+) 负|$(formal \1)

# decimals

"([-−]?\d+)[.,]" "$(formal \1)|点"
"([-−]?\d+[.,]\d*)(\d)" $(formal \1)||$(formal \2)

# currency

# unit/subunit singular/plural

AUD 澳元
CHF 瑞士法郎
CNY 人民币
EUR 欧元
GBP 英镑
HKD 港币
JPY 日圆
MOP 澳门元
USD 美元

# 1/10 角
# 1/100 分

"([A-Z]{3}) ([-−]?\d+([.,]\d+)?)" $(formal \2)$(formal \1)

== ordinal ==

([-−]?\d+) 第$1

== ordinal-number ==

(.*)    \1.

== help ==

"" |$(1)|, |$(2)|, |$(3)|\n$(help formal)$(\0 ordinal)$(\0 ordinal-number)
(formal|ordinal(-number)?) \1: |$(\1 1)|, |$(\1 2)|, |$(\1 3)|\n
"""
from __future__ import unicode_literals
