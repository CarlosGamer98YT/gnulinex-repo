# -*- encoding: UTF-8 -*-
r"""
^0$ nul
1$ een
1 eenen
2$ twee
2 tweeën
3$ drie
3 drieën
4$ vier
4 vieren
5$ vijf
5 vijfen
6$ zes
6 zesen
7$ zeven
7 zevenen
8$ acht
8 achten
9$ negen
9 negenen

10 tien
11 elf
12 twaalf
13 dertien
14 veertien
1(\d) $1|tien

2(\d) $1twintig
3(\d) $1dertig
4(\d) $1veertig
8(\d) $1tachtig
(\d)(\d) $2$1|tig

1(\d\d) honderd$1
(\d)(\d\d) $1|honderd$2
10(\d{2}) duizend[ $1]
(\d)0(\d{2}) $1|duizend[ $2]
(1\d)(\d{2}) $1|honderd$2
(\d\d)(\d{2}) $1|honderd$2
(\d{2,3})(\d{3}) $1|duizend[ $2]

(\d{1,3})(\d{6}) $1| miljoen[ $2]
(\d{1,3})(\d{9}) $1| miljard[ $2]
(\d{1,3})(\d{12}) $1| biljoen[ $2]
(\d{1,3})(\d{15}) $1| biljard[ $2]
(\d{1,3})(\d{18}) $1| triljoen[ $2]
(\d{1,3})(\d{21}) $1| triljard[ $2]

# negative number

[-−](\d+) min |$1

# decimals

([-−]?\d+)[.,] $1| komma
([-−]?\d+[.,]\d*)(\d) $1| |$2

# currencies

# unit/subunit

u:([^,]*),([^,]*),([^,]*)	\1
s:([^,]*),([^,]*),([^,]*)	\2
p:([^,]*),([^,]*),([^,]*)	\3

CHF:(.)	$(\1: Zwitserse franc, centime, centimes)
CNY:(.)	$(\1: renminbi yuan, fen, fen)
EUR:(.)	$(\1: euro, cent, cent)
GBP:(.)	$(\1: pond sterling, penny, pence)
JPY:(.)	$(\1: yen, sen, sen)
USD:(.)	$(\1: Amerikaanse dollar, cent, cent)

"(JPY [-−]?\d+)[.,](\d\d)0" $1
"(JPY [-−]?\d+[.,]\d\d)(\d)" $1 $2| rin

"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2|$(\1:u)

"(CNY [-−]?\d+)[.,](\d)0?" $1 $2| jiao
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2| fen

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 een$(\2:s)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 $(\30)|$(\2:p)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 $3|$(\2:p)

== ordinal ==

([-−]?([24-79]|\d*1\d|\d+0[24-79]))	$1|de
([-−]?\d+)	$(ordinal |$1)

(.*)een		\1eerste
(.*)drie	\1derde
(.*)		\1ste

== ordinal-number ==

([-−]?([2-79]|\d*1\d|\d+0[2-79]))	\1de
([-−]?\d+)	\1ste

== help ==

"" $(1)|, $(2)|, $(3)|\n$(\0 ordinal)$(\0 ordinal-number)currency \(for example, EUR\): $(EUR 2.5)
"(ordinal(-number)?)" \1: $(\1 1), $(\1 2), $(\1 3)\n

"""
from __future__ import unicode_literals
