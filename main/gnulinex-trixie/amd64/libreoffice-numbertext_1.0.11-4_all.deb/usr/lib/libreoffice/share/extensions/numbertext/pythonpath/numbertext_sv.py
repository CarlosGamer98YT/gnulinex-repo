# -*- encoding: UTF-8 -*-
r"""
^0 noll
^1$ ett
^1 en
1 ett
2 två
3 tre
4 fyra
5 fem
6 sex
7 sju
8 åtta
9 nio
10 tio
11 elva
12 tolv
13 tretton
14 fjorton
15 femton
16 sexton
17 sjutton
18 arton
19 nitton
2(\d) tjugo$1
3(\d) trettio$1
4(\d) fyrtio$1
7(\d) sjuttio$1
8(\d) åttio$1
9(\d) nittio$1
(\d)(\d) $1tio$2
(\d)(\d\d) $1|hundra$2

# “ettusen” instead of “etttusen”

(1|\d?[02-9]1)(\d{3}) $1|usen[ $2]

(\d{1,3})(\d{3}) $1tusen[ $2]
(\d{1,3})(\d{6}) |$1 miljon$(pl:\1)[ $2]
(\d{1,3})(\d{9}) |$1 miljard$(pl:\1)[ $2]
(\d{1,3})(\d{12}) |$1 biljon$(pl:\1)[ $2]
(\d{1,3})(\d{15}) |$1 biljard$(pl:\1)[ $2]
(\d{1,3})(\d{18}) |$1 triljon$(pl:\1)[ $2]
(\d{1,3})(\d{21}) |$1 triljard$(pl:\1)[ $2]
(\d{1,3})(\d{24}) |$1 kvadriljon$(pl:\1)[ $2]

# plural for big numbers
pl:1
pl:.* er

# negative number

[-−](\d+) minus |$1

# decimals

"([-−]?\d+)[.,]" $1| komma
"([-−]?\d+[.,])([^0]\d)" $1| |$2
"([-−]?\d+[.,])(\d)(\d)(\d)" $1| |$2 |$3 |$4
"([-−]?\d+[.,]\d*)(\d)" $1| |$2

# currency

# unit/subunit singular/plural
"us, (.*): (.*), (.*), (.*), (.*), (.*), (.*)" $(\2 \1) \3
"up, (.*): (.*), (.*), (.*), (.*), (.*), (.*)" $(\2 \1) \4
"ss, (.*): (.*), (.*), (.*), (.*), (.*), (.*)" $(\5 \1) \6
"sp, (.*): (.*), (.*), (.*), (.*), (.*), (.*)" $(\5 \1) \7

CHF:(\D+,.*) $(\1: cardinal, schweizisk franc, schweizisk franc, cardinal, centime, centime)
CNY:(\D+,.*) $(\1: cardinal, yuan renminbi, yuan renminbi, cardinal, fen, fen)
EUR:(\D+,.*) $(\1: cardinal, euro, euro, cardinal-neuter, cent, cent)
GBP:(\D+,.*) $(\1: cardinal-neuter, brittiskt pund, brittiskt pund, cardinal, penny, pence)
JPY:(\D+,.*) $(\1: cardinal, yen, yen, cardinal, sen, sen)
SEK:(\D+,.*) $(\1: cardinal, svensk krona, svenska kronor, cardinal-neuter, öre, öre)
USD:(\D+,.*) $(\1: cardinal, US-dollar, US-dollar, cardinal-neuter, cent, cent)

"([A-Z]{3}) ([-−]?1)([.,]00?)?"$(\1:us, \2)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?"$(\1:up, \2)

"(CNY [-−]?\d+)[.,]10?" $1 $2 jiao
"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 jiao
"(CNY [-−]?\d+[.,]\d)1" $1 $2 fen
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 fen

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 $(\2:ss, 1)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 $(\2:sp, \30)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 $(\2:sp, \3)

== cardinal-neuter ==

1 ett

== cardinal(-feminine|-masculine|-neuter)? ==

([-−]?\d+) $(cardinal |$2)
"(.*[^ ]e)t(tusen.*)" $(cardinal \2n\3)	# 21000, 31000 .. 991000
"(.*e)tt([ ].*|$)" $(cardinal \2n\3)	# !etthundra, !ettusen
(.*) \2

== ordinal(-masculine)? ==

([-−]?\d+) $(ordinal |$2)

== ordinal ==

(.*)ett		\1förste	# 1
(.*)två		\1andre		# 2
(.*)tre		\1tredje	# 3
(.*)fyra	\1fjärde	# 4
(.*)sex		\1sjätte	# 6
(.*(sju|io))	\1nde		# 7, 9, 10, 20..90
(.*)åtta	\1åttonde	# 8
(.*)elva	\1elfte		# 11
(.*)tolv	\1tolfte	# 12
"(.*(ton|hundra|tusen)) *" \1de	# 13, 14..19, 100, 1000
"(.*)er *"	\1te		# milljoner...
"(.*[^ ]) *"	\1te		# 0, 5, milljon...

== ordinal-feminine ==

([-−]?\d+) $(ordinal-feminine $(ordinal |$1))
(.*(först|andr))e \1a	# 1, 2
(.*)	\1

== ordinal-neuter ==

(.*)	$(ordinal-feminine |$1)

== ordinal-number(-feminine|-neuter)? ==

(.*[02-9][12]|[12])	\2:a

== ordinal-number(-feminine|-neuter|-masculine)? ==

(.*)	\2:e

== year ==

([-−]?(1[1-9]|[2-9]\d))(\d\d) $1hundra$3
(.*) $1

== help ==

"" $(1)|, $(2), $(3)\n$(\0 cardinal-feminine)$(\0 cardinal-masculine)$(\0 cardinal-neuter)$(\0 ordinal-feminine)$(\0 ordinal-masculine)$(\0 ordinal-neuter)$(\0 ordinal-number)$(\0 ordinal-number-feminine)$(\0 ordinal-number-masculine)
((ordinal|cardinal)(-number)?(-feminine|-masculine|-neuter)?) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
