# -*- encoding: UTF-8 -*-
r"""
# mr.sor for - MARATHI मराठी Indian Language (mr-IN)
# In many Indian languages including MARATHI, rules of number reading (from 0 up to number 100) are complex and inconsistent.
# e.g often a number is read first with units place & then ten's place. - e.g 34 read as " चौतीस " where " चौ " stands for 4 (units place) and then तीस  for 30 (ten's place) which is inverse with the number reading logic in ENGLISH (where it is read as Thirty Four)
# Pronunciations of numbers changes and follows virtually no logic - e.g. 54 read as " चौपन्न " where ten's place 50 is read as पन्न but only No. 50 would be read as पन्नास !
# when units place number is 9, the number is read with the reference to the NEXT number e.g. 39 is read as एकोणचाळीस  where " एकोण " stands for 9 (units place) and then चाळीस with reference to 40 (the NEXT number) which is inverse with the number reading logic in ENGLISH (where it is read as Thirty Nine - reference of previous ten's place)
# Reading of same units place but different ten's place is vastly different - e.g. 27 सत्तावीस , 47 सत्तेचाळीस , 67 सदुसष्ट , 77 सत्त्याहत्तर . Here same units place 7 has been read differently as  सत्ता , सत्ते , सदु , सत्त्या ... very difficult to frame any logic !
# Therefore we have hard coded numbers from 0 to 100 with Marathi translations.
# Number reading after Hundred's place is very similar to English logic ... hence no problem in coding for further Marathi numbers
# --------------------------------------
# Number List in English , word in MARATHI
# - Ankur Joshi , pharmankur@gmail.com
#

^0 शून्य
1	एक
2	दोन
3	तीन
4	चार
5	पाच
6	सहा
7	सात
8	आठ
9	नऊ
10	दहा
11	अकरा
12	बारा
13	तेरा
14	चौदा
15	पंधरा
16	सोळा
17	सतरा
18	अठरा
19	एकोणीस
20	वीस
21	एकवीस
22	बावीस
23	तेवीस
24	चोवीस
25	पंचवीस
26	सव्वीस
27	सत्तावीस
28	अठ्ठावीस
29	एकोणतीस
30	तीस
31	एकतीस
32	बत्तीस
33	तेहतीस
34	चौतीस
35	पस्तीस
36	छत्तीस
37	सदतीस
38	अडतीस
39	एकोणचाळीस
40	चाळीस
41	एक्केचाळीस
42	बेचाळीस
43	त्रेचाळीस
44	चव्वेचाळीस
45	पंचेचाळीस
46	सेहेचाळीस
47	सत्तेचाळीस
48	अठ्ठेचाळीस
49	एकोणपन्नास
50	पन्नास
51	एकावन्न
52	बावन्न
53	त्रेपन्न
54	चौपन्न
55	पंचावन्न
56	छप्पन्न
57	सत्तावन्न
58	अठ्ठावन्न
59	एकोणसाठ
60	साठ
61	एकसष्ट
62	बासष्ट
63	त्रेसष्ट
64	चौसष्ट
65	पासष्ट
66	सहासष्ट
67	सदुसष्ट
68	अडुसष्ट
69	एकोणसत्तर
70	सत्तर
71	एकाहत्तर
72	बाहत्तर
73	त्र्याहत्तर
74	चौऱ्याहत्तर
75	पंचाहत्तर
76	शाहत्तर
77	सत्त्याहत्तर
78	अठ्ठ्याहत्तर
79	एकोणऐंशी
80	ऐंशी
81	एक्याऐंशी
82	ब्याऐंशी
83	त्र्याऐंशी
84	चौऱ्याऐंशी
85	पंचाऐंशी
86	शहाऐंशी
87	सत्त्याऐंशी
88	अठ्ठ्याऐंशी
89	एकोणनव्वद
90	नव्वद
91	एक्याण्णव
92	ब्याण्णव
93	त्र्याण्णव
94	चौऱ्याण्णव
95	पंचाण्णव
96	शहाण्णव
97	सत्त्याण्णव
98	अठ्ठ्याण्णव
99	नव्याण्णव
100	शंभर

# ------------------------

# separator function
:0+			# एक हजार
:0*\d?\d " आणि "	# एक हजार आणि पाच
:\d+ ", "		# एक कोटी, एक लाख, एक हजार दोनशेएक्केचाळीस

# ------------------------

(\d)(\d\d) $1शे[ $2]		# default: एकशे एक  Note - The intentional space before $ in [ $2] . This is done to eliminate Zero error after 100
(\d{1,2})(\d\d\d) $1 हजार[ $2]	# दहा हजार दोनशे
(\d{1,2})(\d{5}) $1 लाख$(:\2)$2    # 5 zero after number thus its a LAKH [ 5th power of 10 is LAKH thus expression (\d{5}) , after this next is CRORE which is 7th power i.e. diff of 2 powers thus expression (\d{1,2}) . Foww this henceforth if in future needs to adjust Name of decimal places ]
(\d{1,2})(\d{7}) $1 कोटी$(:\2)$2  # 7 zero after number thus its a CRORE
(\d{1,1})(\d{9}) $1 अब्ज$(:\2)$2  # 9 zero after number thus its a ABJA (equivalant to a BILLION)
(\d{1,1})(\d{10}) $1 खर्व$(:\2)$2 # 10 zero after number thus its a KHARVA
(\d{1,1})(\d{11}) $1 निखर्व$(:\2)$2 # 11 zero after number thus its a  NIKHARVA
(\d{1,1})(\d{12}) $1 महापद्म$(:\2)$2 # 12 zero after number thus its a  MAHAPADMA (equivalant to a TRILLION)
(\d{1,1})(\d{13}) $1 शंकू$(:\2)$2 # 1३ zero after number thus its a  SHANKU
(\d{1,1})(\d{14}) $1 जलधि$(:\2)$2 # 14 zero after number thus its a JALADHI
(\d{1,1})(\d{15}) $1 अन्त्य$(:\2)$2 # 15 zero after number thus its a ANTYA (equivalant to a QUADRILLION)
(\d{1,1})(\d{16}) $1 मध्य$(:\2)$2 # 16 zero after number thus its a MADHYA
(\d{1,50})(\d{17}) $1 परार्ध$(:\2)$2 # 17 zero after number thus its a PARARDH. Practically unlimited numbers are sumed um in Parardh.

### Above nameing for decimal places is with reference to work by BHASKARACHARYA (1150 AD) from book LILAVATI , SHLOKA (Verse) no 11 & 12 which is -->
### एक दशशत सहस्त्र अयुत लक्ष प्रयुत कोट्य: क्रमश: |
### अर्बुदम् अब्जम् खर्व निखर्व महापद्म शंकव: तस्मात्: || 11 ||
### जलधिंच अन्त्यम् मध्यम् परार्धम् इति दशगुणोत्तरम् संज्ञा: |
### संख्याया: स्थानानां व्यवहारार्थम् कृता: पूर्वै: || 12 ||
###
### Verse is translated as -->
### Positions of the digits from right to left are unit, ten, hundred, thousand, ten thousand, hundred thousand (lakh), million, ten million (Crore), hundred million, billion (abja), Kharva, Nikharva, Mahapadma, Sanku, Jaladhi, Antya, Madhya, Parardha. The value of each digit on the left is ten times that on the right.
### Although for practical purpose this verse goes up to parardha (17th power of 10), there are terms for numbers up to 140th power of 10 in Sanskrit.
### In todays practice wordings अयुत and प्रयुत are not used and if used are replaced by दशसहस्त्र and दशलक्ष / दशलाख respectively (Not used here)
###

# ------------------------

# negative number

[-−](\d+) उणे |$1

# ------------------------

# decimals

0[.,] शून्य दशांश
([-−]?\d+)[.,] $1| दशांश

"([-−]?\d+[.,])([^0]\d)" $1| |$2   # e.g. एकशे वीस दशांश नऊ
"([-−]?\d+[.,])(0)(0)(\d)" $1| |$2 |$3 |$4  # e.g. सदुसष्ठ दशांश शून्य शून्य नऊ
"([-−]?\d+[.,])(0)(\d\d)" $1| |$2 |$3 # e.g. एकोणनव्वद दशांश शून्य एकोणनव्वद
"([-−]?\d+[.,])(\d\d\d)" $1| |$2 # e.g. तेवीस दशांश पाचशे सदुसष्ठ , upto 3 places after decimal, decimals read in hundreds
"([-−]?\d+[.,])(\d)(\d)(\d)(\d)" $1| |$2 |$3 |$4 |$5 # e.g. चव्वेचाळीस दशांश पाच सात दोन पाच
"([-−]?\d+[.,]\d*)(\d)" $1| |$2

# ------------------------
# currency
# unit/subunit singular/plural

us:([^,]*),([^,]*),([^,]*),([^,]*) \1
up:([^,]*),([^,]*),([^,]*),([^,]*) \2
ss:([^,]*),([^,]*),([^,]*),([^,]*) \3
sp:([^,]*),([^,]*),([^,]*),([^,]*) \4

AED:(\D+) $(\1: अमीराती दिऱ्हाम, अमीराती दिऱ्हाम, फिल्स्, फिल्स्)
AUD:(\D+) $(\1: ऑस्ट्रेलिअन डॉलर, ऑस्ट्रेलिअन डॉलर्स, सेंट, सेंटस्)
BGN:(\D+) $(\1: lev, leva, stotinka, stotinki)
BWP:(\D+) $(\1: pula, pula, thebe, thebe)
CAD:(\D+) $(\1: कॅनेडीअन डॉलर, कॅनेडीअन डॉलर्स, सेंट, सेंटस्)
CHF:(\D+) $(\1: स्विस् फ्रॅंक, स्विस् फ्रॅंकस्, सेंटीम, सेंटीमस्)
CNY:(\D+) $(\1: चायनीज युआन, चायनीज युआन, फेन, फेन)
CZK:(\D+) $(\1: Czech koruna, Czech koruny, halér, halére)
EEK:(\D+) $(\1: kroon, kroonid,	sent, senti)
EUR:(\D+) $(\1: युरो, युरो, सेंट, सेंटस्)
GBP:(\D+) $(\1: पौंड स्टर्लिंग, पौंडस् स्टर्लिंग, पेनी, पेन्स्)
GHS:(\D+) $(\1: Ghana cedi, Ghana cedis, pesewa, pesewas)
GMD:(\D+) $(\1: dalasi, dalasi, butut, bututs)
HKD:(\D+) $(\1: हॉन्गकॉन्ग डॉलर, हॉन्गकॉन्ग डॉलर्स, सेंट, सेंटस्)
HRK:(\D+) $(\1: kuna, kuna, lipa, lipa)
HUF:(\D+) $(\1: forint, forint, fillér, fillér)

# --- Using Indian Rupee Symbol " ₹ " ------
INR:(\D+) $(\1: ₹ रुपया, ₹ रुपये, पैसा, पैसे)
# ------------------------------------------

JMD:(\D+) $(\1: Jamaica dollar, Jamaica dollars, cent, cents)
JPY:(\D+) $(\1: जपानी येन, जपानी येन, सेन, सेन)
KES:(\D+) $(\1: Kenyan shilling, Kenyan shillings, cent, cents)
KRW:(\D+) $(\1: Korean won, Korean won, jeon, jeon)
KWD:(\D+) $(\1: कुवेती दिनार, कुवेती दिनार, फिल्स्, फिल्स्)
LRD:(\D+) $(\1: Liberian dollar, Liberian dollars, cent, cents)
LSL:(\D+) $(\1: loti, maloti, sente, lisente)
LTL:(\D+) $(\1: litas, litai, centas, centai)
LVL:(\D+) $(\1: lats, lati, santims, santimi)
MGA:(\D+) $(\1: ariary, ariaries, iraimbilanja, iraimbilanja)
MUR:(\D+) $(\1: Mauritian rupee, Mauritian rupees, cent, cents)
MXN:(\D+) $(\1: Mexican peso, Mexican pesos, centavo, centavos)
MWK:(\D+) $(\1: Malawian kwacha, Malawian kwacha, tambala, tambala)
MYR:(\D+) $(\1: Ringgit, Ringgit, cent, cents)
NAD:(\D+) $(\1: Namibian dollar, Namibian dollars, cent, cents)
NGN:(\D+) $(\1: naira, naira, kobo, kobo)
NZD:(\D+) $(\1: न्यूझीलंड डॉलर, न्यूझीलंड डॉलर्स, सेंट, सेंटस्)
PGK:(\D+) $(\1: kina, kina, toea, toea)
PHP:(\D+) $(\1: Philippine peso, Philippine pesos, centavo, centavos)
PKR:(\D+) $(\1: पाकिस्तानी रुपया, पाकिस्तानी रुपये, पैसा, पैसे)
PLN:(\D+) $(\1: zloty, zlotys, grosz, groszy)
RON:(\D+) $(\1: Romanian leu, Romanian lei, ban, bani)
RSD:(\D+) $(\1: Serbian dinar, Serbian dinars, para, para)
RUB:(\D+) $(\1: Russian ruble, Russian rubles, kopek, kopeks)
RWF:(\D+) $(\1: Rwandese franc, Rwandese francs, centime, centimes)
SAR:(\D+) $(\1: सौदी रियाल, सौदी रियाल, हलाला, हलाला)
SDG:(\D+) $(\1: Sudanese pound, Sudanese pounds, piastre, piastres)
SGD:(\D+) $(\1: सिंगापुर डॉलर, सिंगापुर डॉलर्स, सेंट, सेंटस्)
SLL:(\D+) $(\1: leone, leones, cent, cents)
SZL:(\D+) $(\1: lilangeni, emalangeni, cent, cents)
THB:(\D+) $(\1: baht, baht, satang, satang)
TRY:(\D+) $(\1: Turkish lira, Turkish lira, kurus, kurus)
TTD:(\D+) $(\1: Trinidad and Tobago dollar, Trinidad and Tobago dollars, cent, cents)
TZS:(\D+) $(\1: Tanzanian shilling, Tanzanian shillings, cent, cents)
UAH:(\D+) $(\1: hryvnia, hryvnia, kopiyka, kopiyka)
UGX:(\D+) $(\1: Uganda shilling, Uganda shillings, cent, cents)
USD:(\D+) $(\1: यु. एस. डॉलर, यु. एस. डॉलर्स, सेंट, सेंटस् )
X[AO]F:(\D+) $(\1: CFA franc, CFA francs, centime, centimes)
ZAR:(\D+) $(\1: South African rand, South African rand, cent, cents)
ZMK:(\D+) $(\1: Zambian kwacha, Zambian kwacha, ngwee, ngwee)
ZWL:(\D+) $(\1: Zimbabwe dollar, Zimbabwe dollars, cent, cents)

"(JPY [-−]?\d+)[.,](\d\d)0" $1
"(JPY [-−]?\d+[.,]\d\d)(\d)" $1 $2 रिन

"([A-Z]{3}) ([-−]?1)([.,]00?)?" $2$(\1:us)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2$(\1:up)

"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 ज्याओ
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 फेन

"((MGA|MRO) [-−]?\d+)[.,]0" $1
"((MGA|MRO) [-−]?\d+)[.,]2" $1 आणि |$(1)$(\2:ss)
"((MGA|MRO) [-−]?\d+)[.,]4" $1 आणि |$(2)$(\2:sp)
"((MGA|MRO) [-−]?\d+)[.,]6" $1 आणि |$(3)$(\2:sp)
"((MGA|MRO) [-−]?\d+)[.,]8" $1 आणि |$(4)$(\2:sp)

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 आणि |$(1)$(\2:ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 आणि |$(\30)$(\2:sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 आणि |$3$(\2:sp)

== money ==

"(JPY [-−]?\d+)[.,](\d\d)0" $1
"(JPY [-−]?\d+[.,]\d\d)(\d)" $1 $2 रिन

"([A-Z]{3}) ([-−]?1)([.,]00?)?" $2$(\1:us)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2$(\1:up)

"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 ज्याओ
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 फेन

"(MGA|MRO) ([-−]?\d+)[.,]0" $2$(\1:us)
"(MGA|MRO) ([-−]?\d+)[.,]2" $2 आणि 1/5$(\1:us)
"(MGA|MRO) ([-−]?\d+)[.,]4" $2 आणि 2/5$(\1:up)
"(MGA|MRO) ([-−]?\d+)[.,]6" $2 आणि 3/5$(\1:up)
"(MGA|MRO) ([-−]?\d+)[.,]8" $2 आणि 4/5$(\1:up)

"([A-Z]{3}) ([-−]?1)" $2$(\1:us)
"([A-Z]{3}) ([-−]?\d+)" $2$(\1:up)
"(([A-Z]{3}) ([-−]?\d+))[.,](01)" $3 आणि 1/100$(\2:us)
"(([A-Z]{3}) ([-−]?\d+))[.,](\d)" $3 आणि \40/100$(\2:up)
"(([A-Z]{3}) ([-−]?\d+))[.,](\d\d)" $3 आणि \4/100$(\2:up)
"(([A-Z]{3}) ([-−]?\d+))[.,](\d\d\d)" $3 आणि \4/1000$(\2:up)

# ------------------------
# Ordinal ------
# Ordinal no. reading in Marathi are GENDER dependent ( and not as simple in English where anyone at no 1 will be read as FIRST )
# in Marathi there are 3 gender identities Male पुल्लिंगी , Female स्त्रिलिंगी & Neutral नपुसकलिंगी (similar to masculine, feminine, neuter in Swiss )
# -----------------------
# If a sentence refer to MALE subject equivalent of FIRST is पहिला
# ordinal masculine ---  पुल्लिंगी

== ordinal-masculine ==
([-−]?\d+) $(ordinal-masculine |$1)
(.*)एक \1पहिला
(.*)दोन \1दुसरा
(.*)तीन \1तिसरा
(.*)चार \1चौथा
(.*)पाच \1पाचवा
(.*)सहा \1सहावा
(.*)सात \1सातवा
(.*)आठ \1आठवा
(.*)नऊ \1नववा
(.*)दहा \1दहावा
(.*)अकरा \1अकरावा
(.*)बारा \1बारावा
(.*)तेरा \1तेरावा
(.*)चौदा \1चौदावा
(.*)पंधरा \1पंधरावा
(.*)सोळा \1सोळावा
(.*)सतरा \1सतरावा
(.*)अठरा \1अठरावा


(.*)एकोणऐंशी \1एकोणऐंशीवा
(.*)ऐंशी \1ऐंशीवा
(.*)एक्याऐंशी \1एक्याऐंशीवा
(.*)ब्याऐंशी \1ब्याऐंशीवा
(.*)त्र्याऐंशी \1त्र्याऐंशीवा
(.*)चौऱ्याऐंशी \1चौऱ्याऐंशीवा
(.*)पंचाऐंशी \1पंचाऐंशीवा
(.*)शहाऐंशी \1शहाऐंशीवा
(.*)सत्त्याऐंशी \1सत्त्याऐंशीवा
(.*)अठ्ठ्याऐंशी \1अठ्ठ्याऐंशीवा

([-−]?\d+)[.,](.*) $1 दशांश $(\2)वा  # Ordinal of Decimals
(.*)	\1ावा # General Masculine Ordinal

# -----------------------
# If a sentence refer to FEMALE subject equivalent of FIRST is पहिली
# ordinal feminine ---  स्त्रिलिंगी

== ordinal-feminine ==
([-−]?\d+) $(ordinal-feminine |$1)
(.*)एक \1पहिली
(.*)दोन \1दुसरी
(.*)तीन \1तिसरी
(.*)चार \1चौथी
(.*)पाच \1पाचवी
(.*)सहा \1सहावी
(.*)सात \1सातवी
(.*)आठ \1आठवी
(.*)नऊ \1नववी
(.*)दहा \1दहावी
(.*)अकरा \1अकरावी
(.*)बारा \1बारावी
(.*)तेरा \1तेरावी
(.*)चौदा \1चौदावी
(.*)पंधरा \1पंधरावी
(.*)सोळा \1सोळावी
(.*)सतरा \1सतरावी
(.*)अठरा \1अठरावी


(.*)एकोणऐंशी \1एकोणऐंशीवी
(.*)ऐंशी \1ऐंशीवी
(.*)एक्याऐंशी \1एक्याऐंशीवी
(.*)ब्याऐंशी \1ब्याऐंशीवी
(.*)त्र्याऐंशी \1त्र्याऐंशीवी
(.*)चौऱ्याऐंशी \1चौऱ्याऐंशीवी
(.*)पंचाऐंशी \1पंचाऐंशीवी
(.*)शहाऐंशी \1शहाऐंशीवी
(.*)सत्त्याऐंशी \1सत्त्याऐंशीवी
(.*)अठ्ठ्याऐंशी \1अठ्ठ्याऐंशीवी

([-−]?\d+)[.,](.*) $1 दशांश $(\2)वी  # Ordinal of Decimals
(.*)	\1ावी # General Feminine Ordinal

# -----------------------
# If a sentence refer to NEUTRAL subject equivalent of FIRST is पहिले / पहिलं
# ordinal neutral ---  नपुसकलिंगी

== ordinal-neutral ==
([-−]?\d+) $(ordinal-neutral |$1)
(.*)एक \1पहिले
(.*)दोन \1दुसरे
(.*)तीन \1तिसरे
(.*)चार \1चौथे
(.*)पाच \1पाचवे
(.*)सहा \1सहावे
(.*)सात \1सातवे
(.*)आठ \1आठवे
(.*)नऊ \1नववे
(.*)दहा \1दहावे
(.*)अकरा \1अकरावे
(.*)बारा \1बारावे
(.*)तेरा \1तेरावे
(.*)चौदा \1चौदावे
(.*)पंधरा \1पंधरावे
(.*)सोळा \1सोळावे
(.*)सतरा \1सतरावे
(.*)अठरा \1अठरावे

(.*)एकोणऐंशी \1एकोणऐंशीवे
(.*)ऐंशी \1ऐंशीवे
(.*)एक्याऐंशी \1एक्याऐंशीवे
(.*)ब्याऐंशी \1ब्याऐंशीवे
(.*)त्र्याऐंशी \1त्र्याऐंशीवे
(.*)चौऱ्याऐंशी \1चौऱ्याऐंशीवे
(.*)पंचाऐंशी \1पंचाऐंशीवे
(.*)शहाऐंशी \1शहाऐंशीवे
(.*)सत्त्याऐंशी \1सत्त्याऐंशीवे
(.*)अठ्ठ्याऐंशी \1अठ्ठ्याऐंशीवे

([-−]?\d+)[.,](.*) $1 दशांश $(\2)वे # Ordinal of Decimals
(.*)	\1ावे # General Neutral Ordinal

# -----------------------
# As the SUBJECT in the sentence forming is unknown and  is out of scope of this code, default ordinal numbering is set to output all possible GENDERs separated by " / " , and hence may not deliver grammatically correct sentences ( we have hard coded Ordinal numbers from 1-10 with all possible GENDERs separated by " / " .. as in पहिला / पहिली / पहिले
# This is done deliberately considering ease of use.
# As separate commands for masculine, feminine & neutral eventhough exists, a User may not be aware. So by providing all gender words in default ordinal option, user at least will get some output of relevance.
# ordinal default  --- ordinal words with all gender options separated by " / "

== ordinal ==    # Default
([-−]?\d+) $(ordinal |$1)

(.*)एक \1पहिला / \1 पहिली / \1 पहिले
(.*)दोन	\1दुसरा / \1 दुसरी / \1 दुसरे
(.*)तीन	\1तिसरा / \1 तिसरी / \1 तिसरे
(.*)चार	\1चौथा / \1 चौथी / \1 चौथे
(.*)पाच \1पाचवा / \1 पाचवी / \1 पाचवे
(.*)सहा \1सहावा / \1 सहावी / \1 सहावे
(.*)सात \1सातवा / \1 सातवी / \1 सातवे
(.*)आठ \1आठवा / \1 आठवी / \1 आठवे
(.*)नऊ \1नववा / \1 नववी / \1 नववे
(.*)दहा \1दहावा / \1 दहावी / \1 दहावे
(.*)अकरा \1अकरावा / \1 अकरावी / \1 अकरावे
(.*)बारा \1बारावा / \1 बारावी / \1 बारावे
(.*)तेरा \1तेरावा / \1 तेरावी / \1 तेरावे
(.*)चौदा \1चौदावा / \1 चौदावी / \1 चौदावे
(.*)पंधरा \1पंधरावा / \1 पंधरावी / \1 पंधरावे
(.*)सोळा \1सोळावा / \1 सोळावी / \1 सोळावे
(.*)सतरा \1सतरावा / \1 सतरावी / \1 सतरावे
(.*)अठरा \1अठरावा / \1 अठरावी / \1 अठरावे


(.*)एकोणऐंशी \1एकोणऐंशीवा / \1 एकोणऐंशीवी / \1 एकोणऐंशीवे
(.*)ऐंशी \1ऐंशीवा / \1 ऐंशीवी / \1 ऐंशीवे
(.*)एक्याऐंशी \1एक्याऐंशीवा / \1 एक्याऐंशीवी / \1 एक्याऐंशीवे
(.*)ब्याऐंशी \1ब्याऐंशीवा / \1 ब्याऐंशीवी / \1 ब्याऐंशीवे
(.*)त्र्याऐंशी \1त्र्याऐंशीवा / \1 त्र्याऐंशीवी / \1 त्र्याऐंशीवे
(.*)चौऱ्याऐंशी \1चौऱ्याऐंशीवा / \1 चौऱ्याऐंशीवी / \1 चौऱ्याऐंशीवे
(.*)पंचाऐंशी \1पंचाऐंशीवा / \1 पंचाऐंशीवी / \1 पंचाऐंशीवे
(.*)शहाऐंशी \1शहाऐंशीवा / \1 शहाऐंशीवी / \1 शहाऐंशीवे
(.*)सत्त्याऐंशी \1सत्त्याऐंशीवा / \1 सत्त्याऐंशीवी / \1 सत्त्याऐंशीवे
(.*)अठ्ठ्याऐंशी \1अठ्ठ्याऐंशीवा / \1 अठ्ठ्याऐंशीवी / \1 अठ्ठ्याऐंशीवे


([-−]?\d+)[.,](.*) $1 दशांश $(\2)वा / $1 दशांश $(\2)वी / $1 दशांश $(\2)वे # Ordinal of Decimals
(.*)	\1ावा / \1ावी / \1ावे # General ALL Gender Ordinals

# -----------------------
# Also we have considered to use generalized method where result for "ELEVEN" will be like - क्रमांक अकरा (similar to saying "Rank Eleven" in English in a gender neutral way.)
# ordinal Sequential  --- ordinal-sq

== ordinal-sq ==
([-−]?\d+) $(ordinal-sq |$1)
(.*)	क्रमांक \1

# ------------------------
# ordinal-number
# Not relevant in Marathi

== ordinal-number ==
([-−]?\d+) $(ordinal-number |$2)
(.*) \2

# ------------------------
# cardinal
# Not relevant in Marathi

== cardinal(-)? ==
([-−]?\d+) $(cardinal |$2)
(.*) \2

# ------------------------

== year ==

(1[0-9])00 $1शे
(1[0-9])([0-9][0-9]) $1शे $2  # e.g. 1857 = अठराशे सत्तावन्न , 1947 = एकोणीसशे सत्तेचाळीस
(2[0-9])([0-9][0-9]) $1शे $2 # e.g. 2021 = वीसशे एकवीस
(3[0-9])([0-9][0-9]) $1शे $2
(4[0-9])([0-9][0-9]) $1शे $2
(5[0-9])([0-9][0-9]) $1शे $2
(6[0-9])([0-9][0-9]) $1शे $2
(7[0-9])([0-9][0-9]) $1शे $2
(8[0-9])([0-9][0-9]) $1शे $2
(9[0-9])([0-9][0-9]) $1शे $2
(.*) $(year-remove-and $1)

# ------------------------

== year-remove-and ==

"(.*) and (.*)" \1 \2
(.*) \1

== help ==

"" $(1)|, $(2), $(3)\n$(\0 ordinal)$(\0 ordinal-masculine)$(\0 ordinal-feminine)$(\0 ordinal-neutral)$(\0 ordinal-sq)$(\0 ordinal-number)year: $(year 1999), two thousand, $(year 2001)
"" \ncurrency \(for example, INR\): $(INR 2.5)\nmoney INR: $(money INR 2.5) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
