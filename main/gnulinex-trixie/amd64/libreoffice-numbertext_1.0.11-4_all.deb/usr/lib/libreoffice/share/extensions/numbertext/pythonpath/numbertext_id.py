# -*- encoding: UTF-8 -*-
r"""
^0 nol
1 satu
2 dua
3 tiga
4 empat
5 lima
6 enam
7 tujuh
8 delapan
9 sembilan
10 sepuluh
11 sebelas
1(\d) $1 belas
(\d)(\d) $1 puluh[ $2]
1(\d\d) seratus[ $1]
(\d)(\d\d) $1 ratus[ $2]
1(\d{3}) seribu[ $1]
(\d{1,3})(\d{3}) $1 ribu[ $2]
# sejuta or setu juta etc.
(\d{1,3})(\d{6}) $1 juta[ $2]
(\d{1,3})(\d{9}) $1 miliar[ $2]
(\d{1,3})(\d{12}) $1 triliun[ $2]
(\d{1,3})(\d{15}) $1 kuadriliun[ $2]
(\d{1,3})(\d{18}) $1 kuantiliun[ $2]
(\d{1,3})(\d{21}) $1 sextiliun[ $2]
(\d{1,3})(\d{24}) $1 septiliun[ $2]

# negative numbers

[-−](\d+) minus |$1

# decimals

"([-−]?\d+)[.,]" $1| koma
"([-−]?\d+[.,]\d*)(\d)" $1| |$2

# currency

# unit/subunit

u:(.*),(.*)	\1
s:(.*),(.*)	\2

AUD:(.)	$(\1: dollar Australia, sen)
BGN:(.)	$(\1: lev, leva, stotinka, stotinki)
BWP:(.)	$(\1: pula, pula, thebe, thebe)
CAD:(.)	$(\1: dollar Kanada, sen)
CHF:(.)	$(\1: franc Swiss, sen)
CNY:(.)	$(\1: yuan, fen)
CZK:(.)	$(\1: koruna Czech, koruna Czech, halér, halére)
EEK:(.)	$(\1: kroon, kroonid, sen)
EUR:(.)	$(\1: euro, sen)
GBP:(.)	$(\1: pound sterling, penny)
GHS:(.)	$(\1: cedi Ghana, pesewas)
GMD:(.)	$(\1: dalasi, bututs)
HKD:(.)	$(\1: dollar Hongkong, sen)
IDR:(.)	$(\1: rupiah, sen)
INR:(.)	$(\1: rupee India, paisa)
JMD:(.)	$(\1: dollar Jamaika, sen)
JPY:(.)	$(\1: yen, sen)
KRW:(.)	$(\1: won, chon)
KES:(.)	$(\1: shilling Kenya, sen)
LRD:(.)	$(\1: dollar Liberia, sen)
LSL:(.)	$(\1: loti, sente)
LTL:(.)	$(\1: litas, sen)
LVL:(.)	$(\1: lats, sen)
MGA:(.)	$(\1: ariary, iraimbilanja)
MUR:(.)	$(\1: rupee Mauritius, sen)
MXN:(.)	$(\1: peso Meksiko, centavo)
MWK:(.)	$(\1: kwacha Malawi, tambala)
NAD:(.)	$(\1: dollar Namibia, sen)
NGN:(.)	$(\1: naira, kobo)
NZD:(.)	$(\1: dollar New Zealand, sen)
PGK:(.)	$(\1: kina, toea)
PHP:(.)	$(\1: peso Filipina, centavo)
PKR:(.)	$(\1: rupee Pakistan, paisa)
PLN:(.)	$(\1: zloty, grosz)
RON:(.)	$(\1: leu Romania, ban)
RSD:(.)	$(\1: dinar Serbia, para)
RUB:(.)	$(\1: ruble Russia, kopek)
RWF:(.)	$(\1: franc Rwanda, centime)
SGD:(.)	$(\1: dollar Singapura, sen)
SLL:(.)	$(\1: leone, sen)
SZL:(.)	$(\1: lilangeni, sen)
THB:(.)	$(\1: baht, satang)
TRY:(.)	$(\1: lira Turki, kurus)
TTD:(.)	$(\1: dollar Trinidad dan Tobago, sen)
TZS:(.)	$(\1: shilling Tanzania,sen)
UAH:(.)	$(\1: hryvnia, kopiyka)
UGX:(.)	$(\1: shilling Uganda, sen)
USD:(.)	$(\1: dolar Amerika, sen)
ZAR:(.)	$(\1: rand Afrika Selatan, sen)
ZMK:(.)	$(\1: kwacha Zambia, ngwee)
ZWL:(.)	$(\1: dollar Zimbabwe, sen)

"(JPY [-−]?\d+)[.,](\d\d)0" $1
"(JPY [-−]?\d+[.,]\d\d)(\d)" $1 $2 rin

"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2$(\1:u)

"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 yiao
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 fen

"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 dan $(\30)$(\2:s)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 dan $3$(\2:s)

== ordinal ==

1		pertama
(\d+)		$(ordinal ke$1)
"kesatu (.*)"	kese\1
(.*)		\1

== ordinal-number ==

1	1
(\d+)	ke-\1

== help ==

"" $(1), $(2), $(3)\n$(help ordinal)$(help ordinal-number)
(ordinal(-number)?) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
