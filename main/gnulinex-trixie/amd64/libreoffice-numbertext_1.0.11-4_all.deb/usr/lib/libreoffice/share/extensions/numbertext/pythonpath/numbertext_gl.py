# -*- encoding: UTF-8 -*-
r"""
^0 cero
1$ un
1 un
2 dous
3 tres
4 catro
5 cinco
6 seis
7 sete
8 oito
9 nove
10 dez
11 once
12 doce
13 trece
14 catorce
15 quince
1(\d) deza$1
20 vinte
30 trinta
40 corenta
50 cincuenta
60 sesenta
70 setenta
80 oitenta
90 noventa
(\d)(\d) $(\10) e $2
1(\d\d) cen[to $1]
(\d\d) $(\100) $2
(\d)(\d\d) $1centos[ $2]
1(\d{3}) mil[ $1]
(\d{1,3})(\d{3}) $1 mil[ $2]
1(\d{6}) un millón[ $1]
(\d{1,6})(\d{6}) $1 millóns[ $2]
1(\d{12}) un billón[ $1]
(\d{1,6})(\d{12}) $1 billóns[ $2]
1(\d{18}) un trillón[ $1]
(\d{1,6})(\d{18}) $1 trillóns[ $2]
(\d{7,})(\d{18}) $1 de trillóns[ $2]

# negative number

[-−](\d+) menos |$1

# decimals

([-−]?\d+)[.] $1| punto
([-−]?\d+)[,] $1| coma
([-−]?\d+[.,])([^0]\d) $1| |$2
([-−]?\d+[.,])(\d)(\d)(\d) |$1 |$2| |$3| |$4
([-−]?\d+[.,]\d*)(\d) $1| |$2

# currency

# unit/subunit singular/plural

us:([^,]*),([^,]*),([^,]*),([^,]*) \1
up:([^,]*),([^,]*),([^,]*),([^,]*) \2
ss:([^,]*),([^,]*),([^,]*),([^,]*) \3
sp:([^,]*),([^,]*),([^,]*),([^,]*) \4

ARS:(\D+) $(\1: peso arxentino, pesos arxentinos, centavo, centavos)
BOB:(\D+) $(\1: boliviano, bolivianos, centavo, centavos)
BZD:(\D+) $(\1: dólar belizense, dólares belizenses, centavo, centavos)
CEC:(\D+) $(\1: peso convertíbel, pesos convertíbeis, centavo, centavos)
CHF:(\D+) $(\1: franco suízo, francos suízos, céntimo, céntimos)
CLP:(\D+) $(\1: peso chileno, pesos chilenos, centavo, centavos)
CNY:(\D+) $(\1: iuan renminbi, iuans renminbi, fen, fen)
COP:(\D+) $(\1: peso colombiano, pesos colombianos, centavo, centavos)
CRC:(\D+) $(\1: colón costarriqueño, colóns costarriqueños, céntimo, céntimos)
DOP:(\D+) $(\1: peso dominicano, pesos dominicanos, centavo, centavos)
ESP:(\D+) $(\1: peseta, pesetas, céntimo, céntimos)
EUR:(\D+) $(\1: euro, euros, céntimo, céntimos)
GBP:(\D+) $(\1: libra esterlina, libras esterlinas, penique, peniques)
GTQ:(\D+) $(\1: quetzal, quetzais, centavo, centavos)
HNL:(\D+) $(\1: lempira, lempiras, centavo, centavos)
JPY:(\D+) $(\1: ien, iens sen, sen)
MXN:(\D+) $(\1: peso mexicano, pesos mexicanos, centavo, centavos)
NIO:(\D+) $(\1: córdoba, córdobas, centavo, centavos)
PEN:(\D+) $(\1: sol, soles, centavo, centavos)
PYG:(\D+) $(\1: guaraní, guaranís, céntimo, céntimos)
USD:(\D+) $(\1: dólar estadounidense, dólares estadounidenses, centavo, centavos)
UYU:(\D+) $(\1: peso uruguaio, pesos uruguaios, centésimo, centésimos)
VEF:(\D+) $(\1: bolívar forte, bolívares fortes, céntimo, céntimos)

# masculine to feminine conversion of "un" after millions,
# if "as?$" matches currency name

f:(.*ill)(.*),(.*) \1$(f:\2,\3)		# don't modify un in millions
f:(.*un)([^h].*,|,)(.*as?) $(f:\1ha\2\3)	# un libra → unha libra
f:(.*)dous(.*,|,)(.*as?) $(f:\1dúas\2\3)	# dous libras → dúas libra
f:(.*)douscentos(.*,|,)(.*as?) $(f:\1duascentas\2\3)	# douscentos libras → duascentas libras
f:(.*ent)o(s.*),(.*as?) $(f:\1a\2,\3)  # trescentos libras → trescentas libras
f:(.*),(.*) \1\2

"([A-Z]{3}) ([-−]?1)([.,]00?)?"$(f:|$2,$(\1:us))
"([A-Z]{3}) ([-−]?\d+0{6,})([.,]00?)?" $2 de$(\1:up)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?"$(f:|$2,$(\1:up))

"(CNY [-−]?\d+)[.,]10?" $1 $2 jiao
"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 jiao
"(CNY [-−]?\d+[.,]\d)1" $1 $2 fen
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 fen

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 con |$(1)$(\2:ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 con |$(\30)$(\2:sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 con |$3$(\2:sp)

# ordinal

feminine:(.*un) \1ha
feminine:(.*) \1

== feminine ==

(.*)	$(feminine:|$1|)

== masculine ==

1 un
(.*)	$1

== ordinal-masculine ==

(.*) $(ordinal \1)

== ordinal ==

1 primeiro
2 segundo
3 terceiro
4 cuarto
5 quinto
6 sexto
7 sétimo
8 oitavo
9 noveno
10 décimo
11 undécimo
12 duodécimo
20 vixésimo
30 trixésimo
40 cuadraxésimo
50 quincuaxésimo
60 sesaxésimo
70 septuaxésimo
80 octoxésimo
90 nonaxésimo
(\d)(\d) $(ordinal \10) $(ordinal \2)
100 centésimo
200 ducentésimo
300 tricentésimo
400 cuadrinxentésimo
500 quinxentésimo
600 sexcentésimo
700 septinxentésimo
800 octinxentésimo
900 noninxentésimo
(\d)(\d\d) $(ordinal \100) $(ordinal \2)
1(\d{3}) milésimo[ $(ordinal \1)]
(\d{1,3})(\d{3}) $1 milésimo[ $(ordinal \2)]
1(\d{6}) millonésimo[ $(ordinal \1)]
(\d{1,3})(\d{6}) $1 millonésimo[ $(ordinal \2)]
1(\d{9}) milmillonésimo[ $(ordinal \1)]
(\d{1,3})(\d{9}) $1 milmillonésimo[ $(ordinal \2)]

== ordinal-feminine ==

([-−]?\d+) $(ordinal-feminine $(ordinal-masculine \1))
(.*)o\b(.*)  $(ordinal-feminine \1a\2)
(.*)   \1

== ordinal-masculine-adjective ==

([-−]?\d+) $(ordinal-masculine-adjective $(ordinal-masculine \1))
(.*) \1

# ordinal abbreviation

== (ordinal)-number(-feminine|-masculine|-masculine-adjective)? ==

([-−]?\d+) \3$(ordinal-number $(\1\2 \3))
.*a .ª
.*o .º

== help ==

"" $(1)|, $(2), $(3)\n$(\0 feminine)$(\0 masculine)$(\0 ordinal-number-masculine)$(\0 ordinal-number-masculine-adjective)$(\0 ordinal-number-feminine)$(\0 ordinal-feminine)$(\0 ordinal-masculine)$(\0 ordinal-masculine-adjective)
(feminine|masculine|ordinal(-number)?(-feminine|-masculine)?(-adjective)?) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
