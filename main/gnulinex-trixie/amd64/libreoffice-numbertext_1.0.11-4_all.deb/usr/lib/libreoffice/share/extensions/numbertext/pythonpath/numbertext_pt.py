# -*- encoding: UTF-8 -*-
r"""
^0 zero
1 um
2 dois
3 três
4 quatro
5 cinco
6 seis
7 sete
8 oito
9 nove
10 dez
11 onze
12 doze
13 treze
14 quatorze
15 quinze
16 dezesseis	# [:pt-BR:]
16 dezasseis
17 dezessete	# [:pt-BR:]
17 dezassete
18 dezoito
19 dezenove	# [:pt-BR:]
19 dezanove
20 vinte
30 trinta
40 quarenta
50 cinquenta
60 sessenta
70 setenta
80 oitenta
90 noventa
(\d)(\d) $(\10) e $2
100 cem
1(\d\d) cento e $1
2(\d\d) duzentos[ e $1]
3(\d\d) trezentos[ e $1]
5(\d\d) quinhentos[ e $1]
(\d)(\d\d) $1centos[ e $2]

:0+
:0*\d{1,2}(\d{6}){0,} " e "	# mil e um, mil e dez
:0*\d00(\d{6}){0,} " e "	# mil e quinhentos
:0*\d{1,2}000(\d{6}){0,} " e "	# um milhão e onze mil
:0*\d{1}00000(\d{6}){0,} " e "	# um milhão e cem mil
:\d+ " "

pl:1	ão			# milhão
pl:.*	ões			# milhões

1(\d\d\d) mil$(:\1)$1
(\d{1,3})(\d\d\d) $1 mil$(:\2)$2

(\d{1,3})(\d{6}) $1 milh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{9}) $1 bilh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{12}) $1 trilh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{15}) $1 quatrilh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{18}) $1 quintilh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{18}) $1 sextilh$(pl:\1)$(:\2)$2	# [:pt-BR:]
(\d{1,3})(\d{24}) $1 septilh$(pl:\1)$(:\2)$2	# [:pt-BR:]

(\d{1,6})(\d{6}) $1 milh$(pl:\1)$(:\2)$2
(\d{1,6})(\d{12}) $1 bili$(pl:\1)$(:\2)$2
(\d{1,6})(\d{18}) $1 trili$(pl:\1)$(:\2)$2
(\d{1,6})(\d{24}) $1 quatrili$(pl:\1)$(:\2)$2

# negative number

[-−](\d\d*) menos |$1

# decimals

([-−]?\d+)[.] $1| ponto
([-−]?\d+)[,] $1| vírgula
([-−]?\d+[.,])([^0]\d) $1| |$2
"([-−]?\d+[.,])(\d)(\d)(\d)" |$1 |$2| |$3| |$4
([-−]?\d+[.,]\d*)(\d) $1| |$2

# currency (monedas)

# unit/subunit singular/plural

us:([^,]*),([^,]*),([^,]*),([^,]*) \1
up:([^,]*),([^,]*),([^,]*),([^,]*) \2
ss:([^,]*),([^,]*),([^,]*),([^,]*) \3
sp:([^,]*),([^,]*),([^,]*),([^,]*) \4

AOA:(\D+) $(\1: kwanza, kwanzas, cêntimo, cêntimos)
ARG:(\D+) $(\1: peso argentino, pesos argentinos, centavo, centavos)
BOB:(\D+) $(\1: boliviano, bolivianos, centavo, centavos)
BRL:(\D+) $(\1: real, reais, centavo, centavos)				# [:pt-BR:]
BRL:(\D+) $(\1: real, réis, centavo, centavos)
CHF:(\D+) $(\1: franco suíço, francos suíços, cêntimo, cêntimos)
CNY:(\D+) $(\1: yuan renminbi, yuan renminbi, fen, fen)
CVE:(\D+) $(\1: escudos cabo-verdianos, escudos cabo-verdianos, centavo, centavos)
EUR:(\D+) $(\1: euro, euros, cent, cents)
GBP:(\D+) $(\1: libra esterlina, libras esterlinas, penny, pence)
JPY:(\D+) $(\1: iene, ienes, sen, sen)
MOP:(\D+) $(\1: pataca, patacas, avo, avos)
MXN:(\D+) $(\1: peso mexicano, pesos mexicanos, centavo, centavos)
MZM:(\D+) $(\1: metical, meticais, centavo, centavos)
STD:(\D+) $(\1: dobra, dobras, cêntimo, cêntimos)
USD:(\D+) $(\1: dólar americano, dólares americanos, cêntimo, cêntimos)
XOF:(\D+) $(\1: franco CFA, francos CFA, cêntimo, cêntimos)

# masculine to feminine conversion of "un" after millions,
# if "as?$" matches currency name

f:(.*il[hi])(.*),(.*) \1$(f:\2,\3)	# don't modify millions
f:(.*um)([^a].*,|,)(.*as?) $(f:\1a\2\3)	# um libra -> uma libra
f:(.*d)oi(s.*),(.*as?) $(f:\1ua\2,\3)	# dois libra -> duas libra
f:(.*ent)o(s.*),(.*as?) $(f:\1a\2,\3)	# duzentos libra -> duzentas libra
f:(.*),(.*) \1\2

"([A-Z]{3}) ([-−]?1)([.,]00?)?"$(f:|$2,$(\1:us))
"([A-Z]{3}) ([-−]?\d+0{6,})([.,]00?)?" $2 de$(\1:up)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?"$(f:|$2,$(\1:up))

"(CNY [-−]?\d+)[.,]10?" $1 $2 jiao
"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 jiao
"(CNY [-−]?\d+[.,]\d)1" $1 $2 fen
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 fen

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 e |$(1)$(\2:ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 e |$(\30)$(\2:sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 e |$3$(\2:sp)

== feminine ==

([-−]?\d+) $(feminine $1)

(.*)um \1uma
(.*)dois(.*)	$(feminine \1duas\2)
(.*) \1

== masculine ==

([-−]?\d+) $1

== ordinal(-masculine)? ==

1 primeiro
2 segundo
3 terceiro
4 quarto
5 quinto
6 sexto
7 sétimo
8 oitavo
9 nono
10 décimo
20 vigésimo
30 trigésimo
40 cuadragésimo
50 quincuagésimo
60 sexagésimo
70 septuagésimo
80 octogésimo
90 nonagésimo
(\d)(\d) $(ordinal \20) $(ordinal \3)
100 centésimo
200 ducentésimo
300 trecentésimo
400 quadrigentésimo
500 quingentésimo
600 sexcentésimo
700 septicentésimo
800 octigentésimo
900 nongentésimo
(\d)(\d\d) $(ordinal \200) $(ordinal \3)
1(\d{3}) milésimo[ $(ordinal \2)]
(\d)(\d{3}) $2 milésimo[ $(ordinal \3)]
1(\d{6}) milionésimo[ $(ordinal \2)]
(\d{1,3})(\d{6}) $2 milionésimo[ $(ordinal \3)]
1(\d{9}) bilionésimo[ $(ordinal \2)]
(\d{1,3})(\d{9}) $2 bilionésimo[ $(ordinal \3)]

== ordinal-feminine ==

([-−]?\d+) $(ordinal-feminine $(ordinal-masculine \1))
(.*)o\b(.*)  $(ordinal-feminine \1a\2)
(.*)   \1

== (ordinal)-number(-feminine|-masculine)? ==

([-−]?\d+) \3$(ordinal-number $(\1\2 \3))
.*er .ᵉʳ
.*a .ª
.*o .º

== help ==

"" $(1)|, $(2), $(3)\n$(\0 feminine)$(\0 masculine)$(\0 ordinal-feminine)$(\0 ordinal-masculine)$(\0 ordinal-number-feminine)$(\0 ordinal-number-masculine)
(feminine|masculine|ordinal(-number)?(-feminine|-masculine)?) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
