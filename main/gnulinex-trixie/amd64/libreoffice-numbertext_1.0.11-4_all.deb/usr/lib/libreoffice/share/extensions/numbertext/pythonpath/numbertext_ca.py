# -*- encoding: UTF-8 -*-
r"""
^0 zero
1$ u
1 un
2 dos
3 tres
4 quatre
5 cinc
6 sis
7 set
8 vuit
9 nou
10 deu
11 onze
12 dotze
13 tretze
14 catorze
15 quinze
16 setze
17 disset
1(\d) di$1
20 vint
2(\d) vint-i-$1
30 trenta
40 quaranta
50 cinquanta
60 seixanta
70 setanta
80 vuitanta
90 noranta
(\d)(\d) $(\10)-$2
1(\d\d) cent[ $1]
(\d)(\d\d) $1-cents[ $2]
1(\d{3}) mil[ $1]
(\d{1,3})(\d{3}) $1 mil[ $2]
1(\d{6}) un milió[ $1]
(\d{1,6})(\d{6}) $1 milions[ $2]
1(\d{9}) mil milions[ $1]
1(\d{12}) un bilió[ $1]
(\d{1,6})(\d{12}) $1 bilions[ $2]
1(\d{18}) un trilió[ $1]
(\d{1,6})(\d{18}) $1 trilions[ $2]
1(\d{24}) un quadrilió[ $1]
(\d{1,6})(\d{24}) $1 quadrilions[ $2]

# negative number

[-−](\d+) menys |$1

# decimals

"([-−]?\d+)[.,]" |$1| coma
"([-−]?\d+[.,]\d*)(\d)" $1| |$2

# currency

# convert masculine to feminine

f:(.*ili)(.*) \1$(f:\2) # convert only <1000000
f:(.*u)n([^a].*|$) $(f:\1na\2) # un -> una
f:(.*d)o(s.*) $(f:\1ue\2) # dos -> dues
f:(.*cent)(s.*) $(f:\1e\2) # cents -> centes
.:(.*) \1

# unit/subunit singular/plural

# million or greater part of the number name separated by "ili" pattern
# before masculine to feminine conversion

us(.).:([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*) $(\1:\7) \2
up(.).:([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*) $(\1:\7) \3
ud(.).:([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*) $(\1:\7) \4
ss.(.):([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*) $(\1:\7) \5
sp.(.):([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*) $(\1:\7) \6

# "mm" means masculine unit and masculine subunit

# Usually used by Catalan users
CHF:(.+),(.+) $(\2mm: franc suís, francs suïssos, de francs suïssos, cèntim, cèntims, \1)
EUR:(.+),(.+) $(\2mm: euro, euros, d'euros, cèntim, cèntims, \1)
GBP:(.+),(.+) $(\2fm: lliura esterlina, lliures esterlines, de lliures esterlines, penic, penics, \1)
JPY:(.+),(.+) $(\2mm: ien, iens, de iens, sen, sen, \1)
USD:(.+),(.+) $(\2mm: dòlar EUA, dòlars EUA, de dòlars EUA, centau, centaus, \1)

# ACTIVE ISO 4217 CODES--A--
AED:(.+),(.+) $(\2mm: dírham dels Emirats Àrabs Units, dírhams dels Emirats Àrabs Units, de dírhams dels Emirats Àrabs Units, fils, fulús, \1)
AFN:(.+),(.+) $(\2mm: afgani, afganis, d'afganis, puli, puli, \1)
ALL:(.+),(.+) $(\2mm: lek, lekë, de lekë, qindarka, qindarka, \1)
AMD:(.+),(.+) $(\2mm: dram, drams, de drams, luma, luma, \1)
ANG:(.+),(.+) $(\2mm: florí de les Antilles Neerlandeses, florins de les Antilles Neerlandeses, de florins de les Antilles Neerlandeses, cèntim, cèntims, \1)
AOA:(.+),(.+) $(\2fm: kwanza, kwanzes, de kwanzes, cèntim cèntims, \1)
ARS:(.+),(.+) $(\2mm: peso argentí, pesos argentins, de pesos argentins, centau, centaus, \1)
AUD(.+),(.+) $(\2mm: dòlar australià, dòlars australians, de dòlars australians, centau, centaus, \1)
AWG:(.+),(.+) $(\2mm: florí d'Aruba, florins d'Aruba, de florins d'Aruba, cèntim, cèntims, \1)
AZN:(.+),(.+) $(\2mm: manat azerbaidjanès, manats azerbaidjanesos, de manats azerbaidjanesos, qəpik, qəpik, \1)

# ACTIVE ISO 4217 CODES --X--
#XAF Franc CFA emès pel BEAC (Banc dels Estats de l'Àfrica Central)
XAG:(.+),(.+) $(\2fm: unça de plata, unces de plata, d'unces de plata, cèntim, cèntims, \1)
XAU:(.+),(.+) $(\2fm: unça d'or, unces d'or, d'unces d'or, cèntim, cèntims, \1)
#XBA Unitat compensatòria europea (EURCO) (unitat per al mercat d'obligacions)
#XBB Unitat monetària europea (EMU-6) (unitat per al mercat d'obligacions)
#XBC Unitat de compte europea 9 (EUA-9) (unitat per al mercat d'obligacions)
#XBD Unitat de compte europea 17 (EUA-17) (unitat per al mercat d'obligacions)
#XCD Dòlar del Carib Oriental
#XDR Drets especials de gir (del Fons Monetari Internacional)
#XFU Franc UIC (divisa especial)
#XOF Franc CFA emès pel BCEAO (Banc Central dels Estats de l'Àfrica Occidental)
XPD:(.+),(.+) $(\2fm: unça de pal·ladi, unces de pal·ladi, d'unces de pal·ladi, cèntim, cèntims, \1)
#XPF Franc CFP (per als territoris francesos del Pacífic)
XPT:(.+),(.+) $(\2fm: unça de platí, unces de platí, d'unces de platí, cèntim, cèntims, \1)
#XTS Codi reservat per a proves
#XXX Sense moneda, sense transacció monetària

# OBSOLETE ISO 4217 CODES --Replaced by EUR--
ADF:(.+),(.+) $(\2mm: franc andorrà, francs andorrans, de francs andorrans, cèntim, cèntims, \1)
ADP:(.+),(.+) $(\2fm: pesseta andorrana, pessetes andorranes, de pessetes andorranes, cèntim, cèntims, \1)
ATS:(.+),(.+) $(\2mm: xíling austríac, xílings austríacs, de xílings austríacs, groschen, groschen, \1)
BEF:(.+),(.+) $(\2mm: franc belga, francs belgues, de francs belgues, cèntim, cèntims, \1)
CYP:(.+),(.+) $(\2mm: lliura xipriota, lliures xipriotes, de lliures xipriotes, cèntim, cèntims, \1)
DEM:(.+),(.+) $(\2mm: marc alemany, marcs alemanys, de marcs alemanys, penic, penics, \1)
ESP:(.+),(.+) $(\2fm: pesseta, pessetes, de pessetes, cèntim, cèntims, \1)
FIM:(.+),(.+) $(\2mm: marc finlandès, marcs finlandesos, de marcs finlandesos, penic, penics, \1)
FRF:(.+),(.+) $(\2mm: franc francès, francs francesos, de francs francesos, cèntim, cèntims, \1)
GRD:(.+),(.+) $(\2fm: dracma grega, dracmes gregues, leptó, leptà, \1)
IEP:(.+),(.+) $(\2fm: lliura irlandesa, lliures irlandeses, de lliures irlandeses, penic, penics, \1)
ITL:(.+),(.+) $(\2fm: lira italiana, lires italianes, de lires italianes, cèntim, cèntims, \1)
LUF:(.+),(.+) $(\2mm: franc luxemburguès, francs luxemburguesos, de francs luxemburguesos, cèntim, cèntims, \1)
MCF:(.+),(.+) $(\2mm: franc monegasc, francs monegascs, de francs monegascs, cèntim, cèntims, \1)
MTL:(.+),(.+) $(\2fm: lira maltesa, lires malteses, de lires malteses, cèntim, cèntims, \1)
NLG:(.+),(.+) $(\2mm: florí neerlandès, florins neerlandesos, de florins neerlandesos, cèntim, cèntims, \1)
PTE:(.+),(.+) $(\2mm: escut portuguès, escuts portuguesos, de escuts portuguesos, centau, centaus, \1)
SIT:(.+),(.+) $(\2mm: tolar eslovè, tolars eslovens, de tolars eslovens, stotin, stotinov, \1)
SKK:(.+),(.+) $(\2fm: corona eslovaca, corones eslovaques, de corones eslovaques, halier, halierov, \1)
SML:(.+),(.+) $(\2fm: lira de San Marino, lires de San Marino, de lires de San Marino, cèntim, cèntims, \1)
VAL:(.+),(.+) $(\2fm: lira vaticana, lires vaticanes, de lires vaticanes, cèntim, cèntims, \1)
XEU:(.+),(.+) $(\2mm: ecu, ecus, d'ecus, cèntim, cèntims, \1)

"([A-Z]{3}) ([-−]?[01])([.,]00?)?"$(\1:|$2,us)
"([A-Z]{3}) ([-−]?\d+0{6,})([.,]00?)?"$(\1:|$2,ud)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?"$(\1:|$2,up)

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 amb$(\2:un,ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 amb$(\2:|$(\30),sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 amb$(\2:|$3,sp)

== feminine ==

1 una
(.*)	$(f:|$1)

== masculine ==

1 un
(.*)	$1

== ordinal(-masculine)? ==

1 primer
2 segon
([-−]?\d+) $(ordinal |$2)

(.*)nou		\2novè
(.*)deu		\2desè
(.*-)u(na?)?	\2unè
"(.* )u(na?)?"	\2 primer
"(.* )dos"	\2segon
"(.* t|t)res"	\2ercer
"(.* q|q)uatre"	\2uart
(.*)cinc	\2cinquè
(.*)[ae]	\2è
(.*(cent|mil|ion))s?	\2è
(.*li)ó		\2onè
(.*)		\2è

== ordinal-feminine ==

([-−]?\d+) $(ordinal-feminine $(ordinal-masculine \1))
(.*)è  \1ena
(.*)   \1a

== (ordinal)-number(-feminine|-masculine)? ==

([-−]?\d+)	\3$(ordinal-number $(\1\2 \3))
.*(.) \3

== help ==

"" $(1)|, $(2), $(3)\n$(help feminine)$(help masculine)$(help ordinal-number-masculine)$(help ordinal-number-feminine)$(help ordinal-feminine)$(help ordinal-masculine)
(feminine|masculine|ordinal(-number)?(-feminine|-masculine)?) \1: $(\1 1), $(\1 2), $(\1 3)\n
"""
from __future__ import unicode_literals
