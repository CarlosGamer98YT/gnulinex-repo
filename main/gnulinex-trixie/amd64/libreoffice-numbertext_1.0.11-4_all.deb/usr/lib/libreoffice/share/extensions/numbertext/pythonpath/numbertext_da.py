# -*- encoding: UTF-8 -*-
r"""
^0 nul
1$ en
1 et
2 to
3 tre
4 fire
5 fem
6 seks
7 syv
8 otte
9 ni
10 ti

11 elleve
12 tolv
13 tretten
14 fjorten
15 femten
16 seksten
17 sytten
18 atten
19 nitten

20 tyve
30 tredive
40 fyrre
50 halvtreds
60 tres
70 halvfjerds
80 firs
90 halvfems

(\d)(\d) $2|og$(\10)
(\d)(\d\d) $1 hundrede[ og $2]
(\d{1,3})(\d{3}) $1 tusind[ og $2]

a:1,0+
a:\d+,0+ er
a:1,(\d+) " og $1"
a:\d+,(\d+) "er og $1"

(\d{1,3})(\d{6}) $1| million$(a:\1,\2)
(\d{1,3})(\d{9}) $1| milliard$(a:\1,\2)
(\d{1,3})(\d{12}) $1| billion$(a:\1,\2)
(\d{1,3})(\d{15}) $1| billiard$(a:\1,\2)
(\d{1,3})(\d{18}) $1| trillion$(a:\1,\2)
(\d{1,3})(\d{21}) $1| trilliard$(a:\1,\2)
(\d{1,3})(\d{24}) $1| kvadrillion$(a:\1,\2)

# negative number

[-−](\d+) minus |$1

# decimals

([-−]?\d+)[.,] $1| komma
"([-−]?\d+[.,]0*)(\d+)" $1 |$2
([-−]?\d+[.,]\d*)(\d) $1| |$2

# currency

# unit/subunit singular/plural

us:([^,]*),([^,]*),([^,]*),([^,]*) \1
up:([^,]*),([^,]*),([^,]*),([^,]*) \2
ss:([^,]*),([^,]*),([^,]*),([^,]*) \3
sp:([^,]*),([^,]*),([^,]*),([^,]*) \4

CHF:(\D+) $(\1: schweizisk franc, schweizisk franc, centime, centimes)
CNY:(\D+) $(\1: renminbi yuan, renminbi yuan, fen, fen)
DKK:(\D+) $(\1: dansk krone, danske kroner, øre, øre)
EUR:(\D+) $(\1: euro, euro, cent, cent)
GBP:(\D+) $(\1: pund sterling, pund sterling, penny, pence)
ISK:(\D+) $(\1: islandsk krone, islandske kroner, eyrir, aurar)
JPY:(\D+) $(\1: yen, yen, sen, sen)
SEK:(\D+) $(\1: svensk krone, svenske kroner, öre, öre)
USD:(\D+) $(\1: US dollar, US dollar, cent, cent)

"([A-Z]{3}) ([-−]?1)([.,]00?)?" $2$(\1:us)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2$(\1:up)

"(CNY [-−]?\d+)[.,]10?" $1 $2 jiao
"(CNY [-−]?\d+)[.,](\d)0?" $1 $2 jiao
"(CNY [-−]?\d+[.,]\d)1" $1 $2 fen
"(CNY [-−]?\d+[.,]\d)(\d)" $1 $2 fen

"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 |$(1)$(\2:ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 |$(\30)$(\2:sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 |$3$(\2:sp)

== ordinal ==

([-−]?\d+) $(ordinal |$1)

nul		nulte		# 0
en		først		# 1
"(.*) en"	\1 først	# 1
(.*)to		\1anden		# 2
(.*)tre		\1tredje	# 3
(.*)fire	\1fjerde	# 4
(.*(fem|ellev|tolv|ard|on))(e|er)?	\1te # 5, 11, 12, 10^6, 10^9 etc.
(.*)seks	\1sjette	# 6
(.*)tres	\1tressende	# 60
(.*(syv|ott|ni|ti|tyv|trediv|fyrr|s))e?	\1ende # 7, 8, 9, 10, 20, 30, 40, 50, 70, 80, 90
(.*en)		\1de		# 13-19
(.*tusind)	\1e		# 1000 etc.
(.*)		\1		# 100, etc.

== ordinal-number ==

(\d+)	\1.

== help ==

"" |$(1)|, |$(2)|, |$(3)|\n$(help ordinal)$(help ordinal-number)
(ordinal(-number)?) \1: |$(\1 1)|, |$(\1 2)|, |$(\1 3)|\n
"""
from __future__ import unicode_literals
