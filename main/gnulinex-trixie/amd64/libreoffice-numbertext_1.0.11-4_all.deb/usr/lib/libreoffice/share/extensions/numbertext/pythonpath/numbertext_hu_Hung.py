# -*- encoding: UTF-8 -*-
r"""
# Old Hungarian script (ISO 15924 code: Hung)

# Transliterate numbers and words

# parentheses
"([\(\[\{])(.*) 0$" \1$2
"(.*)([\]\)\}]) 0$" $1\2
# convert words with traditional or foreign "i" written as "y"
# e.g. Áprily, Champs-Élysées, Élysée-palota, Dolly, Folly, Hollywood, jolly, intercity, Kisfaludy ...
"^(Áp​?ri​?l|Champs-Él|[cC]i​?t|Do​?lák-Sa​?l|[dfhjDFHJ]ol​?l|Él|Fesz​?t|[gG]rizz​?l|Ha​?rasz​?t|Hat​?va​?n|Husz​?t|[iI]n​?ter​?ci​?t|Jé​?ke​?l|Kis​?fa​?lu​?d|Ku​?ko​?r​?el​?l|Mo​?ho​?l|Mind​?szen​?t|Nosz​?t|[pP]en​n|Pes​?t|Re​?gu​?l|So​?n|Szi​?l|Szte​?va​?no​?vi​?t|Vö​?rös​?mar​?t|[zZ][lł]ot)y(.*) 0$" $1𐳐$2
"^(ÁP​?RI​?L|CHAMPS-ÉL|CI​?T|DO​?LÁK-SA​?L|[DFHJ]OL​?L|ÉL|FESZ​?T|GRIZZ​?L|HA​?RASZ​?T|HAT​?VA​?N|HUSZ​?T|IN​?TER​?CI​?T|JÉ​?KE​?L|KIS​FA​LU​?D|KU​?KO​?R​?EL​?L|MIND​?SZEN​?T|MO​?HO​?L|NOSZ​?T|PEN​?N|PES​?T|RE​?GU​?L|SO​?N|SZI​?L|SZTE​?VA​?NO​?VI​?T|VÖ​?RÖS​?MAR​?T|Z[LŁ]OT)Y(.*) 0$" $1𐲐$2
# punctuation with transliterated letters
"^((𐲀|𐲁|𐲂|𐲄|𐲆|𐲇|𐲉|𐲊|𐲋|𐲌|𐲍|𐲎|𐲏|𐲐|𐲑|𐲒|𐲓|𐲖|𐲗|𐲘|𐲙|𐲚|𐲛|𐲜|𐲞|𐲟|𐲠|𐲢|𐲤|𐲥|𐲦|𐲨|𐲪|𐲫|𐲬|𐲭|𐲮|𐲯|𐲰|𐳀|𐳁|𐳂|𐳄|𐳆|𐳇|𐳉|𐳊|𐳋|𐳌|𐳍|𐳎|𐳏|𐳐|𐳑|𐳒|𐳓|𐳖|𐳗|𐳘|𐳙|𐳚|𐳛|𐳜|𐳞|𐳟|𐳠|𐳢|𐳤|𐳥|𐳦|𐳨|𐳪|𐳫|𐳬|𐳭|𐳮|𐳯|𐳰|𐳺|𐳻|𐳼|𐳽|𐳾|𐳿|[-0-9​–,„”.!\?\;‟⹂⹁⁏⸮])*[,„”\?\;]) 0$" $1
# if the original word contains an unknown character, return without modification
"^(.*[^-0-9qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNMáäéëíóöőúüűÁÄÉËÍÓÖŐÚÜŰ​–,„”\?\;].*) 0$" \1
# words with y
"^y(ard.*) 0$" 𐳒$1
"^Y([aA][rR][dD].*|[uU]​?[cC][oO][nN].*) 0$" 𐲒$1
"^Y([bB][lL].*) 0$" 𐲑$1
"^Y(vet​?te.*) 0$" 𐲐$1
"^([bB]o|[cC]ow​?bo|[dD]isp​?la|[gG]ra|[pP]la)y(.*) 0$" $1𐳒$2
"^(BO|COW​?BO|DISP​?LA|GRA|PLA)Y(.*) 0$" $1𐲒$2
# don't transliterate other words with starting y
"(^[yY].*) 0$" \1
# don't transliterate words with q, but not with qu
"(^.*[qQ][^uU].*) 0$" \1
"(^.*[qQ]) 0$" \1
# other exceptions
# Ágh -> Ág, Balogh -> Balog, Horváth -> Horvát, Mikszáth -> Mikszát, Németh -> Német, Tóth -> Tót, Virágh -> Virág, Végh -> Vég
^([Á][gG]|B[aA]​?[lL][oO][gG]|H[oO][rR]​?[vV][áÁ][tT]|M[iI][kK]​?[sS][zZ][áÁ][tT]|N[éÉ]​?[mM][eE][tT]|T[óÓ][tT]|V[iI]​?[rR][áÁ][gG]|V[éÉ][gG])[hH](.*) $(\1\2)
# Antall -> Antal, Gáll -> Gál, Széll -> Szél
"^(An​?tal|Gál|Szél)​?l 0$" $(\1)
"^(AN​?TAL|GÁL|SZÉL)​?L 0$" $(\1)
# Apáthy -> Apáti, Bláthy -> Bláti, Básthy -> Básti ...
^(A​?pá|Blá|Bás|Hon|Hor|Ka​?rin|Kom​?já|Szent​?ku|Szom​?ba)​?thy(.*) $(\1ti\2)
^(A​?PÁ|BLÁ|BÁS|HON|HOR|KA​?RIN|KOM​?JÁ|SZENT​?KU|SZOM​?BA)​?THY(.*) $(\1TI\2)
# Apponyi -> Aponyi
^Ap​?([pP][oO]​?[nN][yY][iI].*) $(A\1)
# Babits -> Babics, Derkovits -> Derkovics, Takáts -> Takács, Szűts -> Szűcs
^(Ba​?bi|Der​?ko​?vi|Sin​?ko​?vi|Ta​?ká|Sz[üű])ts(.*) $(\1cs\2)
^(BA​?BI|DER​?KO​?VI|SIN​?KO​?VI|TA​?KÁ|SZ[ÜŰ])TS(.*) $(\1CS\2)
# Bakách -> Bakács, Damjanich -> Damjanics, Forgách -> Forgács, Jurisich -> Jurisics, Madách -> Madács
^(Ba​?ká|Dam​?ja​?ni|For​?gá|Gras​?sal​?ko​?vi|Ju​?ri​?si|Ma​?dá)ch(.*) $(\1cs\2)
^(BA​?KÁ|DAM​?JA​?NI|FOR​?GÁ|GRAS​?SAL​?KO​?VI|JU​?RI​?SI|MA​?DÁ)CH(.*) $(\1CS\2)
# Bakócz -> Bakóc, Börötz -> Böröc, Göncz -> Gönc, Makovecz -> Makovec, Móricz -> Móric ...
^(B[aA]​?[kK][óÓ]|B[öÖ]​?[rR][öÖ][cC]|G[öÖ][nN]|M[aA]​?[kK][oO]​?[vV][eE]|M[óÓ]​?[rR][iI]|K[oO][nN]|O​?[rR][aA]​?[vV][eE]|R[áÁ]|R[áÁ]|T[iI]​?[bB][oO][rR])([cCtT])[zZ](.*) $(\1\2\3)
# Bakoss -> Bakos, Baross -> Baros, Boross -> Boros, Hankiss -> Hankis, Kass -> Kas, Kiss -> Kis, Terebess -> Terebes, Vass -> Vas
"^(Ba​?kos|Ba​?ros|Bo​?ros|Han​?kis|Kas|Kis|Lo​?vas|Te​?re​?bes|Vas)​?s 0$" $(\1)
"^(BA​?KOS|BA​?ROS|BO​?ROS|HAN​?KIS|KAS|KIS|LO​?VAS|TE​?RE​?BES|VAS)​?S 0$" $(\1)
# Bay -> Baji
"^Bay 0$" $(Baji)
# Batsányi -> Bacsányi
^Ba​?tsá​?nyi(.*) $(Bacsányi)
^BA​?TSÁ​?NYI(.*) $(BACSÁNYI)
# Bárczi -> Bárci, Kazinczy -> Kazinci, Rákóczi -> Rákóci
^(Bár|Ka​?zin|Rá​?kó)​?cz[iy](.*) $(\1ci\2)
^(BÁR|KA​?ZIN|RÁ​?KÓ)​?CZ[IY](.*) $(\1CI\2)
# Báthory -> Bátori
^(B[áÁ]​?[tT])[hH]([oO]​?[rR][yY].*) $(\1\2)
# Batthyány -> Battyányi
^Bat​?thyá​?ny(.*) $(Battyányi\1)
^BAT​?THYÁ​?NY(.*) $(BATTYÁNYI\1)
# Bessenyei -> Besenyei
^(B[eE][sS])​?[sS]([eE]​?[nN][yY][eE]​?[iI].*) $(\1\2)
# Czuci -> Cuci, Czuczor -> Cucor
^Cz(u​?c)z(([iI]|[oO][rR]).*) $(C\1\2)
# Csathó -> Csató
^(C[sS][aA]​?[tT])[hH]([óÓ].*) $(\1\2)
# Dessewffy -> Dezsőfi
^De​?s​?sew​?ffy(.*) $(Dezsőfi\1)
^DE​?S​?SEW​?FFY(.*) $(DEZSŐFI\1)
# Eördögh -> Ördög
^Eör​?dögh(.*) $(Ördög\1)
^EÖR​?DÖGH(.*) $(ÖRDÖG\1)
# Eöry -> Őri, Eőry -> Őri
^E[öő]​?ry(.*) $(Őri\1)
^E[ÖŐ]​?RY(.*) $(ŐRI\1)
# Eötvös -> Ötvös
^Eöt​?vös(.*) $(Ötvös\1)
^EÖT​?VÖS(.*) $(ÖTVÖS\1)
# Gaál -> Gál
^Ga​?ál(.*) $(Gál\1)
# Háy -> Háji, Fáy -> Fáji, Márki-Zay -> Márki-Zaji, Vay -> Vaji
^(Há|Fá|Már​?ki-​?Za|Va|Za)y(.*) $(\1ji\2)
^(HÁ|FÁ|MÁR​?KI-​?ZA|VA|ZA)Y(.*) $(\1JI\2)
# Joó -> Jó
^J[oO]​?([óÓ].*) $(J\1)
# Kéthly -> Kétli
^Kéth​?ly(.*) $(Kétli\1)
^KÉTH​?LY(.*) $(KÉTLI\1)
# Konkoly-Thege -> Konkoli-Tege
^Kon​?ko​?ly-​?The​?g([eé].*) $(Konkoli-Teg\1)
^KON​?KO​?LY-​?THE​?G([EÉ].*) $(KONKOLI-TEG\1)
# Koós -> Kós, Soós -> Sós
^([KS])[oO]([óÓ][sS])(.*) $(\1\2\3)
# Kossuth -> Kosut, Passuth -> Pasut
^(K[oO]|P[aA])[sS]​?([sS][uU][tT])[hH](.*) $(\1\2\3)
# Pais -> Pajzs
^Pai​?s(.*) $(Pajzs\1)
^PAI​?S(.*) $(PAJZS\1)
# Széchenyi -> Szécsényi
^Szé​?che​?nyi(.*) $(Szécsényi\1)
^SZÉ​?CHE​?NYI(.*) $(SZÉCSÉNYI\1)
# Széchy -> Szécsi, Zichy -> Zicsi
^(Szé|Zi)​?chy(.*) $(\1csi\2)
^(SZÉ|ZI)​?CHY(.*) $(\1CSI\2)
# Tarr -> Tar
"^(T[aA][rR])[rR] 0$" $(\1)
# Thewrewk -> Török
^Thew​?rewk(.*) $(Török\1)
^THEW​?REWK(.*) $(TÖRÖK\1)
# Thököly -> Tököli
^Thö​?kö​?ly(.*) $(Tököli\1)
^THÖ​?KÖ​?LY(.*) $(TÖKÖLI\1)
# Veér -> Vér
^V[eE]​?([éÉ][rR].*) $(V\1)
# Verseghy -> Versegi
^Ver​?se​?ghy(.*) $(Versegi\1)
# Wass -> Vas
"^Was​?(sal|sá) 0$" $(Vas\1)
"^WAS​?(SAL|SÁ) 0$" $(VAS\1)
^Was​?s(.*) $(Vas\1)
^WAS​?S(.*) $(VAS\1)
# Wesselényi -> Veselényi
^Wes​?se​?lé​?nyi(.*) $(Veselényi\1)
^WES​?SE​?LÉ​?NYI(.*) $(VESELÉNYI\1)
# Weöres -> Vörös
^Weö​?res(.*) $(Vörös\1)
^WEÖ​?RES(.*) $(VÖRÖS\1)
# Zigány -> Cigány
^Zi​?gán(y|ny)(.*) $(Cigán\1\2)
^ZI​?GÁN(Y|NY)(.*) $(CIGÁN\1\2)

# avoid of exceeding recursion depth
# convert by 200-character parts
(.{200})(.+) $1$2

# numbers

# remove space separated zero (in LibreOffice integration)
"(\d+) 0" $1

"0: (.*) (.*)"
"1: (.*) (.*)" \1
"2: (.*) (.*)" \1\1
"3: (.*) (.*)" \1\1\1
"4: (.*) (.*)" \1\1\1\1
"5: (.*) (.*)" \2
"6: (.*) (.*)" \2\1
"7: (.*) (.*)" \2\1\1
"8: (.*) (.*)" \2\1\1\1
"9: (.*) (.*)" \2\1\1\1\1

(\d) $(\1: 𐳺 𐳻)
(\d)(\d) $(\1: 𐳼 𐳽)$2
1(\d\d) 𐳾$1
(\d)(\d\d) $1𐳾$2
1(\d\d\d)$ 𐳿$1
(\d{1,3})(\d\d\d) $1𐳿$2
1(\d{6})$ 𐳿𐳿$1
(\d{1,3})(\d{6}) $1𐳿𐳿$2
1(\d{9})$ 𐳿𐳿𐳿$1
(\d{1,3})(\d{9}) $1𐳿𐳿𐳿$2

# numbers with letters, for example dates with affixes

"(\d+)([^ ]+)" $1$2

# letters

"^(.*) 0$" $1
a(.*) 𐳀$1
A(.*) 𐲀$1
á(.*) 𐳁$1
Á(.*) 𐲁$1
b(.*) 𐳂$1
B(.*) 𐲂$1
ccs(.*) 𐳆𐳆$1
CCS(.*) 𐲆𐲆$1
cs(.*) 𐳆$1
C[sS](.*) 𐲆$1
c(.*) 𐳄$1
C(.*) 𐲄$1
d(.*) 𐳇$1
D(.*) 𐲇$1
e(.*) 𐳉$1
E(.*) 𐲉$1
é(.*) 𐳋$1
É(.*) 𐲋$1
ä(.*) 𐳋$1
Ä(.*) 𐲋$1
ë(.*) 𐳊$1
Ë(.*) 𐲊$1
f(.*) 𐳌$1
F(.*) 𐲌$1
ggy(.*) 𐳎𐳎$1
GGY(.*) 𐲎𐲎$1
gy(.*) 𐳎$1
G[yY](.*) 𐲎$1
g(.*) 𐳍$1
G(.*) 𐲍$1
h(.*) 𐳏$1
H(.*) 𐲏$1
i(.*) 𐳐$1
I(.*) 𐲐$1
í(.*) 𐳑$1
Í(.*) 𐲑$1
j(.*) 𐳒$1
J(.*) 𐲒$1
k(.*) 𐳓$1
K(.*) 𐲓$1
lly(.*) 𐳗𐳗$1
LLY(.*) 𐲗𐲗$1
ly(.*) 𐳗$1
L[yY](.*) 𐲗$1
l(.*) 𐳖$1
L(.*) 𐲖$1
m(.*) 𐳘$1
M(.*) 𐲘$1
nny(.*) 𐳚𐳚$1
NNY(.*) 𐲚𐲚$1
ny(.*) 𐳚$1
N[yY](.*) 𐲚$1
n(.*) 𐳙$1
N(.*) 𐲙$1
o(.*) 𐳛$1
O(.*) 𐲛$1
ó(.*) 𐳜$1
Ó(.*) 𐲜$1
ö(.*) 𐳞$1
Ö(.*) 𐲞$1
ő(.*) 𐳟$1
Ő(.*) 𐲟$1
p(.*) 𐳠$1
P(.*) 𐲠$1
qu(.*) 𐳓𐳮$1 # qu->kv
Qu(.*) 𐲓𐳮$1 # Qu->Kv
QU(.*) 𐲓𐲮$1 # QU->KV
r(.*) 𐳢$1
R(.*) 𐲢$1
ssz(.*) 𐳥𐳥$1
SSZ(.*) 𐲥𐲥$1
sz(.*) 𐳥$1
S[zZ](.*) 𐲥$1
sch(.*) 𐳤$1
Sch(.*) 𐲤$1
s(.*) 𐳤$1
S(.*) 𐲤$1
tty(.*) 𐳨𐳨$1
TTY(.*) 𐲨𐲨$1
ty(.*) 𐳨$1
T[yY](.*) 𐲨$1
t(.*) 𐳦$1
T(.*) 𐲦$1
u(.*) 𐳪$1
U(.*) 𐲪$1
ú(.*) 𐳫$1
Ú(.*) 𐲫$1
ü(.*) 𐳭$1
Ü(.*) 𐲭$1
ű(.*) 𐳬$1
Ű(.*) 𐲬$1
[vw](.*) 𐳮$1
[VW](.*) 𐲮$1
x(.*) 𐳓𐳥$1 # x->ksz
^X 𐲓𐳥$1 # X->KSz
X 𐲓𐲥$1 # X->KSZ
X([A-ZÁÉËÍÓÖŐÚÜŰ].*) 𐲓𐲥$1 # X->KSZ
X(.*) 𐲓𐳥$1 # X->Ksz
y(.*) 𐳐$1  # .+y->i
Y(.*) 𐲐$1  # .+Y->I
zzs(.*) 𐳰𐳰$1
ZZS(.*) 𐲰𐲰$1
zs(.*) 𐳰$1
Z[sS](.*) 𐲰$1
z(.*) 𐳯$1
Z(.*) 𐲯$1

# remove ZWSP (used for consonant disambiguation)
​(.*) $1

# punctuation
”(.*) ‟$1
\;(.*) ⁏$1
\?(.*) ⸮$1
,(.*) ⹁$1
„(.*) ⹂$1

# don't modify unknown characters
(.)(.*) \1$2
(.*) \1
"""
from __future__ import unicode_literals
